package com.amway.config;

import static java.util.Collections.singletonList;

import com.amway.exception.handler.CustomCacheErrorHandler;
import com.amway.util.JsonUtil;
import com.github.benmanes.caffeine.cache.Caffeine;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@EnableCaching
@ImportResource({ "classpath*:exbeans-${EXTREME_ENVIRONMENT}.xml" })
public class CacheConfiguration extends CachingConfigurerSupport {
	@Value("${currentEnvironment}")
	private String env;

	@Bean
	@Override
	public KeyGenerator keyGenerator() {
		return (o, method, params) -> {
			StringBuilder sb = new StringBuilder();
			sb.append(env);
			sb.append(o.getClass().getName());
			sb.append(method.getName());
			return sb.toString();
		};
	}

	@Bean
	public KeyGenerator keyGeneratorForEndPoint() {
		return (o, method, params) -> JsonUtil.getJsonString(env + params[0]);
	}

	@Override
	public CacheErrorHandler errorHandler() {
		return new CustomCacheErrorHandler();
	}

	@Bean
	public CacheManager caffeineCacheManager() {
		SimpleCacheManager cacheManager = new SimpleCacheManager();
		cacheManager.setCaches(singletonList(
				new CaffeineCache("local-cache", Caffeine.newBuilder()
						.maximumSize(1000)
						.expireAfterWrite(12, TimeUnit.HOURS)
						.build())));
		cacheManager.initializeCaches();
		return cacheManager;
	}
}