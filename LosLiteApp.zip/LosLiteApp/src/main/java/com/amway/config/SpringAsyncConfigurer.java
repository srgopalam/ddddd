package com.amway.config;

import com.amway.exception.handler.CustomAsyncExceptionHandler;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@EnableAsync
@Configuration
public class SpringAsyncConfigurer implements AsyncConfigurer {

	@Bean
	@Override
	public TaskExecutor getAsyncExecutor() {
		//TODO: Make these configurable
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(100);
		//executor.setMaxPoolSize(1000);
		//executor.setQueueCapacity(2000);
		executor.setThreadNamePrefix("AsyncExecutorThread-");
		executor.setDaemon(true);
		executor.initialize();
		return executor;
	}

	@Override
	public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
		return new CustomAsyncExceptionHandler();
	}

}