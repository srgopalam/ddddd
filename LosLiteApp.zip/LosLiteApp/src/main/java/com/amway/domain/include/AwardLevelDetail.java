package com.amway.domain.include;

import java.io.Serializable;
import java.util.Objects;

public class AwardLevelDetail implements Serializable {

	private static final long serialVersionUID = -3885764547399517546L;
	private String currentAward;
	private String currentAwardName;
	private int currentAwardRank;
	private int currentQualPeriod;
	private String highestAward;
	private String highestAwardName;
	private int highestAwardRank;
	private int highestQualPeriod;

	public AwardLevelDetail() {
		super();
	}

	public String getCurrentAward() {
		return currentAward;
	}

	public void setCurrentAward(String currentAward) {
		this.currentAward = currentAward;
	}

	public String getCurrentAwardName() {
		return currentAwardName;
	}

	public void setCurrentAwardName(String currentAwardName) {
		this.currentAwardName = currentAwardName;
	}

	public int getCurrentAwardRank() {
		return currentAwardRank;
	}

	public void setCurrentAwardRank(int currentAwardRank) {
		this.currentAwardRank = currentAwardRank;
	}

	public int getCurrentQualPeriod() {
		return currentQualPeriod;
	}

	public void setCurrentQualPeriod(int currentQualPeriod) {
		this.currentQualPeriod = currentQualPeriod;
	}

	public String getHighestAward() {
		return highestAward;
	}

	public void setHighestAward(String highestAward) {
		this.highestAward = highestAward;
	}

	public String getHighestAwardName() {
		return highestAwardName;
	}

	public void setHighestAwardName(String highestAwardName) {
		this.highestAwardName = highestAwardName;
	}

	public int getHighestAwardRank() {
		return highestAwardRank;
	}

	public void setHighestAwardRank(int highestAwardRank) {
		this.highestAwardRank = highestAwardRank;
	}

	public int getHighestQualPeriod() {
		return highestQualPeriod;
	}

	public void setHighestQualPeriod(int highestQualPeriod) {
		this.highestQualPeriod = highestQualPeriod;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(currentAward, currentAwardName, currentAwardRank, currentQualPeriod, highestAward,
				highestAwardName, highestAwardRank, highestQualPeriod);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AwardLevelDetail)) {
			return false;
		}
		AwardLevelDetail other = (AwardLevelDetail) obj;
		return Objects.equals(currentAward, other.currentAward)
				&& Objects.equals(currentAwardName, other.currentAwardName)
				&& currentAwardRank == other.currentAwardRank && currentQualPeriod == other.currentQualPeriod
				&& Objects.equals(highestAward, other.highestAward)
				&& Objects.equals(highestAwardName, other.highestAwardName)
				&& highestAwardRank == other.highestAwardRank && highestQualPeriod == other.highestQualPeriod;
	}

}
