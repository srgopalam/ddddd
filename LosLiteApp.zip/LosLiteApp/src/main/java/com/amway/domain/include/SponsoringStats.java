package com.amway.domain.include;

import java.io.Serializable;
import java.util.Objects;

public class SponsoringStats implements Serializable {
	private static final long serialVersionUID = 944720511265094629L;
	private int groupCount;

	public int getGroupCount() {
		return groupCount;
	}

	public void setGroupCount(int groupCount) {
		this.groupCount = groupCount;
	}

	@Override
	public int hashCode() {
		return Objects.hash(groupCount);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SponsoringStats)) {
			return false;
		}
		SponsoringStats other = (SponsoringStats) obj;
		return groupCount == other.groupCount;
	}

}
