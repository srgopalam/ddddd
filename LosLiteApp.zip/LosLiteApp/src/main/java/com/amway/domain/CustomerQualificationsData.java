package com.amway.domain;

import java.util.Map;

public class CustomerQualificationsData {
	private long bonusCustomerId;
	private int period;
	private Map<String, QualificationsData> qualificationsMap;

	public CustomerQualificationsData(long bonusCustomerId, int period,
			Map<String, QualificationsData> qualificationsMap) {
		super();
		this.bonusCustomerId = bonusCustomerId;
		this.period = period;
		this.qualificationsMap = qualificationsMap;
	}

	public long getBonusCustomerId() {
		return bonusCustomerId;
	}

	public void setBonusCustomerId(long bonusCustomerId) {
		this.bonusCustomerId = bonusCustomerId;
	}

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public Map<String, QualificationsData> getQualificationsMap() {
		return qualificationsMap;
	}

	public void setQualificationsMap(Map<String, QualificationsData> qualificationsMap) {
		this.qualificationsMap = qualificationsMap;
	}

}
