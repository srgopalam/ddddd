package com.amway.domain;

import java.util.Objects;

public class AffAbo {

	private int aff;
	private long abo;

	public int getAff() {
		return aff;
	}

	public void setAff(int aff) {
		this.aff = aff;
	}

	public long getAbo() {
		return abo;
	}

	public void setAbo(long abo) {
		this.abo = abo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AffAbo [aff=").append(aff).append(", abo=").append(abo).append("]");
		return builder.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(abo, aff);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AffAbo)) {
			return false;
		}
		AffAbo other = (AffAbo) obj;
		return abo == other.abo && aff == other.aff;
	}

}
