package com.amway.domain.include;

import java.io.Serializable;
import java.util.List;

public class PVBVSummary implements Serializable {

	private static final long serialVersionUID = 8282687443202518690L;
	private List<VolumeTypesPVBVData> volumeTypesPVBVDataList;

	public List<VolumeTypesPVBVData> getVolumeTypesPVBVDataList() {
		return volumeTypesPVBVDataList;
	}

	public void setVolumeTypesPVBVDataList(List<VolumeTypesPVBVData> volumeTypesPVBVDataList) {
		this.volumeTypesPVBVDataList = volumeTypesPVBVDataList;
	}
}
