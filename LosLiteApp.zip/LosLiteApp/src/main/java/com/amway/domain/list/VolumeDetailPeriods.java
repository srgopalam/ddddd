package com.amway.domain.list;

import java.io.Serializable;
import java.util.List;

public class VolumeDetailPeriods implements Serializable {
	private static final long serialVersionUID = 1957198264106116533L;
	private List<VolumeDetailPeriod> volumeDetailPeriods;

	public List<VolumeDetailPeriod> getVolumeDetailPeriods() {
		return volumeDetailPeriods;
	}

	public void setVolumeDetailPeriods(List<VolumeDetailPeriod> volumeDetailPeriods) {
		this.volumeDetailPeriods = volumeDetailPeriods;
	}
}
