package com.amway.domain.include;

import java.io.Serializable;

public class QualCounts implements Serializable {
	private static final long serialVersionUID = 6795670463247872056L;
	private int fosterQualifiedLegsCount;
	private int inMktQualifiedLegsCount;
	private int intlQualifiedLegsCount;
	private int qualifiedAwardLegsCount;

	public int getFosterQualifiedLegsCount() {
		return fosterQualifiedLegsCount;
	}

	public void setFosterQualifiedLegsCount(int fosterQualifiedLegsCount) {
		this.fosterQualifiedLegsCount = fosterQualifiedLegsCount;
	}

	public int getInMktQualifiedLegsCount() {
		return inMktQualifiedLegsCount;
	}

	public void setInMktQualifiedLegsCount(int inMktQualifiedLegsCount) {
		this.inMktQualifiedLegsCount = inMktQualifiedLegsCount;
	}

	public int getIntlQualifiedLegsCount() {
		return intlQualifiedLegsCount;
	}

	public void setIntlQualifiedLegsCount(int intlQualifiedLegsCount) {
		this.intlQualifiedLegsCount = intlQualifiedLegsCount;
	}

	public int getQualifiedAwardLegsCount() {
		return qualifiedAwardLegsCount;
	}

	public void setQualifiedAwardLegsCount(int qualifiedAwardLegsCount) {
		this.qualifiedAwardLegsCount = qualifiedAwardLegsCount;
	}
}
