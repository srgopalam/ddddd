package com.amway.domain.include;

import java.io.Serializable;
import java.util.Objects;

public class VolumeDetails implements Serializable {

	private static final long serialVersionUID = -602265779088046459L;
	private int bonusPercent;
	private int leadershipPercent;
	private int nextPercentage;
	private int nextVolume;
	private PVBVSummary affAboPvBv;
	private PVBVSummary affPvBv;
	private PVBVSummary aboPvBv;

	public VolumeDetails() {
		super();
	}

	public int getBonusPercent() {
		return bonusPercent;
	}

	public void setBonusPercent(int bonusPercent) {
		this.bonusPercent = bonusPercent;
	}

	public int getLeadershipPercent() {
		return leadershipPercent;
	}

	public void setLeadershipPercent(int leadershipPercent) {
		this.leadershipPercent = leadershipPercent;
	}

	public int getNextPercentage() {
		return nextPercentage;
	}

	public void setNextPercentage(int nextPercentage) {
		this.nextPercentage = nextPercentage;
	}

	public int getNextVolume() {
		return nextVolume;
	}

	public void setNextVolume(int nextVolume) {
		this.nextVolume = nextVolume;
	}

	public PVBVSummary getAffAboPvBv() {
		return affAboPvBv;
	}

	public void setAffAboPvBv(PVBVSummary affAboPvBv) {
		this.affAboPvBv = affAboPvBv;
	}

	public PVBVSummary getAffPvBv() {
		return affPvBv;
	}

	public void setAffPvBv(PVBVSummary affPvBv) {
		this.affPvBv = affPvBv;
	}

	public PVBVSummary getAboPvBv() {
		return aboPvBv;
	}

	public void setAboPvBv(PVBVSummary aboPvBv) {
		this.aboPvBv = aboPvBv;
	}

	@Override
	public int hashCode() {
		return Objects.hash(aboPvBv, affAboPvBv, affPvBv, bonusPercent, leadershipPercent, nextPercentage, nextVolume);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof VolumeDetails)) {
			return false;
		}
		VolumeDetails other = (VolumeDetails) obj;
		return Objects.equals(aboPvBv, other.aboPvBv) && Objects.equals(affAboPvBv, other.affAboPvBv)
				&& Objects.equals(affPvBv, other.affPvBv) && bonusPercent == other.bonusPercent
				&& leadershipPercent == other.leadershipPercent && nextPercentage == other.nextPercentage
				&& nextVolume == other.nextVolume;
	}

}
