package com.amway.domain.include;

import java.io.Serializable;

public class AboAttributes implements Serializable {
	private static final long serialVersionUID = -2703730489838343574L;
	private String status;
	private String segment;
	private String aboName;
	private String aboLocalName;
	private int country;
	private String isoCountry;
	private String isoLanguage;
	private boolean privacyFlag;
	private String birthDate;
	private String entryDate;
	private String expireDate;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

	public String getAboName() {
		return aboName;
	}

	public void setAboName(String aboName) {
		this.aboName = aboName;
	}

	public String getAboLocalName() {
		return aboLocalName;
	}

	public void setAboLocalName(String aboLocalName) {
		this.aboLocalName = aboLocalName;
	}

	public int getCountry() {
		return country;
	}

	public void setCountry(int country) {
		this.country = country;
	}

	public boolean isPrivacyFlag() {
		return privacyFlag;
	}

	public void setPrivacyFlag(boolean privacyFlag) {
		this.privacyFlag = privacyFlag;
	}

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}

	public String getIsoLanguage() {
		return isoLanguage;
	}

	public void setIsoLanguage(String isoLanguage) {
		this.isoLanguage = isoLanguage;
	}

	public String getIsoCountry() {
		return isoCountry;
	}

	public void setIsoCountry(String isoCountry) {
		this.isoCountry = isoCountry;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
}
