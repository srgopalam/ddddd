package com.amway.domain;

public class CustomerData {
	private int reqAff;
	private long reqAbo;
	private int aff;
	private long abo;
	private long customerId;
	private int businessEntity;
	private boolean isGlossPeriod;

	public int getReqAff() {
		return reqAff;
	}

	public void setReqAff(int reqAff) {
		this.reqAff = reqAff;
	}

	public long getReqAbo() {
		return reqAbo;
	}

	public void setReqAbo(long reqAbo) {
		this.reqAbo = reqAbo;
	}

	public int getAff() {
		return aff;
	}

	public void setAff(int aff) {
		this.aff = aff;
	}

	public long getAbo() {
		return abo;
	}

	public void setAbo(long abo) {
		this.abo = abo;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public int getBusinessEntity() {
		return businessEntity;
	}

	public void setBusinessEntity(int businessEntity) {
		this.businessEntity = businessEntity;
	}

	public boolean isGlossPeriod() {
		return isGlossPeriod;
	}

	public void setGlossPeriod(boolean isGlossPeriod) {
		this.isGlossPeriod = isGlossPeriod;
	}
}