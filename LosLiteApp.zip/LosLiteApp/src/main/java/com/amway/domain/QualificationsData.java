package com.amway.domain;

public class QualificationsData {

	private String qualStatus;
	private String qualMethod;
	private String qualOverrideMethod;
	private int downlineQualQty;

	public QualificationsData(String qualStatus, String qualMethod, String qualOverrideMethod, int downlineQualQty) {
		super();
		this.qualStatus = qualStatus;
		this.qualMethod = qualMethod;
		this.qualOverrideMethod = qualOverrideMethod;
		this.downlineQualQty = downlineQualQty;
	}

	public String getQualStatus() {
		return qualStatus;
	}

	public void setQualStatus(String qualStatus) {
		this.qualStatus = qualStatus;
	}

	public String getQualMethod() {
		return qualMethod;
	}

	public void setQualMethod(String qualMethod) {
		this.qualMethod = qualMethod;
	}

	public String getQualOverrideMethod() {
		return qualOverrideMethod;
	}

	public void setQualOverrideMethod(String qualOverrideMethod) {
		this.qualOverrideMethod = qualOverrideMethod;
	}

	public int getDownlineQualQty() {
		return downlineQualQty;
	}

	public void setDownlineQualQty(int downlineQualQty) {
		this.downlineQualQty = downlineQualQty;
	}

}
