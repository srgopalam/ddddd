package com.amway.domain;

public class AwardLevelData {

	private long bonusCustomerId;
	private int currentAward;
	private int currentQualificationPeriod;
	private int highestAward;
	private int highestQualificationPeriod;
	private int garAward;
	private int garQualificationPeriod;

	public long getBonusCustomerId() {
		return bonusCustomerId;
	}

	public void setBonusCustomerId(long bonusCustomerId) {
		this.bonusCustomerId = bonusCustomerId;
	}

	public int getCurrentAward() {
		return currentAward;
	}

	public void setCurrentAward(int currentAward) {
		this.currentAward = currentAward;
	}

	public int getCurrentQualificationPeriod() {
		return currentQualificationPeriod;
	}

	public void setCurrentQualificationPeriod(int currentQualificationPeriod) {
		this.currentQualificationPeriod = currentQualificationPeriod;
	}

	public int getHighestAward() {
		return highestAward;
	}

	public void setHighestAward(int highestAward) {
		this.highestAward = highestAward;
	}

	public int getHighestQualificationPeriod() {
		return highestQualificationPeriod;
	}

	public void setHighestQualificationPeriod(int highestQualificationPeriod) {
		this.highestQualificationPeriod = highestQualificationPeriod;
	}

	public int getGarAward() {
		return garAward;
	}

	public void setGarAward(int garAward) {
		this.garAward = garAward;
	}

	public int getGarQualificationPeriod() {
		return garQualificationPeriod;
	}

	public void setGarQualificationPeriod(int garQualificationPeriod) {
		this.garQualificationPeriod = garQualificationPeriod;
	}

}
