package com.amway.domain.list;

import java.io.Serializable;
import java.util.List;

import com.amway.domain.include.AboAttributes;
import com.amway.domain.include.AwardLevelDetail;
import com.amway.domain.include.QualCounts;
import com.amway.domain.include.SponsoringStats;
import com.amway.domain.include.UplineInfo;
import com.amway.domain.include.VolumeDetails;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class Details implements Serializable {
	private static final long serialVersionUID = -4601825216927733863L;
	private int aff;
	private long abo;
	private long sponsorAbo;
	@JsonIgnore
	private long bonusCustomerId;
	@JsonIgnore
	private long sponsorCustomerId;
	@JsonIgnore
	private int businessEntity;
	private String losType;
	@JsonInclude(Include.NON_NULL)
	private Boolean hasDownlines;
	private String segmentCode;
	@JsonInclude(Include.NON_NULL)
	private String businessNature;
	@JsonInclude(Include.NON_NULL)
	private String status;
	@JsonInclude(Include.NON_NULL)
	private Boolean hasRework;
	@JsonInclude(Include.NON_NULL)
	private Boolean hasTopup;
	@JsonInclude(Include.NON_NULL)
	private Boolean hasReturns;
	@JsonInclude(Include.NON_NULL)
	private Boolean hasReworkImpact;
	@JsonInclude(Include.NON_NULL)
	private VolumeDetails volumeDetails;
	@JsonInclude(Include.NON_NULL)
	private AwardLevelDetail awardLevelDetail;
	@JsonInclude(Include.NON_NULL)
	private QualCounts qualCounts;
	@JsonInclude(Include.NON_NULL)
	private SponsoringStats sponsoringStats;
	@JsonInclude(Include.NON_NULL)
	private AboAttributes aboAttributes;
	@JsonInclude(Include.NON_NULL)
	private List<Details> downlines;
	@JsonInclude(Include.NON_NULL)
	private UplineInfo uplineInfo;

	public int getAff() {
		return aff;
	}

	public void setAff(int aff) {
		this.aff = aff;
	}

	public long getAbo() {
		return abo;
	}

	public void setAbo(long abo) {
		this.abo = abo;
	}

	public long getSponsorAbo() {
		return sponsorAbo;
	}

	public void setSponsorAbo(long sponsorAbo) {
		this.sponsorAbo = sponsorAbo;
	}

	public long getBonusCustomerId() {
		return bonusCustomerId;
	}

	public void setBonusCustomerId(long bonusCustomerId) {
		this.bonusCustomerId = bonusCustomerId;
	}

	public long getSponsorCustomerId() {
		return sponsorCustomerId;
	}

	public void setSponsorCustomerId(long sponsorCustomerId) {
		this.sponsorCustomerId = sponsorCustomerId;
	}

	public int getBusinessEntity() {
		return businessEntity;
	}

	public void setBusinessEntity(int businessEntity) {
		this.businessEntity = businessEntity;
	}

	public String getLosType() {
		return losType;
	}

	public void setLosType(String losType) {
		this.losType = losType;
	}

	public String getSegmentCode() {
		return segmentCode;
	}

	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	public String getBusinessNature() {
		return businessNature;
	}

	public void setBusinessNature(String businessNature) {
		this.businessNature = businessNature;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public VolumeDetails getVolumeDetails() {
		return volumeDetails;
	}

	public void setVolumeDetails(VolumeDetails volumeDetails) {
		this.volumeDetails = volumeDetails;
	}

	public AwardLevelDetail getAwardLevelDetail() {
		return awardLevelDetail;
	}

	public void setAwardLevelDetail(AwardLevelDetail awardLevelDetail) {
		this.awardLevelDetail = awardLevelDetail;
	}

	public QualCounts getQualCounts() {
		return qualCounts;
	}

	public void setQualCounts(QualCounts qualCounts) {
		this.qualCounts = qualCounts;
	}

	public SponsoringStats getSponsoringStats() {
		return sponsoringStats;
	}

	public void setSponsoringStats(SponsoringStats sponsoringStats) {
		this.sponsoringStats = sponsoringStats;
	}

	public AboAttributes getAboAttributes() {
		return aboAttributes;
	}

	public void setAboAttributes(AboAttributes aboAttributes) {
		this.aboAttributes = aboAttributes;
	}

	public List<Details> getDownlines() {
		return downlines;
	}

	public void setDownlines(List<Details> downlines) {
		this.downlines = downlines;
	}

	public UplineInfo getUplineInfo() {
		return uplineInfo;
	}

	public void setUplineInfo(UplineInfo uplineInfo) {
		this.uplineInfo = uplineInfo;
	}

	public Boolean getHasRework() {
		return hasRework;
	}

	public void setHasRework(Boolean hasRework) {
		this.hasRework = hasRework;
	}

	public Boolean getHasTopup() {
		return hasTopup;
	}

	public void setHasTopup(Boolean hasTopup) {
		this.hasTopup = hasTopup;
	}

	public Boolean getHasReturns() {
		return hasReturns;
	}

	public void setHasReturns(Boolean hasReturns) {
		this.hasReturns = hasReturns;
	}

	public Boolean getHasReworkImpact() {
		return hasReworkImpact;
	}

	public void setHasReworkImpact(Boolean hasReworkImpact) {
		this.hasReworkImpact = hasReworkImpact;
	}

	public Boolean getHasDownlines() {
		return hasDownlines;
	}

	public void setHasDownlines(Boolean hasDownlines) {
		this.hasDownlines = hasDownlines;
	}
}
