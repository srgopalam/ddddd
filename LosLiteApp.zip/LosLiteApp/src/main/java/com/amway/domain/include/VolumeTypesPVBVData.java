package com.amway.domain.include;

import java.io.Serializable;
import java.math.BigDecimal;

public class VolumeTypesPVBVData implements Serializable {
	private static final long serialVersionUID = 4825126209470783492L;
	private String volumeTypeCode;
	private BigDecimal pv;
	private BigDecimal ytdPvTotal;
	private BigDecimal bv;

	public VolumeTypesPVBVData() {
		super();
	}

	public String getVolumeTypeCode() {
		return volumeTypeCode;
	}

	public void setVolumeTypeCode(String volumeTypeCode) {
		this.volumeTypeCode = volumeTypeCode;
	}

	public BigDecimal getPv() {
		return pv;
	}

	public void setPv(BigDecimal pv) {
		this.pv = pv;
	}

	public BigDecimal getYtdPvTotal() {
		return ytdPvTotal;
	}

	public void setYtdPvTotal(BigDecimal ytdPvTotal) {
		this.ytdPvTotal = ytdPvTotal;
	}

	public BigDecimal getBv() {
		return bv;
	}

	public void setBv(BigDecimal bv) {
		this.bv = bv;
	}

	@Override
	public String toString() {
		return String.format("VolumeTypesPVBVData [volumeTypeCode=%s, pv=%s, ytdPvTotal=%s, bv=%s]", volumeTypeCode, pv,
				ytdPvTotal, bv);
	}

}
