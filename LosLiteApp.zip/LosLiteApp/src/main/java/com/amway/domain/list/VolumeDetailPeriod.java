package com.amway.domain.list;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class VolumeDetailPeriod implements Serializable {

	private static final long serialVersionUID = -3703628901821298962L;
	private int aff;
	private long abo;
	private int period;
	private int httpStatus;
	@JsonInclude(Include.NON_NULL)
	private List<Details> details;
	@JsonInclude(Include.NON_NULL)
	private Details detail;

	public Details getDetail() {
		return detail;
	}

	public void setDetail(Details detail) {
		this.detail = detail;
	}

	public int getAff() {
		return aff;
	}

	public void setAff(int aff) {
		this.aff = aff;
	}

	public long getAbo() {
		return abo;
	}

	public void setAbo(long abo) {
		this.abo = abo;
	}

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public int getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(int httpStatus) {
		this.httpStatus = httpStatus;
	}

	public List<Details> getDetails() {
		return details;
	}

	public void setDetails(List<Details> details) {
		this.details = details;
	}

}
