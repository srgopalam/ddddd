package com.amway.domain.include;

import java.io.Serializable;
import java.util.Objects;

public class UplineInfo implements Serializable {

	private static final long serialVersionUID = 9217296433081840731L;
	private long platinumSponsor;
	private int intlSponAff;
	private long intlSponAbo;
	private String intlSponName;
	private String intlSponCountry;
	private String intlSponsorType;

	public UplineInfo() {
		super();
	}

	public long getPlatinumSponsor() {
		return platinumSponsor;
	}

	public void setPlatinumSponsor(long platinumSponsor) {
		this.platinumSponsor = platinumSponsor;
	}

	public int getIntlSponAff() {
		return intlSponAff;
	}

	public void setIntlSponAff(int intlSponAff) {
		this.intlSponAff = intlSponAff;
	}

	public long getIntlSponAbo() {
		return intlSponAbo;
	}

	public void setIntlSponAbo(long intlSponAbo) {
		this.intlSponAbo = intlSponAbo;
	}

	public String getIntlSponName() {
		return intlSponName;
	}

	public void setIntlSponName(String intlSponName) {
		this.intlSponName = intlSponName;
	}

	public String getIntlSponCountry() {
		return intlSponCountry;
	}

	public void setIntlSponCountry(String intlSponCountry) {
		this.intlSponCountry = intlSponCountry;
	}

	public String getIntlSponsorType() {
		return intlSponsorType;
	}

	public void setIntlSponsorType(String intlSponsorType) {
		this.intlSponsorType = intlSponsorType;
	}

	@Override
	public String toString() {
		return "UplineInfo [platinumSponsor=" + platinumSponsor + ", intlSponAff=" + intlSponAff + ", intlSponAbo="
				+ intlSponAbo + ", intlSponName=" + intlSponName + ", intlSponCountry=" + intlSponCountry
				+ ", intlSponsorType=" + intlSponsorType + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(intlSponAbo, intlSponAff, intlSponCountry, intlSponName, intlSponsorType, platinumSponsor);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof UplineInfo)) {
			return false;
		}
		UplineInfo other = (UplineInfo) obj;
		return intlSponAbo == other.intlSponAbo && intlSponAff == other.intlSponAff
				&& Objects.equals(intlSponCountry, other.intlSponCountry)
				&& Objects.equals(intlSponName, other.intlSponName)
				&& Objects.equals(intlSponsorType, other.intlSponsorType) && platinumSponsor == other.platinumSponsor;
	}
}
