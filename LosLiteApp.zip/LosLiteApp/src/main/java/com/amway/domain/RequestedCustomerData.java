package com.amway.domain;

import java.util.List;

public class RequestedCustomerData {
	private int period;
	private List<CustomerData> customerData;

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public List<CustomerData> getCustomerData() {
		return customerData;
	}

	public void setCustomerData(List<CustomerData> customerData) {
		this.customerData = customerData;
	}

}