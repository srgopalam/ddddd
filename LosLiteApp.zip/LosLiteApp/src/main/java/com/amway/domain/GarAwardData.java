package com.amway.domain;

public class GarAwardData {
	private long bonusCustomerId;
	private int awardNumber;
	private int period;

	public long getBonusCustomerId() {
		return bonusCustomerId;
	}

	public void setBonusCustomerId(long bonusCustomerId) {
		this.bonusCustomerId = bonusCustomerId;
	}

	public int getAwardNumber() {
		return awardNumber;
	}

	public void setAwardNumber(int awardNumber) {
		this.awardNumber = awardNumber;
	}

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}
}
