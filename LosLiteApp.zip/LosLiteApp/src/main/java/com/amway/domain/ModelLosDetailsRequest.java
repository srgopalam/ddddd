package com.amway.domain;

import java.util.Set;

import org.springframework.stereotype.Component;

/**
 * @author Sreenivasa Gopalam
 */
@Component
public class ModelLosDetailsRequest {
	private Set<AffAbo> affAbos;
	private Set<Integer> periods;
	private Set<String> businessNatures;
	private Set<String> volumeTypes;
	private boolean includeInactive;
	private boolean includeInternational;
	private boolean includeGlobalMB;
	private boolean includeMap;
	private boolean asList;
	private boolean includeFrontline;
	private boolean includeAboAttr;
	private boolean includeVolumeDetails;
	private boolean includeAwardLevels;
	private boolean includeQualCount;
	private boolean includeSponStats;
	private boolean showBusinessNatureProperty;
	private boolean includeUpline;
	private boolean includeYTDpv;
	private boolean includeHasDownlineFlag;
	private int reqAff;
	private long reqAbo;

	public ModelLosDetailsRequest() {
		super();
	}

	public ModelLosDetailsRequest(int reqAff, long reqAbo, Set<AffAbo> affAbos, Set<Integer> periods,
			Set<String> businessNatures, Set<String> volumeTypes, boolean includeInactive, boolean includeInternational,
			boolean includeGlobalMB, boolean includeMap, boolean asList, boolean includeFrontline,
			boolean includeAboAttr, boolean includeVolumeDetails, boolean includeAwardLevels, boolean includeQualCount,
			boolean includeSponStats, boolean includeUpline, boolean includeYTDpv, boolean includeHasDownlineFlag) {
		super();
		this.reqAff = reqAff;
		this.reqAbo = reqAbo;
		this.affAbos = affAbos;
		this.periods = periods;
		this.businessNatures = businessNatures;
		this.volumeTypes = volumeTypes;
		this.includeInactive = includeInactive;
		this.includeInternational = includeInternational;
		this.includeGlobalMB = includeGlobalMB;
		this.includeMap = includeMap;
		this.asList = asList;
		this.includeFrontline = includeFrontline;
		this.includeAboAttr = includeAboAttr;
		this.includeVolumeDetails = includeVolumeDetails;
		this.includeAwardLevels = includeAwardLevels;
		this.includeQualCount = includeQualCount;
		this.includeSponStats = includeSponStats;
		this.includeUpline = includeUpline;
		this.includeYTDpv = includeYTDpv;
		this.setIncludeHasDownlineFlag(includeHasDownlineFlag);
	}

	public int getReqAff() {
		return reqAff;
	}

	public void setReqAff(int reqAff) {
		this.reqAff = reqAff;
	}

	public long getReqAbo() {
		return reqAbo;
	}

	public void setReqAbo(long reqAbo) {
		this.reqAbo = reqAbo;
	}

	public Set<AffAbo> getAffAbos() {
		return affAbos;
	}

	public void setAffAbos(Set<AffAbo> affAbos) {
		this.affAbos = affAbos;
	}

	public Set<Integer> getPeriods() {
		return periods;
	}

	public void setPeriods(Set<Integer> periods) {
		this.periods = periods;
	}

	public Set<String> getBusinessNatures() {
		return businessNatures;
	}

	public void setBusinessNatures(Set<String> businessNatures) {
		this.businessNatures = businessNatures;
	}

	public Set<String> getVolumeTypes() {
		return volumeTypes;
	}

	public void setVolumeTypes(Set<String> volumeTypes) {
		this.volumeTypes = volumeTypes;
	}

	public boolean isIncludeInactive() {
		return includeInactive;
	}

	public void setIncludeInactive(boolean includeInactive) {
		this.includeInactive = includeInactive;
	}

	public boolean isIncludeInternational() {
		return includeInternational;
	}

	public void setIncludeInternational(boolean includeInternational) {
		this.includeInternational = includeInternational;
	}

	public boolean isIncludeGlobalMB() {
		return includeGlobalMB;
	}

	public void setIncludeGlobalMB(boolean includeGlobalMB) {
		this.includeGlobalMB = includeGlobalMB;
	}

	public boolean isIncludeMap() {
		return includeMap;
	}

	public void setIncludeMap(boolean includeMap) {
		this.includeMap = includeMap;
	}

	public boolean isAsList() {
		return asList;
	}

	public void setAsList(boolean asList) {
		this.asList = asList;
	}

	public boolean isIncludeFrontline() {
		return includeFrontline;
	}

	public void setIncludeFrontline(boolean includeFrontline) {
		this.includeFrontline = includeFrontline;
	}

	public boolean isIncludeAboAttr() {
		return includeAboAttr;
	}

	public void setIncludeAboAttr(boolean includeAboAttr) {
		this.includeAboAttr = includeAboAttr;
	}

	public boolean isIncludeVolumeDetails() {
		return includeVolumeDetails;
	}

	public void setIncludeVolumeDetails(boolean includeVolumeDetails) {
		this.includeVolumeDetails = includeVolumeDetails;
	}

	public boolean isIncludeAwardLevels() {
		return includeAwardLevels;
	}

	public void setIncludeAwardLevels(boolean includeAwardLevels) {
		this.includeAwardLevels = includeAwardLevels;
	}

	public boolean isIncludeQualCount() {
		return includeQualCount;
	}

	public void setIncludeQualCount(boolean includeQualCount) {
		this.includeQualCount = includeQualCount;
	}

	public boolean isIncludeSponStats() {
		return includeSponStats;
	}

	public void setIncludeSponStats(boolean includeSponStats) {
		this.includeSponStats = includeSponStats;
	}

	public boolean isShowBusinessNatureProperty() {
		return showBusinessNatureProperty;
	}

	public void setShowBusinessNatureProperty(boolean showBusinessNatureProperty) {
		this.showBusinessNatureProperty = showBusinessNatureProperty;
	}

	public void setIncludeUpline(boolean includeUpline) {
		this.includeUpline = includeUpline;
	}

	public boolean isIncludeUpline() {
		return this.includeUpline;
	}

	public boolean isIncludeYTDpv() {
		return includeYTDpv;
	}

	public void setIncludeYTDpv(boolean includeYTDpv) {
		this.includeYTDpv = includeYTDpv;
	}

	public boolean isIncludeHasDownlineFlag() {
		return includeHasDownlineFlag;
	}

	public void setIncludeHasDownlineFlag(boolean includeHasDownlineFlag) {
		this.includeHasDownlineFlag = includeHasDownlineFlag;
	}
}
