package com.amway.service;

import com.amway.api.rest.VolumeAsyncController;
import com.amway.dao.AboAttributesDao;
import com.amway.dao.BlockPrivilegesDao;
import com.amway.dao.BonusExchangeRate;
import com.amway.dao.BusinessEntity;
import com.amway.dao.SysRuleAffParamsDao;
import com.amway.dao.UplineInfoDao;
import com.amway.domain.CustomerData;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.domain.list.Details;
import com.amway.helper.AboAttributesHelper;
import com.amway.helper.AwardLevelHelper;
import com.amway.helper.PVBVHelper;
import com.amway.helper.QualCountsHelper;
import com.amway.helper.SponStatsHelper;
import com.amway.helper.UplineHelper;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class MethodAsyncService {
	private static final Logger LOGGER = LoggerFactory.getLogger(MethodAsyncService.class);
	@Autowired
	private VolumeAsyncController volumeAsyncController;

	@Autowired
	private BusinessEntity businessEntity;

	@Autowired
	private BonusExchangeRate bonusExchangeRate;

	@Autowired
	private AboAttributesDao aboAttrDao;

	@Autowired
	private BlockPrivilegesDao blockPrivilegesDao;

	@Autowired
	private SysRuleAffParamsDao sysRuleAffParamDao;

	@Autowired
	private UplineInfoDao uplineInfoDao;

	@Autowired
	private CaffeineCacheService caffeineCacheService;

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Async
	public CompletableFuture<Void> includeAboAttr(CustomerData customerData, int period,
			List<Details> listDetails, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		long s = System.currentTimeMillis();
		AboAttributesHelper aboAttrHelper = new AboAttributesHelper();
		aboAttrHelper.mapAboAttributes(customerData, period, listDetails, aboAttrDao, blockPrivilegesDao,
				sysRuleAffParamDao, namedParameterJdbcTemplate, businessEntity, caffeineCacheService);
		LOGGER.info("includeAboAttr: {}", (s - System.currentTimeMillis()));
		return CompletableFuture.completedFuture(null);
	}

	@Async
	public CompletableFuture<Void> includeUpline(int period, List<Details> listDetails) {
		long s = System.currentTimeMillis();
		UplineHelper uplineHelper = new UplineHelper();
		uplineHelper.mapUplineInfo(period, listDetails, uplineInfoDao, caffeineCacheService);
		LOGGER.info("includeUpline: {}", (s - System.currentTimeMillis()));
		return CompletableFuture.completedFuture(null);
	}

	@Async
	public CompletableFuture<Void> includeHasDownlineFlag(CustomerData customerData,
			ModelLosDetailsRequest modelLosDetailsRequest, int period, List<String> customerStatusCodes,
			List<Details> listDetails, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		long s = System.currentTimeMillis();
		Set<String> businessNatures = modelLosDetailsRequest.getBusinessNatures();
		UplineHelper uplineHelper = new UplineHelper();
		uplineHelper.mapHasDownlineFlags(customerData.getAff(), period, customerStatusCodes, businessNatures,
				namedParameterJdbcTemplate, listDetails, uplineInfoDao, caffeineCacheService);
		LOGGER.info("includeHasDownlineFlag: {}", (s - System.currentTimeMillis()));
		return CompletableFuture.completedFuture(null);
	}

	@Async
	public CompletableFuture<Void> includeHasDownlineFlagIntl(
			ModelLosDetailsRequest modelLosDetailsRequest, int period, List<String> customerStatusCodes,
			List<Details> listDetails, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		long s = System.currentTimeMillis();
		Set<String> businessNatures = modelLosDetailsRequest.getBusinessNatures();
		UplineHelper uplineHelper = new UplineHelper();
		uplineHelper.mapHasDownlineFlagsIntl(period, customerStatusCodes, businessNatures,
				namedParameterJdbcTemplate, listDetails, uplineInfoDao);
		LOGGER.info("includeHasDownlineFlagIntl: {}", (s - System.currentTimeMillis()));
		return CompletableFuture.completedFuture(null);
	}

	@Async
	public CompletableFuture<Void> includeVolumeDetails(CustomerData customerData,
			ModelLosDetailsRequest modelLosDetailsRequest, int period, List<Details> listDetails,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		long s = System.currentTimeMillis();
		new PVBVHelper().mapVolumeDetails(customerData, modelLosDetailsRequest, period, listDetails,
				caffeineCacheService, volumeAsyncController, businessEntity, bonusExchangeRate,
				namedParameterJdbcTemplate);
		LOGGER.info("includeVolumeDetails: {}", (s - System.currentTimeMillis()));
		return CompletableFuture.completedFuture(null);
	}

	@Async
	public CompletableFuture<Void> includeAwardLevels(int period, List<Details> listDetails,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		long s = System.currentTimeMillis();
		new AwardLevelHelper().mapAwardLevelDetails(period, listDetails, caffeineCacheService,
				namedParameterJdbcTemplate);
		LOGGER.info("includeAwardLevels: {}", (s - System.currentTimeMillis()));
		return CompletableFuture.completedFuture(null);
	}

	@Async
	public CompletableFuture<Void> includeQualCount(int period, List<Details> listDetails,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		long s = System.currentTimeMillis();
		QualCountsHelper qHelper = new QualCountsHelper();
		qHelper.mapQualCountDetails(period, listDetails, namedParameterJdbcTemplate);
		qHelper.mapQualifiedAwardLegCounts(period, listDetails, namedParameterJdbcTemplate);
		qHelper.mapIntlQualifiedLegCounts(period, listDetails, jdbcTemplate, caffeineCacheService);
		LOGGER.info("includeQualCount: {}", (s - System.currentTimeMillis()));
		return CompletableFuture.completedFuture(null);
	}

	@Async
	public CompletableFuture<Void> includeSponStats(CustomerData customerData,
			ModelLosDetailsRequest modelLosDetailsRequest, int period, List<Details> listDetails,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		long s = System.currentTimeMillis();
		SponStatsHelper sponStatsHelper = new SponStatsHelper();
		Set<String> businessNatures = modelLosDetailsRequest.getBusinessNatures();
		int losBuildPeriod = caffeineCacheService.getLosBuildPeriodsByAffiliates().get(customerData.getAff());
		int affCurrPeriod = caffeineCacheService.getCurrentBnsPeriodsByAffiliates().get(customerData.getAff());
		if (period >= affCurrPeriod) {
			period = losBuildPeriod;
		}
		sponStatsHelper.mapGroupCounts(period, listDetails, businessNatures, namedParameterJdbcTemplate);
		LOGGER.info("includeSponStats: {}", (s - System.currentTimeMillis()));
		return CompletableFuture.completedFuture(null);
	}

}