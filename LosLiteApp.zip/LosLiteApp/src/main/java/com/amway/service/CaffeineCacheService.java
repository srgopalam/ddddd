package com.amway.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.amway.config.CaffeineCacheable;
import com.amway.dao.cache.ListCache;
import com.amway.dao.cache.MapCache;
import com.amway.model.AffiliateMasterData;
import com.amway.model.BonusAwardMaster;
import com.amway.model.VolumeTypeMasterData;

@Service
@CaffeineCacheable
public class CaffeineCacheService {
	private static final Logger LOGGER = LoggerFactory.getLogger(CaffeineCacheService.class);
	@Autowired
	private ListCache listCache;
	@Autowired
	private MapCache mapCache;

	@Cacheable(value = "local-cache")
	public Map<Integer, Integer> getLosBuildPeriodsByAffiliates() {
		LOGGER.info("Cache is not being used for getLosBuildPeriodsByAffiliates!");
		return listCache.getLosBuildPeriodsByAffiliates();
	}

	@Cacheable(value = "local-cache")
	public Map<Integer, Integer> getCurrentBnsPeriodsByAffiliates() {
		LOGGER.info("Cache is not being used for getCurrentBnsPeriodsByAffiliates!");
		return listCache.getCurrentBnsPeriodsByAffiliates();
	}

	@Cacheable(value = "local-cache")
	public List<Integer> getAllAffiliates() {
		LOGGER.info("Cache is not being used for getAllAffiliates!");
		return listCache.getAllAffiliates();
	}

	@Cacheable(value = "local-cache")
	public List<Long> getExclusableCustomers() {
		LOGGER.info("Cache is not being used for getExclusableCustomers!");
		return listCache.getExclusableCustomers();
	}

	@Cacheable(value = "local-cache")
	public List<BonusAwardMaster> getAllBonusAwards() {
		LOGGER.info("Cache is not being used for getAllBonusAwards!");
		return listCache.getAllBonusAwards();
	}

	@Cacheable(value = "local-cache")
	public Map<String, VolumeTypeMasterData> getAllVolumeTypesData() {
		LOGGER.info("Cache is not being used for getAllVolumeTypesData!");
		return listCache.getAllVolumeTypesData();
	}

	@Cacheable(value = "local-cache")
	public Map<Integer, AffiliateMasterData> getAllAffiliatesDataMap() {
		LOGGER.info("Cache is not being used for getAllAffiliatesDataMap!");
		return mapCache.getAllAffiliatesDataMap();
	}

	@Cacheable(value = "local-cache")
	public Map<Integer, BonusAwardMaster> getAllBonusAwardsMap() {
		LOGGER.info("Cache is not being used for getAllBonusAwardsMap!");
		return mapCache.getAllBonusAwardsMap();
	}

	@Cacheable(value = "local-cache")
	public List<String> getAllVolumeTypeCodes() {
		LOGGER.info("Cache is not being used for getAllVolumeTypeCodes!");
		return listCache.getAllVolumeTypeCodes();
	}

	@Cacheable(value = "local-cache")
	public List<String> getAllBusinessNatureCodes() {
		LOGGER.info("Cache is not being used for getAllBusinessNatureCodes!");
		return listCache.getAllBusinessNatureCodes();
	}

	@CacheEvict(value = "local-cache", allEntries = true)
	public void clear() {
		// clears all lookup cache
	}
}
