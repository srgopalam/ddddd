package com.amway.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.amway.dao.cache.ListCache;
import com.amway.dao.cache.MapCache;
import com.amway.model.AffiliateMasterData;
import com.amway.model.BonusAwardMaster;
import com.amway.model.VolumeTypeMasterData;

@Service
public class CacheService {
	private static final Logger LOGGER = LoggerFactory.getLogger(CacheService.class);
	@Autowired
	private ListCache listCache;
	@Autowired
	private MapCache mapCache;
	@Value("${cache.enabled:false}")
	private boolean cacheEnabled;

	public boolean isCacheEnabled() {
		return cacheEnabled;
	}

	@Cacheable(value = "losAppLookupMap", keyGenerator = "keyGenerator", condition = "#cacheEnabled")
	public List<Integer> getAllAffiliates(boolean cacheEnabled) {
		LOGGER.info("Cache is not being used for getAllAffiliates!");
		return listCache.getAllAffiliates();
	}

	@Cacheable(value = "losAppLookupMap", keyGenerator = "keyGenerator", condition = "#cacheEnabled")
	public List<String> getAllVolumeTypeCodes(boolean cacheEnabled) {
		LOGGER.info("Cache is not being used for getAllVolumeTypeCodes!");
		return listCache.getAllVolumeTypeCodes();
	}

	@Cacheable(value = "losAppLookupMap", keyGenerator = "keyGenerator", condition = "#cacheEnabled")
	public List<String> getAllBusinessNatureCodes(boolean cacheEnabled) {
		LOGGER.info("Cache is not being used for getAllBusinessNatureCodes!");
		return listCache.getAllBusinessNatureCodes();
	}

	@Cacheable(value = "losAppLookupMap", keyGenerator = "keyGenerator", condition = "#cacheEnabled")
	public List<BonusAwardMaster> getAllBonusAwards(boolean cacheEnabled) {
		LOGGER.info("Cache is not being used for getAllBonusAwards!");
		return listCache.getAllBonusAwards();
	}

	@Cacheable(value = "losAppLookupMap", keyGenerator = "keyGenerator", condition = "#cacheEnabled")
	public Map<Integer, Integer> getLosBuildPeriodsByAffiliates(boolean cacheEnabled) {
		LOGGER.info("Cache is not being used for getLosBuildPeriodsByAffiliates!");
		return listCache.getLosBuildPeriodsByAffiliates();
	}

	@Cacheable(value = "losAppLookupMap", keyGenerator = "keyGenerator", condition = "#cacheEnabled")
	public Map<Integer, Integer> getCurrentBnsPeriodsByAffiliates(boolean cacheEnabled) {
		LOGGER.info("Cache is not being used for getCurrentBnsPeriodsByAffiliates!");
		return listCache.getCurrentBnsPeriodsByAffiliates();
	}

	@Cacheable(value = "losAppLookupMap", keyGenerator = "keyGenerator", condition = "#cacheEnabled")
	public Map<String, VolumeTypeMasterData> getAllVolumeTypesData(boolean cacheEnabled) {
		LOGGER.info("Cache is not being used for getAllVolumeTypesData!");
		return listCache.getAllVolumeTypesData();
	}

	@Cacheable(value = "losAppLookupMap", keyGenerator = "keyGenerator", condition = "#cacheEnabled")
	public Map<Integer, BonusAwardMaster> getAllBonusAwardsMap(boolean cacheEnabled) {
		LOGGER.info("Cache is not being used for getAllBonusAwardsMap!");
		return mapCache.getAllBonusAwardsMap();
	}

	@Cacheable(value = "losAppLookupMap", keyGenerator = "keyGenerator", condition = "#cacheEnabled")
	public Map<Integer, AffiliateMasterData> getAllAffiliatesDataMap(boolean cacheEnabled) {
		LOGGER.info("Cache is not being used for getAllAffiliatesDataMap!");
		return mapCache.getAllAffiliatesDataMap();
	}

	@Cacheable(value = "losAppLookupMap", keyGenerator = "keyGenerator", condition = "#cacheEnabled")
	public List<Long> getExclusableCustomers(boolean cacheEnabled) {
		LOGGER.info("Cache is not being used for getExclusableCustomers!");
		return listCache.getExclusableCustomers();
	}

	@CacheEvict(value = "losAppLookupMap", keyGenerator = "keyGenerator", allEntries = true)
	public void clear(boolean cacheEnabled) {
		// clears all lookup cache
	}

	@CacheEvict(value = "losAppResponseMap", keyGenerator = "keyGeneratorForEndPoint", allEntries = true)
	public void clearResponseMap(boolean cacheEnabled) {
		// clears all response cache
	}
}
