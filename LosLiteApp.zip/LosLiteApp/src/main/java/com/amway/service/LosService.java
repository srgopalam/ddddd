package com.amway.service;

import static com.amway.util.CurrentPeriodHelper.shouldWeGetDataFromGloss;
import static java.util.concurrent.CompletableFuture.supplyAsync;

import com.amway.dao.BonusCustomer;
import com.amway.dao.DetailImpl;
import com.amway.domain.AffAbo;
import com.amway.domain.CustomerData;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.domain.RequestedCustomerData;
import com.amway.domain.list.VolumeDetailPeriods;
import com.amway.model.BonusCustomerMaster;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;

/**
 * @author Sreenivasa Gopalam
 */
@Service
public class LosService {

	private static final Logger LOGGER = LoggerFactory.getLogger(LosService.class);
	@Autowired
	private TaskExecutor executor;
	@Autowired
	private CaffeineCacheService caffeineCacheService;
	@Autowired
	private BonusCustomer bonusCustomer;
	@Autowired
	private DetailImpl detailImpl;

	//@Cacheable(value = "losAppResponseMap", keyGenerator = "keyGeneratorForEndPoint", condition = "#cacheEnabled")
	public VolumeDetailPeriods processServiceInputs(ModelLosDetailsRequest modelLosDetailsRequest) {
		List<RequestedCustomerData> requestedCustomerDataList = mapRequestedCustomerData(modelLosDetailsRequest);
		return modelLosDetailsRequest.isAsList()
				? detailImpl.getListDataForRequested(modelLosDetailsRequest, requestedCustomerDataList)
				: detailImpl.getMapDataForRequested(modelLosDetailsRequest, requestedCustomerDataList);
	}

	private List<RequestedCustomerData> mapRequestedCustomerData(ModelLosDetailsRequest modelLosDetailsRequest) {
		List<RequestedCustomerData> requestedCustomerDatas = new ArrayList<>();
		for (Integer period : modelLosDetailsRequest.getPeriods()) {
			RequestedCustomerData requestedCustomerData = new RequestedCustomerData();
			requestedCustomerData.setPeriod(period);
			requestedCustomerData.setCustomerData(getCustomerDataList(modelLosDetailsRequest, period));
			requestedCustomerDatas.add(requestedCustomerData);
		}
		return requestedCustomerDatas;
	}

	private List<CustomerData> getCustomerDataList(ModelLosDetailsRequest request, Integer period) {
		return request.getAffAbos().stream()
				.map(affAbo -> buildAsyncAffAboCustomerData(request, affAbo, period))
				.map(this::getFutureValueOrNull)
				.filter(Objects::nonNull)
				.collect(Collectors.toList());
	}

	private CustomerData getFutureValueOrNull(CompletableFuture<CustomerData> customerDataFuture) {
		try {
			return customerDataFuture.get();
		} catch (InterruptedException | ExecutionException e) {
		  LOGGER.warn("Failed to get computed value", e);
			return null;
		}
	}

	private CompletableFuture<CustomerData> buildAsyncAffAboCustomerData(
			ModelLosDetailsRequest request, AffAbo affAbo, Integer period) {
	  return supplyAsync(() -> buildAffAboCustomerData(request, affAbo, period), executor);
  }

	private CustomerData buildAffAboCustomerData(ModelLosDetailsRequest request, AffAbo affAbo, Integer period) {
		int aff = affAbo.getAff();
		long abo = affAbo.getAbo();
		try {
			return Optional.ofNullable(bonusCustomer.getCustomerData(aff, abo))
					.filter(bonusCustomerMaster -> bonusCustomerMaster.getBonusCustomerId() > 0)
					.map(bonusCustomerMaster -> buildCustomerData(aff, abo, period, bonusCustomerMaster))
					.orElse(null);
		} catch (Exception e) {
			return buildCustomerErrorData(request, aff, abo, e);
		}
	}

	private CustomerData buildCustomerData(int aff, long abo, Integer period,
			BonusCustomerMaster bonusCustomerMaster) {
		CustomerData customerData = new CustomerData();
		customerData.setAff(aff);
		customerData.setAbo(abo);
		customerData.setBusinessEntity(bonusCustomerMaster.getBusinessEntity());
		customerData.setCustomerId(bonusCustomerMaster.getBonusCustomerId());

		boolean isGlossPeriod = shouldWeGetDataFromGloss(aff, period, caffeineCacheService);
		customerData.setGlossPeriod(isGlossPeriod);

		if (!isGlossPeriod) {
			try {
				bonusCustomer.getCustomerData(bonusCustomerMaster.getBonusCustomerId(), period);
			} catch (Exception e) {
				LOGGER.warn(e.getMessage());
				customerData.setCustomerId(-1);
			}
		}
		return customerData;
	}

	private static CustomerData buildCustomerErrorData(ModelLosDetailsRequest request, int aff,
			long abo, Exception e) {
		if (request.getAffAbos().size() == 1) {
			LOGGER.warn(e.getMessage());
		}
		CustomerData customerData = new CustomerData();
		customerData.setAff(aff);
		customerData.setAbo(abo);
		return customerData;
	}

}
