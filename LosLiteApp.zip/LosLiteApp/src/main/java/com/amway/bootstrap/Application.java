package com.amway.bootstrap;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.EndpointMBeanExportAutoConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.scheduling.annotation.EnableAsync;

import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.zaxxer.hikari.HikariDataSource;

/**
 * @author Sreenivasa Gopalam
 */
@SpringBootApplication
@Configuration
@EnableCaching
@EnableAsync
@EnableAutoConfiguration(exclude = { JmxAutoConfiguration.class, EndpointMBeanExportAutoConfiguration.class })
@ComponentScan({ "com.amway" })
public class Application extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return configureApplication(builder);
	}

	public static void main(String[] args) {
		configureApplication(new SpringApplicationBuilder()).run(args);
	}

	private static SpringApplicationBuilder configureApplication(SpringApplicationBuilder builder) {
		return builder.sources(Application.class).bannerMode(org.springframework.boot.Banner.Mode.OFF);
	}

	@Bean
	public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
		MappingJackson2HttpMessageConverter jsonConverter = new MappingJackson2HttpMessageConverter();
		ObjectMapper objectMapper = jsonConverter.getObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		jsonConverter.setObjectMapper(objectMapper.configure(SerializationFeature.INDENT_OUTPUT, false));
		return jsonConverter;
	}

	@Autowired
	private DataSource dataSource;

	@Autowired
	private MetricRegistry metricRegistry;

	@PostConstruct
	public void setUpHikariWithMetrics() {
		if (dataSource instanceof HikariDataSource) {
			((HikariDataSource) dataSource).setMetricRegistry(metricRegistry);
		}
	}
}