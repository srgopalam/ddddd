package com.amway.dao;

import java.util.List;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.amway.domain.AwardLevelData;

public interface AwardLevel {
	List<AwardLevelData> getAwardLevelData(int period, NamedParameterJdbcTemplate namedParameterJdbcTemplate);
}
