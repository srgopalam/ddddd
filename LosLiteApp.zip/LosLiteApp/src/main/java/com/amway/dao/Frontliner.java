package com.amway.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.amway.domain.ModelLosDetailsRequest;
import com.amway.model.BasicServiceOutputData;

public interface Frontliner {
	public List<BasicServiceOutputData> getAFrontlinersMagic(final int period, final String sponType,
			final List<Long> customerList, List<String> customerStatusCodes,
			final ModelLosDetailsRequest modelLosDetailsRequest, final int level, final JdbcTemplate jdbcTemplate,
			final NamedParameterJdbcTemplate namedParameterJdbcTemplate);
}
