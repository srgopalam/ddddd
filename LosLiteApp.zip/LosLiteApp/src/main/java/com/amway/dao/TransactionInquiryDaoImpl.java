package com.amway.dao;

import java.util.List;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class TransactionInquiryDaoImpl implements TransactionInquiryDao {

	public static final String SQL_BY_TRX_SRC_CD = "SELECT txMst.BNS_CUST_ID AS BNS_CUST_ID FROM WWL03900_TRX_MST txMst, TTL02000_LOS_DTL_SVC temp "
			+ "   WHERE txMst.BNS_CUST_ID = temp.BNS_CUST_ID AND txMst.BNS_PER_NO = :period"
			+ "   AND TRX_SOURC_CD = :trxSourceCd AND PROC_STAT_CD = 'cp'";

	public static final String SQL_BY_GENERATED_IMPACT = "SELECT temp.BNS_CUST_ID "
			+ "FROM WWL03945_TRX_RWRK_MST RWRK_MST "
			+ "INNER JOIN WWL03900_TRX_MST TRX_MST ON RWRK_MST.ORGNL_TRX_ID = TRX_MST.BNS_TRX_ID "
			+ "INNER JOIN TTL02000_LOS_DTL_SVC temp ON RWRK_MST.BNS_CUST_ID = temp.BNS_CUST_ID "
			+ "INNER JOIN WWL03710_TRX_VOL_DTL TRX_DTL ON RWRK_MST.ORGNL_TRX_ID = TRX_DTL.BNS_TRX_ID "
			+ "WHERE RWRK_MST.BNS_PER_NO = :period AND TRX_MST.AFF_NO = :affNo "
			+ "AND RWRK_MST.BNS_PER_NO = TRX_MST.BNS_PER_NO GROUP BY temp.BNS_CUST_ID";

	@Override
	public List<Long> getFilteredCustomersWithGivenTrxSourceCd(int period,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate, String trxSourceCd) {
		SqlParameterSource namedParameters = new MapSqlParameterSource();

		((MapSqlParameterSource) namedParameters).addValue("period", period);
		((MapSqlParameterSource) namedParameters).addValue("trxSourceCd", trxSourceCd);
		return namedParameterJdbcTemplate.queryForList(SQL_BY_TRX_SRC_CD, namedParameters, Long.class);
	}

	@Override
	public List<Long> getFilteredCustomersWithGeneratedImpact(int period, int affNo,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		SqlParameterSource namedParameters = new MapSqlParameterSource();

		((MapSqlParameterSource) namedParameters).addValue("period", period);
		((MapSqlParameterSource) namedParameters).addValue("affNo", affNo);

		return namedParameterJdbcTemplate.queryForList(SQL_BY_GENERATED_IMPACT, namedParameters, Long.class);
	}
}
