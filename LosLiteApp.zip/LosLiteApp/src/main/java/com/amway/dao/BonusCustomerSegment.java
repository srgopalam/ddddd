package com.amway.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.amway.model.BonusCustomerSegmentData;

public interface BonusCustomerSegment {
	public List<BonusCustomerSegmentData> getSegmentData(List<Long> bonusCustomerList, int period,
			final JdbcTemplate scdsJdbcTemplate, final NamedParameterJdbcTemplate namedParameterJdbcTemplate);

	String getSegment(long bonusCustomerId, int period, NamedParameterJdbcTemplate namedParameterJdbcTemplate);
}
