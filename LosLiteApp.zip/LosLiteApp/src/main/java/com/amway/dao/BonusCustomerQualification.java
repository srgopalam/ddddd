package com.amway.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public interface BonusCustomerQualification {
	Map<Long, Integer> getIntlQualifiedLegCounts(boolean fromMagic, int period, List<Long> bonusCustList,
			Set<String> qualMethodCodes, JdbcTemplate scdsJdbcTemplate);

	Map<Long, Map<String, Integer>> getInMktAndFosterQualCounts(int period,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate);

	Map<Long, Integer> getQualifiedAwardLegCounts(int startOfFiscalYear, int endOfFiscalYear,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate);
}
