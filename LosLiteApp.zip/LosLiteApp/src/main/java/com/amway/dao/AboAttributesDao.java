package com.amway.dao;

import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.amway.domain.include.AboAttributes;

public interface AboAttributesDao {
	Map<String, AboAttributes> getAboAttributes(NamedParameterJdbcTemplate namedParameterJdbcTemplate);
}
