package com.amway.dao;

import com.amway.dto.BonusExchangeRateDetailParam;
import com.amway.model.BonusExchangeRateDetail;

public interface BonusExchangeRate {
	public BonusExchangeRateDetail getBonusExchangeRateDetail(BonusExchangeRateDetailParam param);
}
