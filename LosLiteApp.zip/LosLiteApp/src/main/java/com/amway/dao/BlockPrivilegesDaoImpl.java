package com.amway.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

@Component
public class BlockPrivilegesDaoImpl implements BlockPrivilegesDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(BlockPrivilegesDaoImpl.class);
	@Autowired
	protected JdbcTemplate jTemplate;

	public BlockPrivilegesDaoImpl() {
		super();
	}

	@Override
	public boolean getIsDistBlocked(long bnsCustId, Date sqlExpDate) {

		String sql = "SELECT MST.IS_BLCK AS PRIVACY_FLAG  FROM WWL09004_BLCKSPRIVS_DIST DIST, WWL09000_BLCKS_PRIVS_MST MST"
				+ " WHERE DIST.BLCK_PRIV_TYPE_ID = MST.BLCK_PRIV_TYPE_ID AND TO_CHAR (DIST.EFF_DT, 'yyyy-MM-dd') ="
				+ " (SELECT MAX (TO_CHAR (DIST.EFF_DT, 'yyyy-MM-dd')) a         FROM WWL09004_BLCKSPRIVS_DIST DIST"
				+ " WHERE  DIST.BNS_CUST_ID = ?  AND DIST.BLCK_PRIV_TYPE_ID = 101) AND DIST.EFF_DT <= ?"
				+ " AND (DIST.EXPRY_DT IS NULL OR DIST.EXPRY_DT >= ?)   AND Dist.BNS_CUST_ID = ?";

		boolean privacyFlag = false;

		try {
			SqlRowSet rs = jTemplate.queryForRowSet(sql, bnsCustId, sqlExpDate, sqlExpDate, bnsCustId);

			if (rs.next()) {
				privacyFlag = rs.getBoolean("PRIVACY_FLAG");
			}

		} catch (EmptyResultDataAccessException ex) {
			LOGGER.error("Internal error: ", ex);
			privacyFlag = false;
		}

		return privacyFlag;

	}

	@Override
	public Map<Long, Boolean> getIsDistBlocked(NamedParameterJdbcTemplate namedParameterJdbcTemplate, Date sqlExpDate) {
		String sql = "SELECT DIST.BNS_CUST_ID, MST.IS_BLCK AS PRIVACY_FLAG  FROM WWL09004_BLCKSPRIVS_DIST DIST, WWL09000_BLCKS_PRIVS_MST MST, TTL02000_LOS_DTL_SVC temp"
				+ " WHERE DIST.BLCK_PRIV_TYPE_ID = MST.BLCK_PRIV_TYPE_ID AND TO_CHAR (DIST.EFF_DT, 'yyyy-MM-dd') = (SELECT MAX (TO_CHAR (DIST.EFF_DT, 'yyyy-MM-dd')) a FROM WWL09004_BLCKSPRIVS_DIST DIST"
				+ " WHERE  DIST.BNS_CUST_ID = temp.BNS_CUST_ID  AND DIST.BLCK_PRIV_TYPE_ID = 101) AND DIST.EFF_DT <= :sqlExpDate"
				+ " AND (DIST.EXPRY_DT IS NULL OR DIST.EXPRY_DT >= :sqlExpDate)   AND Dist.BNS_CUST_ID = temp.BNS_CUST_ID";

		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("sqlExpDate", sqlExpDate);
		return namedParameterJdbcTemplate.query(sql, namedParameters, (ResultSet rs) -> {
			Map<Long, Boolean> results = new HashMap<>();

			while (rs.next()) {
				results.put(rs.getLong("BNS_CUST_ID"), rs.getBoolean("PRIVACY_FLAG"));
			}

			return results;
		});
	}

}
