package com.amway.dao;

import java.util.List;
import java.util.Map;

import com.amway.model.BusinessEntityData;

public interface BusinessEntity {
	public List<BusinessEntityData> getBusinessEntityDetailsByPeriod(int period);

	public Map<Integer, BusinessEntityData> getBusinessEntityDetailsMapByPeriod(int period);
}
