package com.amway.dao;

import com.amway.domain.CustomerData;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.domain.RequestedCustomerData;
import com.amway.domain.list.Details;
import com.amway.domain.list.VolumeDetailPeriods;
import java.util.List;

public interface IDetail {
	VolumeDetailPeriods getMapDataForRequested(ModelLosDetailsRequest modelLosDetailsRequest,
			List<RequestedCustomerData> requestedCustomerDataList);

	VolumeDetailPeriods getListDataForRequested(ModelLosDetailsRequest modelLosDetailsRequest,
			List<RequestedCustomerData> requestedCustomerDataList);

	List<Details> getListDataForRequested(CustomerData customerData,
			ModelLosDetailsRequest modelLosDetailsRequest, int period, List<String> customerStatusCodes);
}
