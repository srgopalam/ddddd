package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.amway.model.PVBVDetailData;
import com.amway.util.DateUtil;

@Component
@SuppressWarnings({ "rawtypes" })
public class PVBVDetailImpl implements PVBVDetail {
	@SuppressWarnings("unchecked")
	@Override
	public List<PVBVDetailData> getPVBVDataByVolumeType(NamedParameterJdbcTemplate namedParameterJdbcTemplate,
			Set<String> volumeTypes, int period) {
		String sql = "SELECT t1.BNS_CUST_ID, t1.BNS_PER_NO, t1.BUS_ENTTY_NO, "
				+ "       t1.VOL_TYPE_CD, SUM(t1.PV_QTY) AS PV_QTY, "
				+ "       SUM(t1.BNS_VOL_QTY) AS BNS_VOL_QTY FROM WWL03476_VOL_PER_DTL t1, TTL02000_LOS_DTL_SVC temp "
				+ " WHERE     VOL_TYPE_CD IN (:volumeTypes) AND t1.BNS_PER_NO = :period "
				+ "       AND t1.BNS_CUST_ID = temp.BNS_CUST_ID GROUP BY t1.BNS_CUST_ID, "
				+ "         t1.BNS_PER_NO, t1.BUS_ENTTY_NO, t1.VOL_TYPE_CD ";
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("volumeTypes", volumeTypes);
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		return namedParameterJdbcTemplate.query(sql, namedParameters, new PVBVDetailRowMapper());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PVBVDetailData> getYtdPVBVDataByVolumeType(NamedParameterJdbcTemplate namedParameterJdbcTemplate,
			Set<String> volumeTypes, int period) {
		int fiscalYear = DateUtil.fiscalYear(period);
		int startPeriod = DateUtil.startOfFiscalYear(fiscalYear);
		String sql = "SELECT t1.BNS_CUST_ID, " + period + "       as BNS_PER_NO, t1.BUS_ENTTY_NO, "
				+ "       t1.VOL_TYPE_CD, SUM(t1.PV_QTY) AS PV_QTY FROM WWL03476_VOL_PER_DTL t1, TTL02000_LOS_DTL_SVC temp "
				+ " WHERE     VOL_TYPE_CD IN (:volumeTypes) "
				+ "       AND t1.BNS_PER_NO BETWEEN :startPeriod AND :period "
				+ "       AND t1.BNS_CUST_ID = temp.BNS_CUST_ID GROUP BY t1.BNS_CUST_ID, t1.BUS_ENTTY_NO, t1.VOL_TYPE_CD ";
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("volumeTypes", volumeTypes);
		((MapSqlParameterSource) namedParameters).addValue("startPeriod", startPeriod);
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		return namedParameterJdbcTemplate.query(sql, namedParameters, new AccumulatedPVBVDetailRowMapper());
	}

	public class PVBVDetailRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			PVBVDetailData pvBvDetailData = new PVBVDetailData();
			pvBvDetailData.setBonusCustomerId(rs.getLong("BNS_CUST_ID"));
			pvBvDetailData.setBusinessEntity(rs.getInt("BUS_ENTTY_NO"));
			pvBvDetailData.setBonusPeriod(rs.getInt("BNS_PER_NO"));
			pvBvDetailData.setVolumeTypeCode(rs.getString("VOL_TYPE_CD"));
			pvBvDetailData.setPvQuantity(rs.getBigDecimal("PV_QTY"));
			pvBvDetailData.setBvQuantity(rs.getBigDecimal("BNS_VOL_QTY"));
			return pvBvDetailData;
		}
	}

	public class AccumulatedPVBVDetailRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			PVBVDetailData pvBvDetailData = new PVBVDetailData();
			pvBvDetailData.setBonusCustomerId(rs.getLong("BNS_CUST_ID"));
			pvBvDetailData.setBusinessEntity(rs.getInt("BUS_ENTTY_NO"));
			pvBvDetailData.setVolumeTypeCode(rs.getString("VOL_TYPE_CD"));
			pvBvDetailData.setYtdPvQuantity(rs.getBigDecimal("PV_QTY"));
			pvBvDetailData.setBonusPeriod(rs.getInt("BNS_PER_NO"));
			return pvBvDetailData;
		}
	}
}
