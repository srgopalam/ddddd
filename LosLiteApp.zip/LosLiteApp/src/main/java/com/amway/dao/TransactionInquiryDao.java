package com.amway.dao;

import java.util.List;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public interface TransactionInquiryDao {
	List<Long> getFilteredCustomersWithGivenTrxSourceCd(int period,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate, String trxSourceCd);
	
	List<Long> getFilteredCustomersWithGeneratedImpact(int period, int affNo,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate);
}
