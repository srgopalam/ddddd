package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.amway.model.BonusCustomerMaster;

@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class BonusCustomerImpl implements BonusCustomer {
	@Autowired
	protected JdbcTemplate jTemplate;

	@Override
	public BonusCustomerMaster getCustomerData(int aff, long abo) throws Exception {
		String sql = "SELECT CUST.AFF_NO AS AFF_NO, CUST.IBO_NO AS IBO_NO, BNS_CUST_ID, BUS_ENTTY_NO, DFLT_ISO_CNTRY_CD FROM WWL01010_BNS_CUST_MST CUST, WWL01080_IBO_INF_MST MST WHERE CUST.AFF_NO = ? AND CUST.IBO_NO = ? "
				+ " AND CUST.AFF_NO = MST.AFF_ID AND CUST.IBO_NO = MST.IBO_NO AND prg_stat_cd <> 'D' ";
		BonusCustomerMaster customer;
		try {
			customer = (BonusCustomerMaster) jTemplate.queryForObject(sql, new Object[] { aff, abo },
					new CustomerRowMapper());
		} catch (EmptyResultDataAccessException exception) {
			throw new Exception("No customer found with aff:" + aff + ", abo:" + abo + " or DELETED.");
		}
		return customer;
	}

	@Override
	public BonusCustomerMaster getCustomerData(long bonusCustomer, int period) throws Exception {
		String sql = "SELECT 0 as AFF_NO, 0 as IBO_NO, BNS_CUST_ID, BUS_ENTTY_NO, '' as DFLT_ISO_CNTRY_CD FROM WWL03250_CUST_PER_DTL WHERE BNS_CUST_ID = ? AND BNS_PER_NO = ?";
		BonusCustomerMaster customer = null;
		try {
			customer = (BonusCustomerMaster) jTemplate.queryForObject(sql, new Object[] { bonusCustomer, period },
					new CustomerRowMapper());
		} catch (EmptyResultDataAccessException exception) {
			throw new Exception("No customer found with bonusCustomer:" + bonusCustomer + ", period:" + period);
		}
		return customer;
	}

	public class CustomerRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			BonusCustomerMaster customer = new BonusCustomerMaster();
			customer.setAff(rs.getInt("AFF_NO"));
			customer.setAbo(rs.getLong("IBO_NO"));
			customer.setBonusCustomerId(rs.getLong("BNS_CUST_ID"));
			customer.setBusinessEntity(rs.getInt("BUS_ENTTY_NO"));
			customer.setDefaultIsoCountryCode(rs.getString("DFLT_ISO_CNTRY_CD"));
			return customer;
		}
	}
}
