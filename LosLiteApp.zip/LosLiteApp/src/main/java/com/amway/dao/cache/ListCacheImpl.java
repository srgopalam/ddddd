package com.amway.dao.cache;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

import com.amway.dao.VolumeTypeMaster;
import com.amway.model.BonusAwardMaster;
import com.amway.model.VolumeTypeMasterData;
import com.amway.util.mappers.BonusAwardsRowMapper;

@Component
public class ListCacheImpl implements ListCache {
	private static final Logger LOGGER = LoggerFactory.getLogger(ListCacheImpl.class);
	@Autowired
	protected JdbcTemplate jTemplate;

	@Autowired
	protected VolumeTypeMaster volumeTypeMaster;

	@Override
	public List<Integer> getAllAffiliates() {
		LOGGER.info("Retrieving AFF_NO's from DB!");
		String sql = "SELECT AFF_NO FROM WWL12010_AFF_MST order by AFF_NO";
		return jTemplate.queryForList(sql, Integer.class);
	}

	@Override
	public List<String> getAllVolumeTypeCodes() {
		String sql = "SELECT VOL_TYPE_CD FROM WWL03680_VOL_TYPE_MST order by VOL_TYPE_CD";
		return jTemplate.queryForList(sql, String.class);
	}

	@Override
	public List<String> getAllBusinessNatureCodes() {
		LOGGER.info("Retrieving BUS_NATR_CD's from DB!");
		String sql = "SELECT TRIM(BUS_NATR_CD) FROM WWL03190_BUS_NATR_LKP order by BUS_NATR_CD";
		return jTemplate.queryForList(sql, String.class);
	}

	@Override
	public List<BonusAwardMaster> getAllBonusAwards() {
		LOGGER.info("Retrieving WWL03070_BNS_AWD_MST's data from DB!");
		String sql = "SELECT BNS_AWD_NO,BNS_AWD_NM,BNS_AWD_DESC,BNS_AWD_GRP_CD,WW_ALIAS_TXT,TOP_UP_CD,PROC_CD FROM WWL03070_BNS_AWD_MST order by BNS_AWD_NO";
		@SuppressWarnings("unchecked")
		List<BonusAwardMaster> bonusAwardsData = jTemplate.query(sql, new BonusAwardsRowMapper());
		return bonusAwardsData;
	}

	@Override
	public Map<Integer, Integer> getLosBuildPeriodsByAffiliates() {
		LOGGER.info("Retrieving WWL03640_SYS_RULE_AFF_CTL's data from DB!");
		return jTemplate.query(
				"SELECT AFF_NO, MAX(EFF_BNS_PER_NO) AS LOS_BUILD_PERIOD FROM WWL03640_SYS_RULE_AFF_CTL WHERE SYS_RULE_ID = 80 GROUP BY AFF_NO ",
				new ResultSetExtractor<Map<Integer, Integer>>() {
					@Override
					public Map<Integer, Integer> extractData(ResultSet rs) throws SQLException {
						Map<Integer, Integer> results = new HashMap<>();
						while (rs.next()) {
							results.put(rs.getInt("AFF_NO"), rs.getInt("LOS_BUILD_PERIOD"));
						}
						return results;
					}
				});
	}

	@Override
	public Map<Integer, Integer> getCurrentBnsPeriodsByAffiliates() {
		LOGGER.info("Retrieving WWL12010_AFF_MST's data from DB!3");
		return jTemplate.query("SELECT AFF_NO, CURR_BNS_PER_NO FROM WWL12010_AFF_MST ",
				new ResultSetExtractor<Map<Integer, Integer>>() {
					@Override
					public Map<Integer, Integer> extractData(ResultSet rs) throws SQLException {
						Map<Integer, Integer> results = new HashMap<>();
						while (rs.next()) {
							results.put(rs.getInt("AFF_NO"), rs.getInt("CURR_BNS_PER_NO"));
						}
						return results;
					}
				});
	}

	@Override
	public Map<String, VolumeTypeMasterData> getAllVolumeTypesData() {
		// Populate volume type master details data
		Map<String, VolumeTypeMasterData> volumeTypeMasterDetailMap = new HashMap<>();
		List<VolumeTypeMasterData> volumeTypeMasterDetailList = this.volumeTypeMaster.getAllVolumeTypesData();
		for (VolumeTypeMasterData volumeTypeMasterData : volumeTypeMasterDetailList) {
			volumeTypeMasterDetailMap.put(volumeTypeMasterData.getVolumeTypeCode(), volumeTypeMasterData);
		}
		return volumeTypeMasterDetailMap;
	}

	@Override
	public List<Long> getExclusableCustomers() {
		LOGGER.info("Retrieving WWL07100_TM_CUST_CHK_DTL.BNS_CUST_ID's from DB!");
		String sql = "SELECT BNS_CUST_ID FROM WWL07100_TM_CUST_CHK_DTL";
		return jTemplate.queryForList(sql, Long.class);
	}

}
