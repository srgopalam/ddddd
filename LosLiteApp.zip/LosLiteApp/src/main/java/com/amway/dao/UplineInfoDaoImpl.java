package com.amway.dao;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.amway.domain.include.UplineInfo;
import com.amway.util.DBUtil;

@Component
public class UplineInfoDaoImpl implements UplineInfoDao {

	JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	private static final String PARAM_NM_BNS_PERIOD = "bnsPeriod";
	private static final String PARAM_NM_CUST_STATUS_CODES = "customerStatusCodes";
	private static final String PARAM_NM_BUSINESS_NATURES = "businessNatures";

	@Override
	public Map<Long, UplineInfo> getUplineInfoFrmGloss(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		String sql = "select t1.spon_aff_id, t1.spon_ibo_no, t3.phys_nm, t5.iso_cntry_cd, t4.bns_cust_id, t1.los_type_cd"
				+ " from wwl01160_ibo_spon_mst t1 left outer join wwl01080_ibo_inf_mst t2"
				+ " on t1.spon_aff_id = t2.aff_id and t1.spon_ibo_no = t2.ibo_no"
				+ " left outer join wwl01100_ibo_nm_mst t3 on t1.spon_aff_id = t3.aff_id"
				+ " and t1.spon_ibo_no = t3.ibo_no and t3.nm_type_cd = '0'"
				+ " inner join wwl01010_bns_cust_mst t4 on t1.aff_id = t4.aff_no and t1.ibo_no = t4.ibo_no"
				+ " inner join wwl12030_cntry_mst t5 on t2.amway_cntry_cd = t5.amway_cntry_cd"
				+ " INNER JOIN TTL02000_LOS_DTL_SVC temp ON t4.bns_cust_id = temp.bns_cust_id where  t1.los_type_cd = 'B'";

		SqlParameterSource namedParameters = new MapSqlParameterSource();
		return namedParameterJdbcTemplate.query(sql, namedParameters, (ResultSet rs) -> {
			Map<Long, UplineInfo> results = new HashMap<>();

			while (rs.next()) {
				UplineInfo uplineInfo = new UplineInfo();
				uplineInfo.setIntlSponAff(rs.getInt("spon_aff_id"));
				uplineInfo.setIntlSponAbo(rs.getLong("spon_ibo_no"));
				uplineInfo.setIntlSponCountry(rs.getString("iso_cntry_cd"));
				uplineInfo.setIntlSponName(rs.getString("phys_nm"));
				uplineInfo.setIntlSponsorType(rs.getString("los_type_cd"));
				results.put(rs.getLong("bns_cust_id"), uplineInfo);
			}
			return results;
		});
	}

	@Override
	public Map<Long, UplineInfo> getUplineInfoFrmMagic(int bnsPeriod,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		String sql = "SELECT t1.bns_cust_id, t3.aff_no, t3.ibo_no, t3.dflt_iso_cntry_cd, t2.cust_nm, t1.spon_type_cd "
				+ "FROM WWL03290_cust_spon_dtl t1 "
				+ "INNER JOIN WWL01010_bns_cust_mst t3 ON t1.cust_spon_id = t3.bns_cust_id "
				+ "INNER JOIN TTL02000_LOS_DTL_SVC temp ON t1.bns_cust_id = temp.bns_cust_id "
				+ "LEFT OUTER JOIN WWL03250_cust_per_dtl t2 ON t1.cust_spon_id = t2.bns_cust_id AND t1.bns_per_no = t2.bns_per_no "
				+ "WHERE t1.spon_type_cd = 'mn' AND t1.bns_per_no = :bnsPeriod";

		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue(PARAM_NM_BNS_PERIOD, bnsPeriod);
		return namedParameterJdbcTemplate.query(sql, namedParameters, (ResultSet rs) -> {
			Map<Long, UplineInfo> results = new HashMap<>();

			while (rs.next()) {
				UplineInfo uplineInfo = new UplineInfo();
				uplineInfo.setIntlSponAff(rs.getInt("aff_no"));
				uplineInfo.setIntlSponAbo(rs.getLong("ibo_no"));
				uplineInfo.setIntlSponCountry(rs.getString("dflt_iso_cntry_cd"));
				uplineInfo.setIntlSponName(rs.getString("cust_nm"));
				uplineInfo.setIntlSponsorType(rs.getString("spon_type_cd"));
				results.put(rs.getLong("bns_cust_id"), uplineInfo);
			}
			return results;
		});
	}

	@Override
	public Map<Long, Long> getPlatinumSponsor(int bnsPeriod, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		String sql = "SELECT CUSTMST.BNS_CUST_ID, CUSTUPLNDTL.BNS_PER_NO, CUSTUPLNDTL.SPON_BNS_CUST_ID,"
				+ " CUSTMST1.AFF_NO,  CUSTMST1.IBO_NO FROM WWL03255_CUST_UPLN_TYPE_DTL CUSTUPLNDTL"
				+ " JOIN WWL01010_BNS_CUST_MST CUSTMST ON CUSTMST.BNS_CUST_ID = CUSTUPLNDTL.BNS_CUST_ID"
				+ " JOIN WWL01010_BNS_CUST_MST CUSTMST1 ON CUSTMST1.BNS_CUST_ID = CUSTUPLNDTL.SPON_BNS_CUST_ID"
				+ " JOIN TTL02000_LOS_DTL_SVC temp ON temp.BNS_CUST_ID = CUSTUPLNDTL.BNS_CUST_ID"
				+ " WHERE CUSTUPLNDTL.UPLN_TYPE_CD = 'PT' AND CUSTUPLNDTL.BNS_PER_NO = :bnsPeriod";

		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue(PARAM_NM_BNS_PERIOD, bnsPeriod);
		return namedParameterJdbcTemplate.query(sql, namedParameters, (ResultSet rs) -> {
			Map<Long, Long> results = new HashMap<>();
			while (rs.next()) {
				results.put(rs.getLong("BNS_CUST_ID"), rs.getLong("IBO_NO"));
			}
			return results;
		});
	}

	public Set<Long> getSponsoredSet(final boolean fromGloss, final int bnsPeriod,
			final List<String> customerStatusCodes, final Set<String> businessNatures,
			final NamedParameterJdbcTemplate namedParameterJdbcTemplate) {

		String magic = "SELECT DISTINCT CUST_SPON_ID FROM (SELECT spon.CUST_SPON_ID FROM WWL03290_CUST_SPON_DTL spon, "
				+ "         WWL03250_CUST_PER_DTL per, TTL02000_LOS_DTL_SVC temp "
				+ "   WHERE     spon.CUST_SPON_ID = temp.BNS_CUST_ID AND per.bns_per_no = spon.bns_per_no "
				+ "         AND spon.CUST_SPON_ID = per.BNS_CUST_ID AND TRIM (PER.CUST_STAT_CD) IN (:customerStatusCodes) "
				+ "         AND TRIM (PER.BUS_NATR_CD) IN (:businessNatures) AND spon.BNS_PER_NO = :bnsPeriod "
				+ "         AND (spon.SPON_TYPE_CD = 'mm' OR spon.SPON_TYPE_CD = 'mn' OR spon.SPON_TYPE_CD = 'gm'))";

		String gloss = "SELECT temp.BNS_CUST_ID AS CUST_SPON_ID FROM TTL02000_LOS_DTL_SVC temp\n"
				+ "       JOIN WWL01010_BNS_CUST_MST mst ON mst.BNS_CUST_ID = temp.BNS_CUST_ID\n"
				+ " WHERE EXISTS (SELECT 1 FROM WWL01080_IBO_INF_MST mst2 WHERE mst.IBO_NO = MST2.SPON_IBO_NO AND mst.aff_no = mst2.SPON_AFF_ID"
				+ " AND TRIM (mst2.BUS_STAT_CD) IN (:customerStatusCodes) AND TRIM (mst2.AMWAY_BUS_INACT_CD) IN (:businessNatures))";
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue(PARAM_NM_BNS_PERIOD, bnsPeriod);
		((MapSqlParameterSource) namedParameters).addValue(PARAM_NM_BUSINESS_NATURES, businessNatures);
		((MapSqlParameterSource) namedParameters).addValue(PARAM_NM_CUST_STATUS_CODES, customerStatusCodes);
		return namedParameterJdbcTemplate.query(fromGloss ? gloss : magic, namedParameters, (ResultSet rs) -> {
			Set<Long> results = new HashSet<>();
			while (rs.next()) {
				results.add(rs.getLong("CUST_SPON_ID"));
			}
			return results;
		});
	}

	public Set<Long> getSponsoredSetIntl(final int bnsPeriod, final List<String> customerStatusCodes,
			final Set<String> businessNatures, final NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		String gloss = "SELECT temp.BNS_CUST_ID AS CUST_SPON_ID FROM TTL02000_LOS_DTL_SVC temp "
				+ " JOIN WWL01010_BNS_CUST_MST mst ON mst.BNS_CUST_ID = temp.BNS_CUST_ID WHERE EXISTS "
				+ " (SELECT 1 FROM WWL01160_IBO_SPON_MST intlmst WHERE mst.IBO_NO = intlmst.SPON_IBO_NO AND mst.aff_no = intlmst.SPON_AFF_ID)";
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue(PARAM_NM_BNS_PERIOD, bnsPeriod);
		((MapSqlParameterSource) namedParameters).addValue(PARAM_NM_BUSINESS_NATURES, businessNatures);
		((MapSqlParameterSource) namedParameters).addValue(PARAM_NM_CUST_STATUS_CODES, customerStatusCodes);
		return namedParameterJdbcTemplate.query(gloss, namedParameters, (ResultSet rs) -> {
			Set<Long> results = new HashSet<>();
			while (rs.next()) {
				results.add(rs.getLong("CUST_SPON_ID"));
			}
			return results;
		});
	}

	@Override
	public JdbcTemplate getSingleConnectionJdbcTemplate() {
		return DBUtil.getSingleConnectionJdbcTemplate(this.jdbcTemplate);
	}
}
