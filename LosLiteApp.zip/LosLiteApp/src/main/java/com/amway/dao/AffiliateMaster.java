package com.amway.dao;

import java.util.List;
import java.util.Map;

import com.amway.model.AffiliateMasterData;

public interface AffiliateMaster {
	public AffiliateMasterData getAffiliateData(int aff) throws Exception;

	public List<AffiliateMasterData> getAllAffiliatesData();

	public Map<Integer, AffiliateMasterData> getAllAffiliatesDataMap();
}
