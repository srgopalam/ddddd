package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.amway.dto.NextPercentageAndVolume;

@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class NextPercentageImpl implements NextPercentage {
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LoggerFactory.getLogger(NextPercentageImpl.class);
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public class NextPercentageDataRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			NextPercentageAndVolume data = new NextPercentageAndVolume();
			data.setNextPercentage(rs.getInt("NEXT_PERCENTAGE"));
			data.setScheduleLevelNumber(rs.getInt("SCHED_LVL_NO"));
			data.setRowNumber(rs.getInt("RN"));
			return data;
		}
	}

	@Override
	public NextPercentageAndVolume getNextPercentageData(int aff, int businessEntity, int period, int currentPercentage,
			int awardNumber) throws Exception {
		// @formatter:off
		String sql = "SELECT BNS_PCT AS NEXT_PERCENTAGE, SCHED_LVL_NO, RN FROM ( SELECT BNS_PCT,"
				+ "                 SCHED_LVL_NO, ROW_NUMBER () OVER (ORDER BY BNS_PCT) AS RN"
				+ "            FROM WWL03610_SCHED_BNS_AWD_DTL  WHERE EFF_BNS_PER_NO ="
				+ "                        (SELECT MAX (EFF_BNS_PER_NO)"
				+ "                           FROM WWL03610_SCHED_BNS_AWD_DTL"
				+ "                          WHERE     EFF_BNS_PER_NO <= :period"
				+ "                                AND BUS_ENTTY_NO = :businessEntity"
				+ "                                AND BNS_AWD_NO = :awardNumber"
				+ "                                AND AFF_NO = :aff)"
				+ "                 AND BUS_ENTTY_NO = :businessEntity"
				+ "                 AND BNS_AWD_NO = :awardNumber AND AFF_NO = :aff"
				+ "                 AND BNS_PCT > :currentPercentage ORDER BY BNS_PCT) WHERE RN <= 1";
		// @formatter:on

		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("aff", aff);
		((MapSqlParameterSource) namedParameters).addValue("businessEntity", businessEntity);
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		((MapSqlParameterSource) namedParameters).addValue("currentPercentage", currentPercentage);
		((MapSqlParameterSource) namedParameters).addValue("awardNumber", awardNumber);
		NextPercentageAndVolume data;
		try {
			data = (NextPercentageAndVolume) namedParameterJdbcTemplate.queryForObject(sql, namedParameters,
					new NextPercentageDataRowMapper());
		} catch (EmptyResultDataAccessException exception) {
			throw new Exception(
					"Current percantage is already reached to the maximum posiible for the given input data:");
		}
		return data;
	}

	@Override
	public List<Integer> getNextVolume(int aff, int businessEntity, int period, int scheduleLevel, int awardNumber) {
		// @formatter:off
		String sql = "  SELECT VOL_BASIS_QTY " + "    FROM WWL03612_SCHED_BNS_AWD_VOL_DTL "
				+ "   WHERE     EFF_BNS_PER_NO = " + "                (SELECT MAX (EFF_BNS_PER_NO) "
				+ "                   FROM WWL03612_SCHED_BNS_AWD_VOL_DTL "
				+ "                  WHERE     EFF_BNS_PER_NO <= :period "
				+ "                        AND BUS_ENTTY_NO = :businessEntity "
				+ "                        AND BNS_AWD_NO = :awardNumber "
				+ "                        AND SCHED_LVL_NO = :scheduleLevel) "
				+ "         AND BUS_ENTTY_NO = :businessEntity " + "         AND BNS_AWD_NO = :awardNumber "
				+ "         AND SCHED_LVL_NO = :scheduleLevel " + "GROUP BY AFF_NO, " + "         BNS_AWD_NO, "
				+ "         BUS_ENTTY_NO, " + "         SCHED_LVL_NO, " + "         VOL_BASIS_QTY";
		// @formatter:on

		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("aff", aff);
		((MapSqlParameterSource) namedParameters).addValue("businessEntity", businessEntity);
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		((MapSqlParameterSource) namedParameters).addValue("scheduleLevel", scheduleLevel);
		((MapSqlParameterSource) namedParameters).addValue("awardNumber", awardNumber);
		return namedParameterJdbcTemplate.queryForList(sql, namedParameters, Integer.class);
	}
}
