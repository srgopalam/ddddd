package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.amway.domain.AwardLevelData;

@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class AwardLevelImpl implements AwardLevel {

	public class AwardLevelRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			AwardLevelData awardLevelData = new AwardLevelData();
			awardLevelData.setBonusCustomerId(rs.getLong("BNS_CUST_ID"));
			awardLevelData.setCurrentAward(rs.getInt("CURR_AWD"));
			awardLevelData.setCurrentQualificationPeriod(rs.getInt("CURR_QUAL_PER"));
			awardLevelData.setHighestAward(rs.getInt("HIGH_AWD"));
			awardLevelData.setHighestQualificationPeriod(rs.getInt("HIGH_QUAL_PER"));
			return awardLevelData;
		}
	}

	@Override
	public List<AwardLevelData> getAwardLevelData(int period, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		String sql = "SELECT CUST.BNS_CUST_ID, CRRAWD.BNS_AWD_NO CURR_AWD, "
				+ "       CRRAWD.EFF_BNS_PER_NO CURR_QUAL_PER, HIGHAWD.BNS_AWD_NO HIGH_AWD, "
				+ "       HIGHAWD.EFF_BNS_PER_NO HIGH_QUAL_PER FROM WWL01010_BNS_CUST_MST CUST "
				+ "       JOIN WWL03051_CURR_HIGH_AWD HIGHAWD "
				+ "          ON     HIGHAWD.BNS_CUST_ID = CUST.BNS_CUST_ID "
				+ "             AND BNS_AWD_TYP_CD = 'HGHST' AND EFF_BNS_PER_NO = "
				+ "                    (SELECT MAX (EFF_BNS_PER_NO) "
				+ "                       FROM WWL03051_CURR_HIGH_AWD "
				+ "                      WHERE     EFF_BNS_PER_NO <= :period "
				+ "                            AND BNS_CUST_ID = CUST.BNS_CUST_ID "
				+ "                            AND BNS_AWD_TYP_CD = 'HGHST') "
				+ "       JOIN WWL03051_CURR_HIGH_AWD CRRAWD "
				+ "          ON     CRRAWD.BNS_CUST_ID = CUST.BNS_CUST_ID "
				+ "             AND CRRAWD.BNS_AWD_TYP_CD = 'CURNT' AND CRRAWD.EFF_BNS_PER_NO = "
				+ "                    (SELECT MAX (EFF_BNS_PER_NO) "
				+ "                       FROM WWL03051_CURR_HIGH_AWD "
				+ "                      WHERE     EFF_BNS_PER_NO <= :period "
				+ "                            AND BNS_CUST_ID = CUST.BNS_CUST_ID "
				+ "                            AND BNS_AWD_TYP_CD = 'CURNT') JOIN TTL02000_LOS_DTL_SVC TEMP "
				+ "          ON     CUST.BNS_CUST_ID = TEMP.BNS_CUST_ID ";
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		return namedParameterJdbcTemplate.query(sql, namedParameters, new AwardLevelRowMapper());
	}
}
