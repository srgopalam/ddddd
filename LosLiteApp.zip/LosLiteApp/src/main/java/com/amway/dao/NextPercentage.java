package com.amway.dao;

import java.util.List;

import com.amway.dto.NextPercentageAndVolume;

public interface NextPercentage {
	public NextPercentageAndVolume getNextPercentageData(int aff, int businessEntity, int period, int currentPercentage,
			int awardNumber) throws Exception;

	public List<Integer> getNextVolume(int aff, int businessEntity, int period, int scheduleLevel, int awardNumber);
}
