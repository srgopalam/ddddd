package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.amway.util.DBUtil;

@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class BonusCustomerQualificationImpl implements BonusCustomerQualification {

	public class QualCountsRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			CustomerQualCounts qualCounts = new CustomerQualCounts();
			qualCounts.setBonusCustomerId(rs.getLong("BNS_CUST_ID"));
			qualCounts.setQualStatCode(rs.getString("QUAL_STAT_CD"));
			qualCounts.setDownlineQualQuantity(rs.getInt("DWNLN_QUAL_QTY"));
			return qualCounts;
		}
	}

	public class CustomerQualCounts {
		private long bonusCustomerId;
		private String qualStatCode;
		private int downlineQualQuantity;

		public long getBonusCustomerId() {
			return bonusCustomerId;
		}

		public void setBonusCustomerId(long bonusCustomerId) {
			this.bonusCustomerId = bonusCustomerId;
		}

		public String getQualStatCode() {
			return qualStatCode;
		}

		public void setQualStatCode(String qualStatCode) {
			this.qualStatCode = qualStatCode;
		}

		public int getDownlineQualQuantity() {
			return downlineQualQuantity;
		}

		public void setDownlineQualQuantity(int downlineQualQuantity) {
			this.downlineQualQuantity = downlineQualQuantity;
		}
	}

	@Override
	public Map<Long, Map<String, Integer>> getInMktAndFosterQualCounts(int period,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		String sql = "SELECT dtl.BNS_CUST_ID, dtl.QUAL_STAT_CD, dtl.DWNLN_QUAL_QTY FROM WWL03270_CUST_PER_QUAL_DTL dtl, TTL02000_LOS_DTL_SVC temp"
				+ "      WHERE dtl.BNS_CUST_ID = temp.BNS_CUST_ID AND dtl.BNS_PER_NO = :period ";
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		List<CustomerQualCounts> qualCounts = namedParameterJdbcTemplate.query(sql, namedParameters,
				new QualCountsRowMapper());
		Map<Long, Map<String, Integer>> customerQualCountsMap = new HashMap<>();
		for (CustomerQualCounts qualCount : qualCounts) {
			customerQualCountsMap.computeIfAbsent(qualCount.getBonusCustomerId(), k -> new HashMap<>())
					.put(qualCount.getQualStatCode(), qualCount.getDownlineQualQuantity());
		}
		return customerQualCountsMap;
	}

	@Override
	public Map<Long, Integer> getQualifiedAwardLegCounts(int startOfFiscalYear, int endOfFiscalYear,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		String sql = "  SELECT dtl.BNS_CUST_ID, SUM (dtl.QUAL_LEG_QTY) AS QUAL_LEG_QTY_SUM "
				+ "    FROM WWL03430_LEG_CNT_ANNUAL_DTL dtl, TTL02000_LOS_DTL_SVC temp WHERE dtl.BNS_CUST_ID = temp.BNS_CUST_ID"
				+ "         AND dtl.BNS_PER_NO BETWEEN :startOfFiscalYear AND :endOfFiscalYear "
				+ "         AND dtl.LEG_TYPE_CD = 'I06' GROUP BY dtl.BNS_CUST_ID, dtl.LEG_TYPE_CD ";

		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("startOfFiscalYear", startOfFiscalYear);
		((MapSqlParameterSource) namedParameters).addValue("endOfFiscalYear", endOfFiscalYear);
		return namedParameterJdbcTemplate.query(sql, namedParameters, (ResultSet rs) -> {
			Map<Long, Integer> results = new HashMap<>();
			while (rs.next()) {
				results.put(rs.getLong("BNS_CUST_ID"), rs.getInt("QUAL_LEG_QTY_SUM"));
			}
			return results;
		});
	}

	@Override
	public Map<Long, Integer> getIntlQualifiedLegCounts(boolean fromMagic, int period, List<Long> bonusCustList,
			Set<String> qualMethodCodes, JdbcTemplate scdsJdbcTemplate) {
		// @formatter:off
		String glossSQL = "  SELECT SP.BNS_CUST_ID AS CUST_SPON_ID, COUNT (*) AS QUALIFIED_LEG_COUNT "
				+ "    FROM WWL01160_IBO_SPON_MST SPON JOIN WWL01010_BNS_CUST_MST CUST "
				+ "            ON SPON.AFF_ID = CUST.AFF_NO AND SPON.IBO_NO = CUST.IBO_NO "
				+ "         JOIN WWL03270_CUST_PER_QUAL_DTL QUAL "
				+ "            ON     CUST.BNS_CUST_ID = QUAL.BNS_CUST_ID "
				+ "               AND QUAL.BNS_PER_NO = :period AND QUAL.QUAL_STAT_CD = 'QMT' "
				+ "         JOIN WWL01010_BNS_CUST_MST SP "
				+ "            ON SPON.SPON_AFF_ID = SP.AFF_NO AND SPON.SPON_IBO_NO = SP.IBO_NO JOIN TTL02000_LOS_DTL_SVC TEMP ON TEMP.BNS_CUST_ID = SP.BNS_CUST_ID"
				+ "   WHERE     LOS_TYPE_CD = 'B'  " + "         AND (   QUAL_MTHOD_OVRRD_CD IS NULL "
				+ "              OR TRIM (QUAL_MTHOD_OVRRD_CD) IN (:qualMethodCodes)) "
				+ "         AND (   AUTO_RULE_VLTE_OVRRD IS NULL "
				+ "              OR TRIM (AUTO_RULE_VLTE_OVRRD) IN (:qualMethodCodes)) GROUP BY SP.BNS_CUST_ID ";

		String magicSQL = "  SELECT CUST_SPON_ID, COUNT (*) AS QUALIFIED_LEG_COUNT "
				+ "    FROM WWL03290_CUST_SPON_DTL SPON JOIN WWL03270_CUST_PER_QUAL_DTL QUAL "
				+ "            ON     SPON.BNS_CUST_ID = QUAL.BNS_CUST_ID "
				+ "               AND SPON.BNS_PER_NO = QUAL.BNS_PER_NO "
				+ "               AND QUAL.QUAL_STAT_CD = 'QMT' JOIN TTL02000_LOS_DTL_SVC TEMP ON TEMP.BNS_CUST_ID = SPON.BNS_CUST_ID WHERE SPON_TYPE_CD = 'mn' "
				+ "         AND SPON.BNS_PER_NO = :period         AND (   QUAL_MTHOD_OVRRD_CD IS NULL "
				+ "              OR TRIM (QUAL_MTHOD_OVRRD_CD) IN (:qualMethodCodes)) "
				+ "         AND (   AUTO_RULE_VLTE_OVRRD IS NULL "
				+ "              OR TRIM (AUTO_RULE_VLTE_OVRRD) IN (:qualMethodCodes)) GROUP BY CUST_SPON_ID ";
		// @formatter:on

		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		((MapSqlParameterSource) namedParameters).addValue("qualMethodCodes", qualMethodCodes);
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(scdsJdbcTemplate);
		DBUtil.insertIntoTempTable(scdsJdbcTemplate, bonusCustList);
		Map<Long, Integer> resultMap = namedParameterJdbcTemplate.query(fromMagic ? magicSQL : glossSQL,
				namedParameters, (ResultSet rs) -> {
					Map<Long, Integer> results = new HashMap<>();
					while (rs.next()) {
						results.put(rs.getLong("CUST_SPON_ID"), rs.getInt("QUALIFIED_LEG_COUNT"));
					}
					return results;
				});
		DBUtil.commitConnection(scdsJdbcTemplate);
		return resultMap;

	}
}
