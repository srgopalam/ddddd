package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.amway.model.SysRuleAffPerCtl;

@Component
@SuppressWarnings({ "unchecked", "rawtypes" })
public class SysRuleAffParamsDaoImpl implements SysRuleAffParamsDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(SysRuleAffParamsDaoImpl.class);
	@Autowired
	protected JdbcTemplate jTemplate;

	public SysRuleAffParamsDaoImpl() {
		super();
	}

	@Override
	public SysRuleAffPerCtl get(int affiliate, int ruleId, int period) {

		String sql = "SELECT AFF_NO, SYS_RULE_ID, "
				+ "EFF_BNS_PER_NO, XPR_BNS_PER_NO, USER_DFINE_TXT, USER_DFINE_DTM, USER_DFINE_QTY, USER_DFINE_PER_NO, "
				+ "USER_DFINE_FLG, AUDIT_CREAT_DTM, AUDIT_CREAT_USER_NM, AUDIT_CHNG_DTM, AUDIT_CHNG_USER_NM, "
				+ "AUDIT_CHNG_MODUL_NM FROM WWL03640_SYS_RULE_AFF_CTL t1 "
				+ "WHERE SYS_RULE_ID = ? and AFF_NO = ? and EFF_BNS_PER_NO = (select max(eff_bns_per_no) from "
				+ "wwl03640_sys_rule_aff_ctl t2 where t1.aff_no = t2.aff_no and t1.sys_rule_id = t2.sys_rule_id "
				+ "and t2.eff_bns_per_no <= ?)";

		SysRuleAffPerCtl sysRuleAff = null;

		try {
			sysRuleAff = (SysRuleAffPerCtl) jTemplate.queryForObject(sql, new Object[] { ruleId, affiliate, period },
					new SysRuleAffParamsRowMapper());
		} catch (EmptyResultDataAccessException exception) {
			LOGGER.error("Internal Error : ", exception);
		}

		return sysRuleAff;
	}

	public class SysRuleAffParamsRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			SysRuleAffPerCtl sysRuleAffCtl = new SysRuleAffPerCtl();
			sysRuleAffCtl.setAffNo(rs.getInt("AFF_NO"));
			sysRuleAffCtl.setRuleId(rs.getInt("SYS_RULE_ID"));
			sysRuleAffCtl.setEffBnsPerNo(rs.getInt("EFF_BNS_PER_NO"));
			sysRuleAffCtl.setXprBnsPerNo(rs.getInt("XPR_BNS_PER_NO"));
			sysRuleAffCtl.setUserDefinedTxt(rs.getString("USER_DFINE_TXT"));
			sysRuleAffCtl.setUserDefinedTime(rs.getTimestamp("USER_DFINE_DTM"));
			sysRuleAffCtl.setUserDefinedQty(rs.getBigDecimal("USER_DFINE_QTY"));
			sysRuleAffCtl.setUserDefinedPerNo(rs.getInt("USER_DFINE_PER_NO"));
			sysRuleAffCtl.setUserDefinedFlag(rs.getBoolean("USER_DFINE_FLG"));
			sysRuleAffCtl.setCreatedTime(rs.getTimestamp("AUDIT_CREAT_DTM"));
			sysRuleAffCtl.setCreatedBy(rs.getString("AUDIT_CREAT_USER_NM"));
			sysRuleAffCtl.setChangedTime(rs.getTimestamp("AUDIT_CHNG_DTM"));
			sysRuleAffCtl.setChangedBy(rs.getString("AUDIT_CHNG_USER_NM"));
			sysRuleAffCtl.setModuleName(rs.getString("AUDIT_CHNG_MODUL_NM"));
			return sysRuleAffCtl;
		}
	}
}
