package com.amway.dao;

import java.util.List;

import com.amway.model.VolumeTypeMasterData;

public interface VolumeTypeMaster {
	public List<VolumeTypeMasterData> getAllVolumeTypesData();
}
