package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.amway.model.CountryMasterData;

@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class CountryMasterImpl implements CountryMaster {
	private static final Logger LOGGER = LoggerFactory.getLogger(CountryMasterImpl.class);
	@Autowired
	protected JdbcTemplate jTemplate;

	public class CountryMasterRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			CountryMasterData cMaster = new CountryMasterData();
			cMaster.setIsoCountryCode(rs.getString("ISO_CNTRY_CD"));
			cMaster.setDefaultIsoLanguageCode(rs.getString("DFLT_ISO_LANG_CD"));
			return cMaster;
		}
	}

	public List<CountryMasterData> getAllCountriessData() {
		LOGGER.info("Retrieving WWL12030_CNTRY_MST's from DB!");
		String sql = "SELECT ISO_CNTRY_CD,DFLT_ISO_LANG_CD FROM WWL12030_CNTRY_MST";
		return jTemplate.query(sql, new CountryMasterRowMapper());
	}

	@Override
	public Map<String, CountryMasterData> getAllCountryDataMap() {
		Map<String, CountryMasterData> cMasterMap = new HashMap<>();
		List<CountryMasterData> cMasterList = this.getAllCountriessData();
		for (CountryMasterData cData : cMasterList) {
			cMasterMap.put(cData.getIsoCountryCode(), cData);
		}
		return cMasterMap;
	}

}