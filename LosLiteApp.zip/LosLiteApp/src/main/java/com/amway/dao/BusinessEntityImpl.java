package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.amway.model.BusinessEntityData;

@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class BusinessEntityImpl implements BusinessEntity {
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Override
	public List<BusinessEntityData> getBusinessEntityDetailsByPeriod(int period) {
		String sql = "SELECT a.BUS_ENTTY_NO, BUS_ENTTY_NM,  BUS_ENTTY_DESC,  "
				+ "       EFF_BNS_PER_NO, BUS_ALLOW_FLG,  BV_PV_RATIO_AMT,  "
				+ "       MIN_STMT_AMT, REDO_CLASS_AR_LIMT_AMT, CALC_TOP_UP_FLG,  "
				+ "       EXCLD_PV_FROM_AWD_VOL_FLG, EXCLD_PV_FROM_RUBY_VOL_FLG,  "
				+ "       ESCRW_PAY_LIMT_AMT, TRACK_FIRST_TM_PCT_AWD_FLG,  "
				+ "       TRACK_MBR_SLVR_AWD_FLG, INCLD_NET_NEG_IN_GRP_VOL_FLG,  "
				+ "       ISO_CURCY_CD, CO_CD, ISO_CNTRY_CD, AFF_NO,  "
				+ "       AUTO_CLASS_CD, PAY_CUST_CLASS_CD, MBR_CLT_VOL_ALLOW_FLG,  "
				+ "       SALE_PLAN_CD, DTL_VAT_FLG, PAY_PREC_NO,  "
				+ "       PAY_RND_MTHOD_CD, TOP_UP_TOT_QTY, TOP_UP_TOT_VOL_LIMT_QTY  "
				+ "FROM   WWL03160_BUS_ENTTY_MST a  INNER JOIN WWL03170_BUS_ENTTY_DTL b  "
				+ "               ON a.BUS_ENTTY_NO = b.BUS_ENTTY_NO  "
				+ "WHERE  EFF_BNS_PER_NO = (SELECT MAX (EFF_BNS_PER_NO)  "
				+ "                         FROM   WWL03170_BUS_ENTTY_DTL c  "
				+ "                         WHERE  a.BUS_ENTTY_NO = c.BUS_ENTTY_NO  "
				+ "                                AND c.EFF_BNS_PER_NO <= :period) ORDER  BY a.BUS_ENTTY_NO ";
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		return namedParameterJdbcTemplate.query(sql, namedParameters, new BusinessEntityRowMapper());
	}

	public class BusinessEntityRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			BusinessEntityData businessEntityData = new BusinessEntityData();
			businessEntityData.setBusinessEntity(rs.getInt("BUS_ENTTY_NO"));
			businessEntityData.setAffiliateNumber(rs.getInt("AFF_NO"));
			businessEntityData.setIsoCountry(rs.getString("ISO_CNTRY_CD"));
			businessEntityData.setIsoCurrency(rs.getString("ISO_CURCY_CD"));
			return businessEntityData;
		}
	}

	@Override
	public Map<Integer, BusinessEntityData> getBusinessEntityDetailsMapByPeriod(int period) {
		Map<Integer, BusinessEntityData> businessEntityDetailMap = new HashMap<>();
		List<BusinessEntityData> businessEntityDetailList = this.getBusinessEntityDetailsByPeriod(period);
		for (BusinessEntityData businessEntityData : businessEntityDetailList) {
			businessEntityDetailMap.put(businessEntityData.getBusinessEntity(), businessEntityData);
		}
		return businessEntityDetailMap;
	}
}
