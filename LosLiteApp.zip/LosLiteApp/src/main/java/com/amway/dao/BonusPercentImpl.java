package com.amway.dao;

import java.util.List;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.amway.model.CustomerPercentage;
import com.amway.util.mappers.CustomerPercentageRowMapper;

public class BonusPercentImpl implements BonusPercent {

	@SuppressWarnings("unchecked")
	@Override
	public List<CustomerPercentage> getBonusPercent(int period, NamedParameterJdbcTemplate namedParameterJdbcTemplate,
			int awardNumber) {
		String sql = "SELECT dtl.BNS_CUST_ID, dtl.CALC_PCT FROM WWL03240_CUST_PER_CALC_DTL dtl, TTL02000_LOS_DTL_SVC temp"
				+ " WHERE dtl.BNS_AWD_NO = :awardNumber AND dtl.BNS_PER_NO = :period"
				+ " AND dtl.BNS_CUST_ID = temp.BNS_CUST_ID";
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("awardNumber", awardNumber);
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		return namedParameterJdbcTemplate.query(sql, namedParameters, new CustomerPercentageRowMapper());
	}

}
