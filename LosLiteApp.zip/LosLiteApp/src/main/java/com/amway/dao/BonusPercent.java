package com.amway.dao;

import java.util.List;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.amway.model.CustomerPercentage;

public interface BonusPercent {
	public List<CustomerPercentage> getBonusPercent(final int period,
			final NamedParameterJdbcTemplate namedParameterJdbcTemplate, final int awardNumber);
}
