
package com.amway.dao;

import com.amway.domain.CustomerData;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.domain.list.Details;
import com.amway.exception.EmptyResultException;
import com.amway.model.BasicServiceOutputData;
import com.amway.service.CaffeineCacheService;
import com.amway.util.DBUtil;
import com.amway.util.LOSType;
import com.amway.util.mappers.BasicServiceOutputMapper;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.sql.DataSource;
import javax.validation.ConstraintViolation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

@Component
@SuppressWarnings("unchecked")
public class DetailGlossImpl extends DetailImpl {
	private static final Logger LOGGER = LoggerFactory.getLogger(DetailGlossImpl.class);
	private static final Set<? extends ConstraintViolation<?>> constraintViolations = new HashSet<>();
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	@Autowired
	private BonusCustomer bonusCustomer;

	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	private JdbcTemplate jdbcTemplate;

	@Autowired
	@Override
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Autowired
	private BonusCustomerSegment bonusCustomerSegment;

	@Autowired
	private CaffeineCacheService caffeineCacheService;

	@Override
	public List<Details> getListDataForRequested(CustomerData customerData,
			ModelLosDetailsRequest modelLosDetailsRequest, int period, List<String> customerStatusCodes) {
		List<Details> detailsList = new ArrayList<>();
		Details details = new Details();
		BasicServiceOutputData basicServiceOutputData = null;
		List<BasicServiceOutputData> downlineList = new ArrayList<>();
		basicServiceOutputData = getAData(customerData, customerStatusCodes);
		List<Long> segment2List = new ArrayList<>();
		Map<Integer, List<Long>> inMarketMap = new HashMap<>();
		long bonusCustId = customerData.getCustomerId();
		if (modelLosDetailsRequest.isIncludeMap() || modelLosDetailsRequest.isIncludeFrontline()) {
			downlineList = mapDownlines(customerStatusCodes, modelLosDetailsRequest, segment2List, inMarketMap,
					customerData);
		}
		if (!modelLosDetailsRequest.isIncludeMap()) {
			addInternationalAndGMBForRequested(customerData, modelLosDetailsRequest, customerStatusCodes, downlineList);
		}
		details.setAff(customerData.getAff());
		details.setAbo(customerData.getAbo());
		details.setSponsorAbo(basicServiceOutputData.getSponsorAbo());
		details.setBonusCustomerId(basicServiceOutputData.getBonusCustomer());
		details.setSponsorCustomerId(basicServiceOutputData.getSponsorCustomerId());
		details.setBusinessEntity(basicServiceOutputData.getBusinessEntity());
		details.setLosType(basicServiceOutputData.getLosTypeCode());
		String segmentCode = bonusCustomerSegment.getSegment(bonusCustId, period, namedParameterJdbcTemplate);
		details.setSegmentCode(StringUtils.isEmpty(segmentCode) ? DEFAULT_CLASS_CODE : segmentCode);
		mapBnAndStatus(modelLosDetailsRequest, details, basicServiceOutputData);
		detailsList.add(details);
		for (BasicServiceOutputData data : nullSafe(downlineList)) {
			details = new Details();
			details.setAff(data.getAff());
			details.setAbo(data.getAbo());
			details.setSponsorAbo(data.getSponsorAbo());
			details.setBonusCustomerId(data.getBonusCustomer());
			details.setSponsorCustomerId(data.getSponsorCustomerId());
			details.setBusinessEntity(data.getBusinessEntity());
			details.setLosType(data.getLosTypeCode());
			details.setSegmentCode(
					StringUtils.isEmpty(data.getSegmentCode()) ? DEFAULT_CLASS_CODE : data.getSegmentCode());
			mapBnAndStatus(modelLosDetailsRequest, details, data);
			detailsList.add(details);
		}
		return detailsList;
	}

	private void mapBnAndStatus(ModelLosDetailsRequest modelLosDetailsRequest, Details details,
			BasicServiceOutputData basicServiceOutputData) {
		if (modelLosDetailsRequest.isIncludeAboAttr() || modelLosDetailsRequest.isIncludeInactive()) {
			details.setStatus(basicServiceOutputData.getBusinessStatusCode());
		}
		if (modelLosDetailsRequest.isIncludeAboAttr() || modelLosDetailsRequest.isShowBusinessNatureProperty()) {
			details.setBusinessNature(basicServiceOutputData.getBusinessNature());
		}
	}

	private void addInternationalAndGMBForRequested(CustomerData customerData,
			ModelLosDetailsRequest modelLosDetailsRequest, List<String> customerStatusCodes,
			List<BasicServiceOutputData> downlineList) {
		if (modelLosDetailsRequest.isIncludeInternational()) {
			downlineList.addAll(getNonIMFrontliners(customerData.getAff(), customerData.getAbo(),
					modelLosDetailsRequest, customerStatusCodes, LOSType.MONTHLY_INTERNATIONAL_SPONSOR.getGlossCode()));

		}
		if (modelLosDetailsRequest.isIncludeGlobalMB()) {
			downlineList.addAll(getNonIMFrontliners(customerData.getAff(), customerData.getAbo(),
					modelLosDetailsRequest, customerStatusCodes, LOSType.GLOBAL_MULTI_BUSINESS_SPONSOR.getGlossCode()));
		}
	}

	/**
	 * Map downlines from gloss.
	 *
	 * @param customerStatusCodes    the customer status codes
	 * @param modelLosDetailsRequest the model los details request
	 * @param segment2List           the segment 2 list
	 * @param inMarketMap            the in market map
   * @param customerData           the customer data (aff / abo)
	 * @return the list
	 * @throws Exception
	 */
	private List<BasicServiceOutputData> mapDownlines(final List<String> customerStatusCodes,
			final ModelLosDetailsRequest modelLosDetailsRequest, List<Long> segment2List,
			Map<Integer, List<Long>> inMarketMap, CustomerData customerData) {
		int aff = customerData.getAff();
		long abo = customerData.getAbo();
		long bonusCustId = customerData.getCustomerId();
		List<BasicServiceOutputData> downlineList = new ArrayList<>();
		List<Long> aboList;
		if (!caffeineCacheService.getExclusableCustomers().contains(bonusCustId)) {
			downlineList = getADownlinesWithoutConnectBy(aff, abo, modelLosDetailsRequest, customerStatusCodes);
		}
		for (BasicServiceOutputData data : nullSafe(downlineList)) {
			if (data.getLosLevelNo() > 1 && PLATINUM_CLASS_CODE.equals(data.getAboClass())) {
				segment2List.add(data.getBonusCustomer());
			}
			if (inMarketMap.containsKey(data.getAff())) {
				inMarketMap.get(data.getAff()).add(data.getAbo());
			} else {
				aboList = new ArrayList<>();
				aboList.add(data.getAbo());
				inMarketMap.put(data.getAff(), aboList);
			}
		}
		if (modelLosDetailsRequest.isIncludeInternational() && modelLosDetailsRequest.isIncludeMap()) {
			mapInternationalByType(customerStatusCodes, modelLosDetailsRequest, segment2List, inMarketMap, aff, abo,
					downlineList, LOSType.MONTHLY_INTERNATIONAL_SPONSOR.getGlossCode());
		}
		if (modelLosDetailsRequest.isIncludeGlobalMB() && modelLosDetailsRequest.isIncludeMap()) {
			mapInternationalByType(customerStatusCodes, modelLosDetailsRequest, segment2List, inMarketMap, aff, abo,
					downlineList, LOSType.GLOBAL_MULTI_BUSINESS_SPONSOR.getGlossCode());
		}
		return downlineList;
	}

	/**
	 * Gets the a downlines without connect by.
	 *
	 * @param aff                    the aff
	 * @param abo                    the abo
	 * @param modelLosDetailsRequest the model los details request
	 * @param customerStatusCodes    the customer status codes
	 * @return the a downlines without connect by
	 * @throws Exception the exception
	 */
	private List<BasicServiceOutputData> getADownlinesWithoutConnectBy(int aff, long abo,
			ModelLosDetailsRequest modelLosDetailsRequest, List<String> customerStatusCodes) {
		List<BasicServiceOutputData> aDownlineList = new ArrayList<>();
		if (modelLosDetailsRequest.isIncludeFrontline() && !modelLosDetailsRequest.isIncludeMap()) {
			return getAFrontliners(aff, abo, modelLosDetailsRequest, customerStatusCodes);
		} else {
			long custId = 0;
			try {
				custId = this.bonusCustomer.getCustomerData(aff, abo).getBonusCustomerId();
			} catch (Exception e) {
				LOGGER.error("Exception occured while getting getCustomerData!", e);
			}
			List<Long> aboList = new ArrayList<>();
			aboList.add(custId);
			List<Long> nonPlatinumCustList = new ArrayList<>();
			List<BasicServiceOutputData> nextLevelList = new ArrayList<>();
			int level = 2;
			JdbcTemplate scdsJdbcTemplate = DBUtil.getSingleConnectionJdbcTemplate(this.jdbcTemplate);
			NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(scdsJdbcTemplate);
			do {
				nonPlatinumCustList.clear();
				nextLevelList.clear();
				nextLevelList.addAll(getAFrontlinersAsyncGloss(modelLosDetailsRequest, customerStatusCodes, level,
						scdsJdbcTemplate, npJdbcTemplate, aboList));
				if (!nextLevelList.isEmpty()) {
					for (BasicServiceOutputData data : nullSafe(nextLevelList)) {
						if (!PLATINUM_CLASS_CODE.equals(data.getSegmentCode())) {
							nonPlatinumCustList.add(data.getBonusCustomer());
						}
					}
				}
				aboList.clear();
				aboList.addAll(nonPlatinumCustList);
				aDownlineList.addAll(nextLevelList);
			} while (!nonPlatinumCustList.isEmpty());
			DBUtil.releaseConnection(scdsJdbcTemplate);
		}
		return aDownlineList;

	}

	public List<BasicServiceOutputData> getAFrontlinersAsyncGloss(final ModelLosDetailsRequest modelLosDetailsRequest,
			final List<String> customerStatusCodes, final int level, final JdbcTemplate scdsJdbcTemplate,
			final NamedParameterJdbcTemplate namedParameterJdbcTemplate, final List<Long> customerList) {
		String sql = "    SELECT CUST.BNS_CUST_ID, MST.AFF_ID AS AFF_NO, MST.IBO_NO, '' AS CUST_NM, MST.BUS_STAT_CD AS CUST_STAT_CD,"
				+ "           CUST2.BNS_CUST_ID AS SPON_CUST_ID, MST.SPON_IBO_NO, MST.SPON_AFF_ID, CUST.BUS_ENTTY_NO,"
				+ "           MST.CLASS_CD AS CUST_CLASS_CD, MST.AMWAY_BUS_INACT_CD AS BUS_NATR_CD, MST.AMWAY_CNTRY_CD,"
				+ level + " AS LOS_LVL_NO, 'A' AS LOS_TYPE_CD, TRIM(MST.CLASS_CD) AS SEG_CD "
				+ " FROM WWL01080_IBO_INF_MST MST, WWL01010_BNS_CUST_MST CUST, WWL01010_BNS_CUST_MST CUST2, TTL02000_LOS_DTL_SVC temp "
				+ " WHERE CUST.AFF_NO = MST.AFF_ID AND CUST.IBO_NO = MST.IBO_NO AND CUST2.AFF_NO = MST.SPON_AFF_ID "
				+ " AND CUST2.IBO_NO = MST.SPON_IBO_NO AND MST.prg_stat_cd <> 'D' AND TRIM(MST.BUS_STAT_CD) IN (:customerStatusCodes) "
				+ " AND TRIM(MST.AMWAY_BUS_INACT_CD) IN (:businessNatures) AND temp.BNS_CUST_ID = CUST2.BNS_CUST_ID";
		DBUtil.insertIntoTempTable(scdsJdbcTemplate, customerList);
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("businessNatures",
				modelLosDetailsRequest.getBusinessNatures());
		((MapSqlParameterSource) namedParameters).addValue("customerStatusCodes", customerStatusCodes);
		List<BasicServiceOutputData> resultList = namedParameterJdbcTemplate.query(sql, namedParameters,
				new BasicServiceOutputMapper());
		DBUtil.commitConnection(scdsJdbcTemplate);
		return resultList;
	}

	/**
	 * Map international from gloss.
	 *
	 * @param customerStatusCodes    the customer status codes
	 * @param modelLosDetailsRequest the model los details request
	 * @param bSet                   the b set
	 * @param gSet                   the g set
	 * @param segment2List           the segment 2 list
	 * @param inMarketMap            the in market map
	 * @param aff                    the aff
	 * @param abo                    the abo
	 * @param downlineList           the downline list
	 */
	private void mapInternationalByType(final List<String> customerStatusCodes,
			final ModelLosDetailsRequest modelLosDetailsRequest, List<Long> segment2List,
			Map<Integer, List<Long>> inMarketMap, int aff, long abo, List<BasicServiceOutputData> downlineList,
			final String fType) {
		List<BasicServiceOutputData> internationalList = new ArrayList<>();
		internationalList
				.addAll(getFrontlinersByCustomerByType(aff, abo, modelLosDetailsRequest, customerStatusCodes, fType));
		List<Long> list = (List<Long>) nullSafe(inMarketMap.get(aff));
		internationalList.addAll(getFrontlinersByType(aff, list, modelLosDetailsRequest, customerStatusCodes, fType));
		for (BasicServiceOutputData data : nullSafe(internationalList)) {
			if (!segment2List.contains(data.getSponsorCustomerId())) {
				downlineList.add(data);
			}
		}
	}

	/**
	 * Gets the a data from gloss.
	 *
	 * @param customerData           the customer data
	 * @param customerStatusCodes    the customer status codes
	 * @return the a data from gloss
	 */
	private BasicServiceOutputData getAData(CustomerData customerData, List<String> customerStatusCodes) {
		// @formatter:off
		String sql = "SELECT CUST.BNS_CUST_ID, MST.AFF_ID AS AFF_NO, MST.IBO_NO,"
				+ "       '' AS CUST_NM, MST.BUS_STAT_CD AS CUST_STAT_CD,"
				+ "       CUST2.BNS_CUST_ID AS SPON_CUST_ID, MST.SPON_IBO_NO, MST.SPON_AFF_ID,"
				+ "       CUST.BUS_ENTTY_NO, MST.CLASS_CD AS CUST_CLASS_CD,"
				+ "       MST.AMWAY_BUS_INACT_CD AS BUS_NATR_CD, MST.AMWAY_CNTRY_CD,"
				+ "       1 AS LOS_LVL_NO, 'A' AS LOS_TYPE_CD, MST.CLASS_CD AS SEG_CD "
				+ "  FROM WWL01080_IBO_INF_MST MST, WWL01010_BNS_CUST_MST CUST,"
				+ "       WWL01010_BNS_CUST_MST CUST2  WHERE CUST.AFF_NO = MST.AFF_ID"
				+ "       AND CUST.IBO_NO = MST.IBO_NO AND CUST2.AFF_NO = MST.SPON_AFF_ID"
				+ "       AND CUST2.IBO_NO = MST.SPON_IBO_NO AND MST.prg_stat_cd <> 'D'"
				+ "       AND CUST.AFF_NO = :aff AND CUST.IBO_NO = :abo";
		// @formatter:on
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("aff", customerData.getAff());
		((MapSqlParameterSource) namedParameters).addValue("abo", customerData.getAbo());
		((MapSqlParameterSource) namedParameters).addValue(CUSTOMER_STATUS_CODES, customerStatusCodes);
		BasicServiceOutputData data;
		try {
			data = (BasicServiceOutputData) namedParameterJdbcTemplate.queryForObject(sql, namedParameters,
					new BasicServiceOutputMapper());
		} catch (EmptyResultDataAccessException ex) {
			throw new EmptyResultException("No records were found that match the specified search criteria!",
					constraintViolations);
		}
		return data;
	}

	/**
	 * Gets the a frontliners.
	 *
	 * @param aff                    the aff
	 * @param abo                    the abo
	 * @param modelLosDetailsRequest the model los details request
	 * @param customerStatusCodes    the customer status codes
	 * @return the a frontliners
	 */
	private List<BasicServiceOutputData> getAFrontliners(final int aff, final long abo,
			final ModelLosDetailsRequest modelLosDetailsRequest, final List<String> customerStatusCodes) {
		// @formatter:off
		String sql = "    SELECT CUST.BNS_CUST_ID, MST.AFF_ID AS AFF_NO, MST.IBO_NO,"
				+ "           '' AS CUST_NM, MST.BUS_STAT_CD AS CUST_STAT_CD,"
				+ "           CUST2.BNS_CUST_ID AS SPON_CUST_ID, MST.SPON_IBO_NO,"
				+ "           MST.SPON_AFF_ID, CUST.BUS_ENTTY_NO,"
				+ "           MST.CLASS_CD AS CUST_CLASS_CD, MST.AMWAY_BUS_INACT_CD AS BUS_NATR_CD,"
				+ "           MST.AMWAY_CNTRY_CD, 2 AS LOS_LVL_NO, 'A' AS LOS_TYPE_CD,"
				+ "           MST.CLASS_CD AS SEG_CD  FROM WWL01080_IBO_INF_MST MST,"
				+ "           WWL01010_BNS_CUST_MST CUST, WWL01010_BNS_CUST_MST CUST2"
				+ "     WHERE     CUST.AFF_NO = MST.AFF_ID  AND CUST.IBO_NO = MST.IBO_NO "
				+ "           AND CUST2.AFF_NO = MST.SPON_AFF_ID  AND CUST2.IBO_NO = MST.SPON_IBO_NO "
				+ "           AND MST.prg_stat_cd <> 'D' "
				+ "           AND TRIM(MST.BUS_STAT_CD) IN (:customerStatusCodes) "
				+ "           AND TRIM(MST.AMWAY_BUS_INACT_CD) IN (:businessNatures) "
				+ "           AND MST.SPON_AFF_ID = :aff AND MST.SPON_IBO_NO = :abo ";
		// @formatter:on
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("aff", aff);
		((MapSqlParameterSource) namedParameters).addValue("abo", abo);
		((MapSqlParameterSource) namedParameters).addValue(BUSINESS_NATURES,
				modelLosDetailsRequest.getBusinessNatures());
		((MapSqlParameterSource) namedParameters).addValue(CUSTOMER_STATUS_CODES, customerStatusCodes);
		return namedParameterJdbcTemplate.query(sql, namedParameters, new BasicServiceOutputMapper());
	}

	private List<BasicServiceOutputData> getFrontlinersByType(final int aff, final List<Long> aboList,
			final ModelLosDetailsRequest modelLosDetailsRequest, final List<String> customerStatusCodes,
			final String fType) {
		// @formatter:off
		String sql = "SELECT CUST.BNS_CUST_ID, intlmst.AFF_ID AS AFF_NO, intlmst.IBO_NO, "
				+ "       '' AS CUST_NM, MST2.BUS_STAT_CD AS CUST_STAT_CD, "
				+ "       CUST2.BNS_CUST_ID AS SPON_CUST_ID, intlmst.SPON_IBO_NO, "
				+ "       intlmst.SPON_AFF_ID, CUST.BUS_ENTTY_NO, "
				+ "       MST2.CLASS_CD AS CUST_CLASS_CD, MST2.AMWAY_BUS_INACT_CD AS BUS_NATR_CD, "
				+ "       MST2.AMWAY_CNTRY_CD, 2 AS LOS_LVL_NO, intlmst.LOS_TYPE_CD, "
				+ "       MST2.CLASS_CD AS SEG_CD FROM WWL01080_IBO_INF_MST mst, "
				+ "       WWL01080_IBO_INF_MST mst2, WWL01160_IBO_SPON_MST intlmst, "
				+ "       WWL01010_BNS_CUST_MST cust, WWL01010_BNS_CUST_MST cust2, TTL02000_LOS_DTL_SVC temp "
				+ " WHERE     intlmst.LOS_TYPE_CD = :fType AND mst.AFF_ID = intlmst.SPON_AFF_ID "
				+ "       AND mst.IBO_NO = intlmst.SPON_IBO_NO AND mst2.IBO_NO = intlmst.IBO_NO "
				+ "       AND mst2.AFF_ID = intlmst.AFF_ID AND mst.PRG_STAT_CD <> 'D' "
				+ "       AND cust.AFF_NO = intlmst.AFF_ID AND cust.IBO_NO = intlmst.IBO_NO "
				+ "       AND cust2.AFF_NO = intlmst.SPON_AFF_ID AND cust2.IBO_NO = intlmst.SPON_IBO_NO "
				+ "       AND intlmst.SPON_AFF_ID = :aff AND intlmst.SPON_IBO_NO = temp.BNS_CUST_ID "
				+ "       AND TRIM(mst.BUS_STAT_CD) IN (:customerStatusCodes) "
				+ "       AND TRIM(mst2.BUS_STAT_CD) IN (:customerStatusCodes) "
				+ "       AND TRIM(mst.AMWAY_BUS_INACT_CD) IN (:businessNatures) "
				+ "       AND TRIM(mst2.AMWAY_BUS_INACT_CD) IN (:businessNatures) ";
		// @formatter:on
		try {
			JdbcTemplate scdsJdbcTemplate = DBUtil.getSingleConnectionJdbcTemplate(this.jdbcTemplate);
			NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(scdsJdbcTemplate);
			scdsJdbcTemplate.batchUpdate("INSERT INTO TTL02000_LOS_DTL_SVC(BNS_CUST_ID) VALUES(?)",
					new BatchPreparedStatementSetter() {
						public int getBatchSize() {
							return aboList.size();
						}

						public void setValues(PreparedStatement ps, int i) throws SQLException {
							ps.setLong(1, aboList.get(i));
						}
					});
			SqlParameterSource namedParameters = new MapSqlParameterSource();
			((MapSqlParameterSource) namedParameters).addValue("aff", aff);
			((MapSqlParameterSource) namedParameters).addValue("fType", fType);
			((MapSqlParameterSource) namedParameters).addValue("aboList", aboList);
			((MapSqlParameterSource) namedParameters).addValue(BUSINESS_NATURES,
					modelLosDetailsRequest.getBusinessNatures());
			((MapSqlParameterSource) namedParameters).addValue(CUSTOMER_STATUS_CODES, customerStatusCodes);
			List<BasicServiceOutputData> resultList = npJdbcTemplate.query(sql, namedParameters,
					new BasicServiceOutputMapper());
			DBUtil.commitConnection(scdsJdbcTemplate);
			DBUtil.releaseConnection(scdsJdbcTemplate);
			return resultList;
		} catch (Exception e) {
			throw new DataAccessResourceFailureException("Unable to create single connnection ds", e);
		}
	}

	private List<BasicServiceOutputData> getNonIMFrontliners(final int aff, final long abo,
			final ModelLosDetailsRequest modelLosDetailsRequest, final List<String> customerStatusCodes,
			final String sponType) {
		// @formatter:off
		String sql = "SELECT CUST.BNS_CUST_ID, intlmst.AFF_ID AS AFF_NO, intlmst.IBO_NO, "
				+ "       '' AS CUST_NM, MST2.BUS_STAT_CD AS CUST_STAT_CD, "
				+ "       CUST2.BNS_CUST_ID AS SPON_CUST_ID, intlmst.SPON_IBO_NO, "
				+ "       intlmst.SPON_AFF_ID, CUST.BUS_ENTTY_NO, "
				+ "       MST2.CLASS_CD AS CUST_CLASS_CD, MST2.AMWAY_BUS_INACT_CD AS BUS_NATR_CD, "
				+ "       MST2.AMWAY_CNTRY_CD, 2 AS LOS_LVL_NO, intlmst.LOS_TYPE_CD, "
				+ "       MST2.CLASS_CD AS SEG_CD FROM WWL01080_IBO_INF_MST mst, "
				+ "       WWL01080_IBO_INF_MST mst2, WWL01160_IBO_SPON_MST intlmst, "
				+ "       WWL01010_BNS_CUST_MST cust, WWL01010_BNS_CUST_MST cust2 "
				+ " WHERE     intlmst.LOS_TYPE_CD = :sponType AND mst.AFF_ID = intlmst.SPON_AFF_ID "
				+ "       AND mst.IBO_NO = intlmst.SPON_IBO_NO AND mst2.IBO_NO = intlmst.IBO_NO "
				+ "       AND mst2.AFF_ID = intlmst.AFF_ID AND mst.PRG_STAT_CD <> 'D' "
				+ "       AND cust.AFF_NO = intlmst.AFF_ID AND cust.IBO_NO = intlmst.IBO_NO "
				+ "       AND cust2.AFF_NO = intlmst.SPON_AFF_ID AND cust2.IBO_NO = intlmst.SPON_IBO_NO "
				+ "       AND intlmst.SPON_AFF_ID = :aff AND intlmst.SPON_IBO_NO = :abo "
				+ "       AND TRIM(mst.BUS_STAT_CD) IN (:customerStatusCodes) "
				+ "       AND TRIM(mst2.BUS_STAT_CD) IN (:customerStatusCodes) "
				+ "       AND TRIM(mst.AMWAY_BUS_INACT_CD) IN (:businessNatures) "
				+ "       AND TRIM(mst2.AMWAY_BUS_INACT_CD) IN (:businessNatures) ";
		// @formatter:on
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("aff", aff);
		((MapSqlParameterSource) namedParameters).addValue("abo", abo);
		((MapSqlParameterSource) namedParameters).addValue("sponType", sponType);
		((MapSqlParameterSource) namedParameters).addValue(BUSINESS_NATURES,
				modelLosDetailsRequest.getBusinessNatures());
		((MapSqlParameterSource) namedParameters).addValue(CUSTOMER_STATUS_CODES, customerStatusCodes);
		return namedParameterJdbcTemplate.query(sql, namedParameters, new BasicServiceOutputMapper());
	}

	/**
	 * Gets the band G frontliners from gloss by customer.
	 *
	 * @param aff                    the aff
	 * @param abo                    the abo
	 * @param modelLosDetailsRequest the model los details request
	 * @param customerStatusCodes    the customer status codes
	 * @return the band G frontliners from gloss by customer
	 */
	private List<BasicServiceOutputData> getFrontlinersByCustomerByType(final int aff, final long abo,
			final ModelLosDetailsRequest modelLosDetailsRequest, final List<String> customerStatusCodes,
			final String fType) {
		final List<Long> aboList = Collections.singletonList(abo);
		return getFrontlinersByType(aff, aboList, modelLosDetailsRequest, customerStatusCodes, fType);
	}

}
