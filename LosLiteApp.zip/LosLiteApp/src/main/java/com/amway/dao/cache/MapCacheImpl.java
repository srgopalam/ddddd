package com.amway.dao.cache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.amway.dao.AffiliateMaster;
import com.amway.dao.CountryMaster;
import com.amway.model.AffiliateMasterData;
import com.amway.model.BonusAwardMaster;
import com.amway.model.CountryMasterData;
import com.amway.service.CaffeineCacheService;

@Component
public class MapCacheImpl implements MapCache {
	@Autowired
	protected JdbcTemplate jTemplate;

	@Autowired
	protected CaffeineCacheService caffeineCacheService;

	@Autowired
	protected AffiliateMaster affiliateMaster;

	@Autowired
	protected CountryMaster countryMaster;

	@Override
	public Map<Integer, BonusAwardMaster> getAllBonusAwardsMap() {
		List<BonusAwardMaster> bnsAwards = caffeineCacheService.getAllBonusAwards();
		Map<Integer, BonusAwardMaster> awardMap = new HashMap<>();
		for (BonusAwardMaster bnsAward : bnsAwards) {
			awardMap.put(bnsAward.getBonusAwardNo(), bnsAward);
		}
		return awardMap;
	}

	@Override
	public Map<Integer, AffiliateMasterData> getAllAffiliatesDataMap() {
		return affiliateMaster.getAllAffiliatesDataMap();
	}

	@Override
	public Map<String, CountryMasterData> getAllCountryDataMap() {
		return countryMaster.getAllCountryDataMap();
	}
}