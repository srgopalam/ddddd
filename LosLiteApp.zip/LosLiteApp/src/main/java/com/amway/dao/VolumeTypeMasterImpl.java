package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.amway.model.VolumeTypeMasterData;

@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class VolumeTypeMasterImpl implements VolumeTypeMaster {
	@Autowired
	protected JdbcTemplate jTemplate;

	@Override
	public List<VolumeTypeMasterData> getAllVolumeTypesData() {
		String sql = "SELECT VOL_TYPE_CD,VOL_TYPE_NM,VOL_TYPE_DESC,VOL_TYPE_GRP_CD FROM WWL03680_VOL_TYPE_MST";
		return jTemplate.query(sql, new VolumeTypeMasterRowMapper());
	}

	public class VolumeTypeMasterRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			VolumeTypeMasterData volumeTypeMasterData = new VolumeTypeMasterData();
			volumeTypeMasterData.setVolumeTypeCode(rs.getString("VOL_TYPE_CD"));
			volumeTypeMasterData.setVolumeTypeName(rs.getString("VOL_TYPE_NM"));
			volumeTypeMasterData.setVolumeTypeDesc(rs.getString("VOL_TYPE_DESC"));
			volumeTypeMasterData.setVolumeTypeGroupCode(rs.getString("VOL_TYPE_GRP_CD"));
			return volumeTypeMasterData;
		}
	}
}
