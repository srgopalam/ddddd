package com.amway.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.amway.domain.include.UplineInfo;

public interface UplineInfoDao {

	Map<Long, UplineInfo> getUplineInfoFrmGloss(NamedParameterJdbcTemplate namedParameterJdbcTemplate);

	Map<Long, UplineInfo> getUplineInfoFrmMagic(int bnsPeriod, NamedParameterJdbcTemplate namedParameterJdbcTemplate);

	Map<Long, Long> getPlatinumSponsor(int bnsPeriod, NamedParameterJdbcTemplate namedParameterJdbcTemplate);

	Set<Long> getSponsoredSet(final boolean fromGloss, final int bnsPeriod, final List<String> customerStatusCodes,
			final Set<String> businessNatures, final NamedParameterJdbcTemplate namedParameterJdbcTemplate);

	Set<Long> getSponsoredSetIntl(final int bnsPeriod, final List<String> customerStatusCodes,
			final Set<String> businessNatures, final NamedParameterJdbcTemplate namedParameterJdbcTemplate);

	JdbcTemplate getSingleConnectionJdbcTemplate();
}
