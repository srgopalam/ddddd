package com.amway.dao;

import com.amway.domain.CustomerData;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.domain.list.Details;
import com.amway.exception.EmptyResultException;
import com.amway.model.BasicServiceOutputData;
import com.amway.model.BonusCustomerSegmentData;
import com.amway.service.CacheService;
import com.amway.util.DBUtil;
import com.amway.util.LOSType;
import com.amway.util.mappers.BasicServiceOutputMapper;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import javax.sql.DataSource;
import javax.validation.ConstraintViolation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

@Component
@SuppressWarnings("unchecked")
public class DetailMagicImpl extends DetailImpl {
	private static final Set<? extends ConstraintViolation<?>> constraintViolations = new HashSet<>();
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private JdbcTemplate jdbcTemplate;

	@Autowired
	@Override
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Autowired
	private BonusCustomerSegment bonusCustomerSegment;

	@Autowired
	private CacheService cacheService;

	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	/**
	 * Gets the data for requested.
	 *
	 * @param customerData           the customer data
	 * @param modelLosDetailsRequest the model los details request
	 * @param period                 the volume detail period
	 * @param customerStatusCodes    the customer status codes
	 * @return the data for requested
	 * @throws Exception
	 */
	@Override
	public List<Details> getListDataForRequested(CustomerData customerData,
			ModelLosDetailsRequest modelLosDetailsRequest, int period,
			List<String> customerStatusCodes) {
		BasicServiceOutputData basicServiceOutputData;
		basicServiceOutputData = getAData(customerData, period, customerStatusCodes);
		List<BasicServiceOutputData> downlineList = new ArrayList<>();
		long bonusCustId = customerData.getCustomerId();
		int aff = customerData.getAff();
		long abo = customerData.getAbo();
		if (modelLosDetailsRequest.isIncludeMap() || modelLosDetailsRequest.isIncludeFrontline()) {
			downlineList = mapDownlines(period, customerStatusCodes, modelLosDetailsRequest,
					bonusCustId, aff, abo);
		}
		if (!modelLosDetailsRequest.isIncludeMap()) {
			addInternationalAndGMBForRequested(customerData, modelLosDetailsRequest, customerStatusCodes, period,
					downlineList);
		}
		String segmentCode = bonusCustomerSegment.getSegment(bonusCustId, period, namedParameterJdbcTemplate);
		Details details = new Details();
		List<Details> detailsList = new ArrayList<>();
		details.setAff(customerData.getAff());
		details.setAbo(customerData.getAbo());
		details.setSponsorAbo(basicServiceOutputData.getSponsorAbo());
		details.setBonusCustomerId(basicServiceOutputData.getBonusCustomer());
		details.setSponsorCustomerId(basicServiceOutputData.getSponsorCustomerId());
		details.setBusinessEntity(basicServiceOutputData.getBusinessEntity());
		details.setLosType(basicServiceOutputData.getLosTypeCode());
		details.setSegmentCode(StringUtils.isEmpty(segmentCode) ? DEFAULT_CLASS_CODE : segmentCode);
		mapBnAndStatus(modelLosDetailsRequest, basicServiceOutputData, details);
		detailsList.add(details);
		for (BasicServiceOutputData data : nullSafe(downlineList)) {
			details = new Details();
			details.setAff(data.getAff());
			details.setAbo(data.getAbo());
			details.setSponsorAbo(data.getSponsorAbo());
			details.setBonusCustomerId(data.getBonusCustomer());
			details.setSponsorCustomerId(data.getSponsorCustomerId());
			details.setBusinessEntity(data.getBusinessEntity());
			details.setLosType(data.getLosTypeCode());
			details.setSegmentCode(
					StringUtils.isEmpty(data.getSegmentCode()) ? DEFAULT_CLASS_CODE : data.getSegmentCode());
			mapBnAndStatus(modelLosDetailsRequest, data, details);

			detailsList.add(details);
		}
		return detailsList;
	}

	private void mapBnAndStatus(ModelLosDetailsRequest modelLosDetailsRequest,
			BasicServiceOutputData basicServiceOutputData, Details details) {
		if (modelLosDetailsRequest.isIncludeAboAttr() || modelLosDetailsRequest.isIncludeInactive()) {
			details.setStatus(basicServiceOutputData.getBusinessStatusCode());
		}
		if (modelLosDetailsRequest.isIncludeAboAttr() || modelLosDetailsRequest.isShowBusinessNatureProperty()) {
			details.setBusinessNature(basicServiceOutputData.getBusinessNature());
		}
	}

	private void addInternationalAndGMBForRequested(CustomerData customerData,
			ModelLosDetailsRequest modelLosDetailsRequest, List<String> customerStatusCodes, int period,
			List<BasicServiceOutputData> downlineList) {
		if (modelLosDetailsRequest.isIncludeInternational()) {
			downlineList.addAll(getNonIMFrontliners(customerData.getAff(), customerData.getAbo(), period,
					modelLosDetailsRequest, customerStatusCodes, LOSType.MONTHLY_INTERNATIONAL_SPONSOR.getMagicCode()));

		}
		if (modelLosDetailsRequest.isIncludeGlobalMB()) {
			downlineList.addAll(getNonIMFrontliners(customerData.getAff(), customerData.getAbo(), period,
					modelLosDetailsRequest, customerStatusCodes, LOSType.GLOBAL_MULTI_BUSINESS_SPONSOR.getMagicCode()));
		}
	}

	private Collection<? extends BasicServiceOutputData> getNonIMFrontliners(final int aff, final long abo,
			final int period, final ModelLosDetailsRequest modelLosDetailsRequest,
			final List<String> customerStatusCodes, final String losType) {
		// @formatter:off
		String sql = "SELECT tbl1.bns_cust_id, spon2.aff_no, spon2.ibo_no, per.cust_nm, per.cust_stat_cd, TBL1.CUST_SPON_ID AS SPON_CUST_ID, "
				+ " spon.ibo_no AS SPON_IBO_NO,  spon.aff_no AS SPON_AFF_ID, PER.BUS_ENTTY_NO,  per.cust_class_cd,  per.bus_natr_cd, "
				+ " per.AMWAY_CNTRY_CD, 2 AS LOS_LVL_NO, '' AS SEG_CD, CASE WHEN TBL1.SPON_TYPE_CD = 'mn' THEN 'B' "
				+ " WHEN TBL1.SPON_TYPE_CD = 'gm' THEN 'G' END AS LOS_TYPE_CD "
				+ " FROM WWL03290_CUST_SPON_DTL TBL1, WWL01010_bns_cust_mst spon, WWL01010_bns_cust_mst spon2, WWL03250_CUST_PER_DTL per "
				+ " WHERE per.bns_per_no = TBL1.bns_per_no AND per.BNS_CUST_ID = tbl1.bns_cust_id "
				+ " AND spon.aff_no = :aff AND spon.ibo_no = :abo AND TBL1.BNS_PER_NO = :period "
				+ " AND TBL1.SPON_TYPE_CD = :losType AND TRIM(PER.BUS_NATR_CD) IN (:businessNatures) "
				+ " AND TRIM(PER.CUST_STAT_CD) IN (:customerStatusCodes) AND spon.bns_cust_id = TBL1.CUST_SPON_ID AND spon2.bns_cust_id = TBL1.BNS_CUST_ID ";
		// @formatter:on
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("aff", aff);
		((MapSqlParameterSource) namedParameters).addValue("abo", abo);
		((MapSqlParameterSource) namedParameters).addValue(PERIOD, period);
		((MapSqlParameterSource) namedParameters).addValue("losType", losType);
		((MapSqlParameterSource) namedParameters).addValue(BUSINESS_NATURES,
				modelLosDetailsRequest.getBusinessNatures());
		((MapSqlParameterSource) namedParameters).addValue(CUSTOMER_STATUS_CODES, customerStatusCodes);
		return namedParameterJdbcTemplate.query(sql, namedParameters, new BasicServiceOutputMapper());

	}

	/**
	 * Map downlines from magic.
	 *
	 * @param period                 the period
	 * @param customerStatusCodes    the customer status codes
	 * @param modelLosDetailsRequest the model los details request
	 * @param internationalList      the international list
	 * @param bSet                   the b set
	 * @param gSet                   the g set
	 * @param segment2List           the segment 2 list
	 * @param bonusCustId            the bonus cust id
	 * @param aff                    the aff
	 * @param abo                    the abo
	 * @return the list
	 * @throws ExecutionException
	 * @throws InterruptedException
	 */
	private List<BasicServiceOutputData> mapDownlines(final int period,
			final List<String> customerStatusCodes, final ModelLosDetailsRequest modelLosDetailsRequest,
			long bonusCustId, int aff, long abo) {
		List<Long> segment2List = new ArrayList<>();
		List<BasicServiceOutputData> downlineList = new ArrayList<>();
		List<Long> aCustomerList = new ArrayList<>();
		if (!cacheService.getExclusableCustomers(cacheService.isCacheEnabled()).contains(bonusCustId)) {
			downlineList = getADownlinesWithoutConnectBy(period, bonusCustId, customerStatusCodes,
					modelLosDetailsRequest);
		}
		for (BasicServiceOutputData data : nullSafe(downlineList)) {
			if (data.getLosLevelNo() > 1 && PLATINUM_CLASS_CODE.equals(data.getAboClass())) {
				segment2List.add(data.getBonusCustomer());
			}
			aCustomerList.add(data.getBonusCustomer());
		}
		if (modelLosDetailsRequest.isIncludeInternational() && modelLosDetailsRequest.isIncludeMap()) {
			mapInternationalByType(period, customerStatusCodes, modelLosDetailsRequest, segment2List, aCustomerList,
					aff, abo, downlineList, LOSType.MONTHLY_INTERNATIONAL_SPONSOR.getMagicCode());
		}
		if (modelLosDetailsRequest.isIncludeGlobalMB() && modelLosDetailsRequest.isIncludeMap()) {
			mapInternationalByType(period, customerStatusCodes, modelLosDetailsRequest, segment2List, aCustomerList,
					aff, abo, downlineList, LOSType.GLOBAL_MULTI_BUSINESS_SPONSOR.getMagicCode());
		}
		return downlineList;
	}

	/**
	 * Map international from magic.
	 *
	 * @param period                 the period
	 * @param customerStatusCodes    the customer status codes
	 * @param modelLosDetailsRequest the model los details request
	 * @param internationalList      the international list
	 * @param bSet                   the b set
	 * @param gSet                   the g set
	 * @param segment2List           the segment 2 list
	 * @param aCustomerList          the a customer list
	 * @param aff                    the aff
	 * @param abo                    the abo
	 * @param bonusCustId            the bonus cust id
	 * @param downlineList           the downline list
	 */
	private void mapInternationalByType(final int period, final List<String> customerStatusCodes,
			final ModelLosDetailsRequest modelLosDetailsRequest, List<Long> segment2List, List<Long> aCustomerList,
			int aff, long abo, List<BasicServiceOutputData> downlineList, String fType) {
		List<BasicServiceOutputData> internationalList = new ArrayList<>();
		internationalList.addAll(getFrontlinersFromMagicByCustomerByType(period, aff, abo, modelLosDetailsRequest,
				customerStatusCodes, fType));
		internationalList.addAll(
				getFrontlinersByType(period, aCustomerList, modelLosDetailsRequest, customerStatusCodes, fType));
		for (BasicServiceOutputData data : nullSafe(internationalList)) {
			if (!segment2List.contains(data.getSponsorCustomerId())) {
				downlineList.add(data);
			}
		}
	}

	/**
	 * Gets the a data from magic.
	 *
	 * @param customerData        the customer data
	 * @param volumeDetailPeriod  the volume detail period
	 * @param customerStatusCodes the customer status codes
	 * @return the a data from magic
	 */
	private BasicServiceOutputData getAData(CustomerData customerData, int period, List<String> customerStatusCodes) {
		// @formatter:off
		String sql = "SELECT tbl1.BNS_CUST_ID, spon2.AFF_NO, spon2.IBO_NO,"
				+ "       per.CUST_STAT_CD, per.CUST_NM, spon.bns_cust_id AS SPON_CUST_ID,"
				+ "       spon.IBO_NO AS SPON_IBO_NO, spon.AFF_NO AS SPON_AFF_ID,"
				+ "       per.BUS_ENTTY_NO, per.CUST_CLASS_CD, per.BUS_NATR_CD,"
				+ "       per.AMWAY_CNTRY_CD, 1 AS LOS_LVL_NO, 'A' AS LOS_TYPE_CD,"
				+ "       '' AS SEG_CD FROM WWL03290_CUST_SPON_DTL tbl1, WWL01010_BNS_CUST_MST spon,"
				+ "       WWL03250_CUST_PER_DTL per, WWL01010_BNS_CUST_MST spon2"
				+ " WHERE     per.BNS_CUST_ID = tbl1.BNS_CUST_ID AND spon.BNS_CUST_ID = tbl1.CUST_SPON_ID"
				+ "       AND spon2.BNS_CUST_ID = tbl1.BNS_CUST_ID AND per.BNS_PER_NO = tbl1.BNS_PER_NO"
				+ "       AND tbl1.BNS_PER_NO = :period AND tbl1.SPON_TYPE_CD = :inMarketSponType"
				+ "       AND tbl1.BNS_CUST_ID = :bonusCustId";
		// @formatter:on
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue(PERIOD, period);
		((MapSqlParameterSource) namedParameters).addValue("inMarketSponType", IN_MARKET_SPON_TYPE);
		((MapSqlParameterSource) namedParameters).addValue(BONUS_CUST_ID, customerData.getCustomerId());
		((MapSqlParameterSource) namedParameters).addValue(CUSTOMER_STATUS_CODES, customerStatusCodes);
		BasicServiceOutputData data;

		try {
			data = (BasicServiceOutputData) namedParameterJdbcTemplate.queryForObject(sql, namedParameters,
					new BasicServiceOutputMapper());
		} catch (EmptyResultDataAccessException ex) {
			throw new EmptyResultException("No records were found that match the specified search criteria!",
					constraintViolations);
		}

		return data;
	}

	private List<BasicServiceOutputData> getADownlinesWithoutConnectBy(int period, long bonusCustId,
			List<String> customerStatusCodes, ModelLosDetailsRequest modelLosDetailsRequest) {
		List<BasicServiceOutputData> aDownlineList = new ArrayList<>();
		if (modelLosDetailsRequest.isIncludeFrontline() && !modelLosDetailsRequest.isIncludeMap()) {
			return getAFrontliners(period, bonusCustId, customerStatusCodes, modelLosDetailsRequest);
		} else {
			List<Long> custList = new ArrayList<>();
			custList.add(bonusCustId);
			List<Long> nonPlatinumCustList = new ArrayList<>();
			List<BasicServiceOutputData> nextLevelList = new ArrayList<>();
			int level = 2;
			Map<Long, String> segmentMap = new HashMap<>();
			List<Long> custListToGetSegment = new ArrayList<>();
			custListToGetSegment.add(bonusCustId);
			List<BonusCustomerSegmentData> segmentDataList = new ArrayList<>();
			FrontlinerImpl frontliner = new FrontlinerImpl();
			JdbcTemplate scdsJdbcTemplate = DBUtil.getSingleConnectionJdbcTemplate(this.jdbcTemplate);
			NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(scdsJdbcTemplate);
			do {
				nonPlatinumCustList.clear();
				nextLevelList.clear();
				nextLevelList.addAll(frontliner.getAFrontlinersMagic(period, IN_MARKET_SPON_TYPE, custList,
						customerStatusCodes, modelLosDetailsRequest, level++, scdsJdbcTemplate, npJdbcTemplate));
				if (!nextLevelList.isEmpty()) {
					mapNextLevel(period, nonPlatinumCustList, nextLevelList, segmentMap, custListToGetSegment,
							segmentDataList, scdsJdbcTemplate, npJdbcTemplate);
				}
				custList.clear();
				custList.addAll(nonPlatinumCustList);
				aDownlineList.addAll(nextLevelList);
			} while (!nonPlatinumCustList.isEmpty());
			DBUtil.releaseConnection(scdsJdbcTemplate);
		}
		return aDownlineList;

	}

	private void mapNextLevel(int period, List<Long> nonPlatinumCustList, List<BasicServiceOutputData> nextLevelList,
			Map<Long, String> segmentMap, List<Long> custListToGetSegment,
			List<BonusCustomerSegmentData> segmentDataList, JdbcTemplate scdsJdbcTemplate,
			NamedParameterJdbcTemplate npJdbcTemplate) {
		for (BasicServiceOutputData data : nullSafe(nextLevelList)) {
			custListToGetSegment.add(data.getBonusCustomer());
		}

		segmentDataList.addAll(
				bonusCustomerSegment.getSegmentData(custListToGetSegment, period, scdsJdbcTemplate, npJdbcTemplate));

		for (BonusCustomerSegmentData data : segmentDataList) {
			segmentMap.put(data.getBonusCustomerId(), data.getSegmentCode());
		}
		segmentDataList.clear();
		custListToGetSegment.clear();
		for (BasicServiceOutputData data : nullSafe(nextLevelList)) {
			data.setSegmentCode(segmentMap.get(data.getBonusCustomer()));
			if (!PLATINUM_CLASS_CODE.equals(data.getSegmentCode())) {
				nonPlatinumCustList.add(data.getBonusCustomer());
			}
		}
	}

	private List<BasicServiceOutputData> getAFrontliners(int period, long bonusCustId,
			List<String> customerStatusCodes, ModelLosDetailsRequest modelLosDetailsRequest) {
		// @formatter:off
		String sql = "    SELECT tbl1.BNS_CUST_ID, spon2.AFF_NO, spon2.IBO_NO, "
				+ "           per.CUST_STAT_CD, per.CUST_NM, "
				+ "           spon.bns_cust_id AS SPON_CUST_ID, spon.IBO_NO AS SPON_IBO_NO, "
				+ "           spon.AFF_NO AS SPON_AFF_ID, per.BUS_ENTTY_NO, "
				+ "           per.CUST_CLASS_CD, per.BUS_NATR_CD, per.AMWAY_CNTRY_CD, "
				+ "           2 AS LOS_LVL_NO, 'A' AS LOS_TYPE_CD, "
				+ "           TRIM(TBL2.SEG_CD) AS SEG_CD FROM WWL03290_CUST_SPON_DTL TBL1, "
				+ "           WWL03088_CUST_SEG_PER_DTL TBL2, WWL03250_CUST_PER_DTL per, "
				+ "           WWL01010_bns_cust_mst spon, WWL01010_bns_cust_mst spon2 "
				+ "     WHERE     TBL2.BNS_CUST_ID(+) = TBL1.BNS_CUST_ID "
				+ "           AND TBL2.bns_per_no(+) = TBL1.bns_per_no "
				+ "           AND per.BNS_CUST_ID = tbl1.bns_cust_id "
				+ "           AND per.BNS_PER_NO = TBL1.bns_per_no "
				+ "           AND spon.bns_cust_id = TBL1.CUST_SPON_ID "
				+ "           AND spon2.BNS_CUST_ID = tbl1.BNS_CUST_ID "
				+ "           AND TRIM (PER.CUST_STAT_CD) IN ( :customerStatusCodes) "
				+ "           AND TRIM (PER.BUS_NATR_CD) IN (:businessNatures) "
				+ "           AND TBL1.CUST_SPON_ID = :bonusCustId AND TBL1.BNS_PER_NO = :period "
				+ "           AND TBL1.SPON_TYPE_CD = :sponType ";
		// @formatter:on
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue(PERIOD, period);
		((MapSqlParameterSource) namedParameters).addValue("sponType", IN_MARKET_SPON_TYPE);
		((MapSqlParameterSource) namedParameters).addValue(BONUS_CUST_ID, bonusCustId);
		((MapSqlParameterSource) namedParameters).addValue(BUSINESS_NATURES,
				modelLosDetailsRequest.getBusinessNatures());
		((MapSqlParameterSource) namedParameters).addValue(CUSTOMER_STATUS_CODES, customerStatusCodes);
		return namedParameterJdbcTemplate.query(sql, namedParameters, new BasicServiceOutputMapper());
	}

	/**
	 * Gets the band G frontliners from magic.
	 *
	 * @param period                 the period
	 * @param customerList           the customer list
	 * @param modelLosDetailsRequest the model los details request
	 * @param customerStatusCodes    the customer status codes
	 * @param excludeNo2             the exclude no 2
	 * @return the band G frontliners from magic
	 */
	private List<BasicServiceOutputData> getFrontlinersByType(final int period, final List<Long> customerList,
			final ModelLosDetailsRequest modelLosDetailsRequest, final List<String> customerStatusCodes,
			final String fType) {
		// @formatter:off
		String sql = "SELECT tbl1.bns_cust_id, spon2.aff_no, spon2.ibo_no, "
				+ "       per.cust_nm, per.cust_stat_cd, TBL1.CUST_SPON_ID AS SPON_CUST_ID, "
				+ "       spon.ibo_no AS SPON_IBO_NO,  spon.aff_no AS SPON_AFF_ID, "
				+ "       PER.BUS_ENTTY_NO,  per.cust_class_cd,  per.bus_natr_cd, "
				+ "       per.AMWAY_CNTRY_CD, 2 AS LOS_LVL_NO, '' AS SEG_CD, CASE "
				+ "          WHEN TBL1.SPON_TYPE_CD = 'mn' THEN 'B' "
				+ "          WHEN TBL1.SPON_TYPE_CD = 'gm' THEN 'G' END AS LOS_TYPE_CD "
				+ "  FROM WWL03290_CUST_SPON_DTL TBL1, WWL01010_bns_cust_mst spon, "
				+ "       WWL01010_bns_cust_mst spon2, WWL03250_CUST_PER_DTL per, TTL02000_LOS_DTL_SVC temp "
				+ " WHERE     per.bns_per_no = TBL1.bns_per_no AND per.BNS_CUST_ID = tbl1.bns_cust_id "
				+ "       AND spon.bns_cust_id = temp.bns_cust_id AND TBL1.BNS_PER_NO = :period "
				+ "       AND TBL1.SPON_TYPE_CD = :fType " + "       AND TRIM(PER.BUS_NATR_CD) IN (:businessNatures) "
				+ "       AND TRIM(PER.CUST_STAT_CD) IN (:customerStatusCodes) "
				+ "       AND spon.bns_cust_id = TBL1.CUST_SPON_ID "
				+ "       AND spon2.bns_cust_id = TBL1.BNS_CUST_ID ";
		// @formatter:on
		try {
			JdbcTemplate scdsJdbcTemplate = DBUtil.getSingleConnectionJdbcTemplate(this.jdbcTemplate);
			NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(scdsJdbcTemplate);
			scdsJdbcTemplate.batchUpdate("INSERT INTO TTL02000_LOS_DTL_SVC(BNS_CUST_ID) VALUES(?)",
					new BatchPreparedStatementSetter() {
						public int getBatchSize() {
							return customerList.size();
						}

						public void setValues(PreparedStatement ps, int i) throws SQLException {
							ps.setLong(1, customerList.get(i));
						}
					});

			SqlParameterSource namedParameters = new MapSqlParameterSource();
			((MapSqlParameterSource) namedParameters).addValue(PERIOD, period);
			((MapSqlParameterSource) namedParameters).addValue("fType", fType);
			((MapSqlParameterSource) namedParameters).addValue("customerList", customerList);
			((MapSqlParameterSource) namedParameters).addValue(BUSINESS_NATURES,
					modelLosDetailsRequest.getBusinessNatures());
			((MapSqlParameterSource) namedParameters).addValue(CUSTOMER_STATUS_CODES, customerStatusCodes);
			List<BasicServiceOutputData> resultList = npJdbcTemplate.query(sql, namedParameters,
					new BasicServiceOutputMapper());
			DBUtil.commitConnection(scdsJdbcTemplate);
			DBUtil.releaseConnection(scdsJdbcTemplate);
			return resultList;
		} catch (Exception e) {
			throw new DataAccessResourceFailureException("Unable to create single connnection ds", e);
		}
	}

	/**
	 * Gets the band G frontliners from magic by customer.
	 *
	 * @param period                 the period
	 * @param aff                    the aff
	 * @param abo                    the abo
	 * @param modelLosDetailsRequest the model los details request
	 * @param customerStatusCodes    the customer status codes
	 * @return the band G frontliners from magic by customer
	 */
	private List<BasicServiceOutputData> getFrontlinersFromMagicByCustomerByType(final int period, final int aff,
			final long abo, final ModelLosDetailsRequest modelLosDetailsRequest, final List<String> customerStatusCodes,
			final String fType) {
		// @formatter:off
		String sql = "SELECT tbl1.bns_cust_id, spon2.aff_no, spon2.ibo_no, "
				+ "       per.cust_nm, per.cust_stat_cd, TBL1.CUST_SPON_ID AS SPON_CUST_ID, "
				+ "       spon.ibo_no AS SPON_IBO_NO, spon.aff_no AS SPON_AFF_ID, "
				+ "       PER.BUS_ENTTY_NO, per.cust_class_cd, per.bus_natr_cd, "
				+ "       per.AMWAY_CNTRY_CD, 2 AS LOS_LVL_NO, '' AS SEG_CD, CASE "
				+ "          WHEN TBL1.SPON_TYPE_CD = 'mn' THEN 'B' "
				+ "          WHEN TBL1.SPON_TYPE_CD = 'gm' THEN 'G' END  AS LOS_TYPE_CD "
				+ "  FROM WWL03290_CUST_SPON_DTL TBL1, WWL01010_bns_cust_mst spon, "
				+ "       WWL01010_bns_cust_mst spon2, WWL03250_CUST_PER_DTL per "
				+ " WHERE     per.bns_per_no = TBL1.bns_per_no AND per.BNS_CUST_ID = tbl1.bns_cust_id "
				+ "       AND spon.aff_no = :aff AND spon.ibo_no = :abo "
				+ "       AND TBL1.BNS_PER_NO = :period AND TBL1.SPON_TYPE_CD = :fType "
				+ "       AND TRIM(PER.BUS_NATR_CD) IN (:businessNatures) "
				+ "       AND TRIM(PER.CUST_STAT_CD) IN (:customerStatusCodes) "
				+ "       AND spon.bns_cust_id = TBL1.CUST_SPON_ID "
				+ "       AND spon2.bns_cust_id = TBL1.BNS_CUST_ID ";
		// @formatter:on
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue(PERIOD, period);
		((MapSqlParameterSource) namedParameters).addValue("aff", aff);
		((MapSqlParameterSource) namedParameters).addValue("abo", abo);
		((MapSqlParameterSource) namedParameters).addValue("fType", fType);
		((MapSqlParameterSource) namedParameters).addValue(BUSINESS_NATURES,
				modelLosDetailsRequest.getBusinessNatures());
		((MapSqlParameterSource) namedParameters).addValue("customerStatusCodes", customerStatusCodes);
		return namedParameterJdbcTemplate.query(sql, namedParameters, new BasicServiceOutputMapper());
	}

}
