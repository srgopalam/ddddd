package com.amway.dao.cache;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.amway.model.BonusAwardMaster;
import com.amway.model.VolumeTypeMasterData;

@Service
public interface ListCache {
	public List<Integer> getAllAffiliates();

	public List<String> getAllVolumeTypeCodes();

	public List<String> getAllBusinessNatureCodes();

	public List<BonusAwardMaster> getAllBonusAwards();

	public Map<Integer, Integer> getLosBuildPeriodsByAffiliates();

	public Map<Integer, Integer> getCurrentBnsPeriodsByAffiliates();

	public Map<String, VolumeTypeMasterData> getAllVolumeTypesData();
	
	public List<Long> getExclusableCustomers();
}
