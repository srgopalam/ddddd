package com.amway.dao;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class SponsoringStatisticsImpl implements SponsoringStatistics {
	@Override
	public Map<Long, Integer> getGroupCounts(int period, NamedParameterJdbcTemplate namedParameterJdbcTemplate,
			Set<String> businessNatures) {
		String sql = "  SELECT spon.BNS_CUST_ID, SUM (spon.KEY_STATS_CNT) AS GRP_COUNT "
				+ "    FROM WWL03760_SPONG_STATS_DTL spon, TTL02000_LOS_DTL_SVC temp "
				+ "   WHERE     spon.BNS_CUST_ID = temp.BNS_CUST_ID AND spon.BNS_PER_NO = :period "
				+ "         AND spon.BNS_AWD_NO = 330 AND TRIM (spon.KEY_STATS_IND_CD) = 'GRP' "
				+ "         AND spon.EXTRC_ID = 0 AND TRIM (spon.BUS_NATR_CD) IN (:businessNatures) GROUP BY spon.BNS_CUST_ID ";
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		((MapSqlParameterSource) namedParameters).addValue("businessNatures", businessNatures);
		return namedParameterJdbcTemplate.query(sql, namedParameters, (ResultSet rs) -> {
			Map<Long, Integer> results = new HashMap<>();
			while (rs.next()) {
				results.put(rs.getLong("BNS_CUST_ID"), rs.getInt("GRP_COUNT"));
			}
			return results;
		});

	}
}
