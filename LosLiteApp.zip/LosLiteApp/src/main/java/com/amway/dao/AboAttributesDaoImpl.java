package com.amway.dao;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.amway.domain.include.AboAttributes;

@Component
public class AboAttributesDaoImpl implements AboAttributesDao {
	private static final String ORGNZ_CD = "ORGNZ_CD";

	@Override
	public Map<String, AboAttributes> getAboAttributes(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {

		String sql = "SELECT CUSTMST.BNS_CUST_ID,TRIM(NMMST.PHYS_NM) AS IBO_LOCAL_NAME, AMWAY_CNTRY_CD, TRIM(ISO_LANG_CD) AS ISO_LANG_CD, TO_CHAR(NMMST.BIRTH_DT,'yyyy-MM-dd') AS BIRTH_DT, "
				+ " TO_CHAR (CUSTMST.APP_ENTRY_DT, 'yyyy-MM-dd') AS ENTRY_DATE, TO_CHAR (IBO_MST.RNW_XPR_DT, 'yyyy-MM-dd') AS EXPIRY_DATE, TRIM(NMMST.NM_TYPE_CD) AS NM_TYPE_CD, TRIM(IBO_MST.ORGNZ_CD) AS ORGNZ_CD"
				+ " FROM WWL01100_IBO_NM_MST NMMST, WWL01010_BNS_CUST_MST CUSTMST, TTL02000_LOS_DTL_SVC temp, WWL01080_IBO_INF_MST IBO_MST"
				+ " WHERE CUSTMST.AFF_NO = NMMST.AFF_ID AND CUSTMST.IBO_NO = NMMST.IBO_NO AND CUSTMST.AFF_NO = IBO_MST.AFF_ID AND CUSTMST.IBO_NO = IBO_MST.IBO_NO"
				+ " AND TRIM(NMMST.NM_TYPE_CD) IN ('0','A','B') AND CUSTMST.BNS_CUST_ID = temp.BNS_CUST_ID";
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		return namedParameterJdbcTemplate.query(sql, namedParameters, (ResultSet rs) -> {
			Map<String, AboAttributes> results = new HashMap<>();
			while (rs.next()) {
				AboAttributes aboAttr = new AboAttributes();
				aboAttr.setAboName(rs.getString("IBO_LOCAL_NAME"));
				aboAttr.setCountry(rs.getInt("AMWAY_CNTRY_CD"));
				aboAttr.setIsoLanguage(rs.getString("ISO_LANG_CD"));
				aboAttr.setBirthDate(rs.getString("BIRTH_DT"));
				aboAttr.setEntryDate(rs.getString("ENTRY_DATE"));
				aboAttr.setExpireDate(rs.getString("EXPIRY_DATE"));
				// If is Legal Entity, Use Applicant 1 Name.
				if (null != rs.getString(ORGNZ_CD) && "Y".equals(rs.getString(ORGNZ_CD).trim())) {
					results.put(rs.getLong("BNS_CUST_ID") + rs.getString("NM_TYPE_CD") + rs.getString(ORGNZ_CD),
							aboAttr);
				} else {
					results.put(rs.getLong("BNS_CUST_ID") + rs.getString("NM_TYPE_CD"), aboAttr);
				}
			}
			return results;
		});
	}
}
