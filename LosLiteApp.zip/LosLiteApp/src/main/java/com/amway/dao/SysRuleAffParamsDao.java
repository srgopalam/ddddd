package com.amway.dao;

import com.amway.model.SysRuleAffPerCtl;

public interface SysRuleAffParamsDao {

	public SysRuleAffPerCtl get(int affiliate, int ruleId, int period);

}
