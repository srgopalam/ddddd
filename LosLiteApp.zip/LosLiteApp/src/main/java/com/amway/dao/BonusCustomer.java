package com.amway.dao;

import com.amway.model.BonusCustomerMaster;

public interface BonusCustomer {
	public BonusCustomerMaster getCustomerData(int aff, long abo) throws Exception;

	public BonusCustomerMaster getCustomerData(long bonusCustomer, int period) throws Exception;
}
