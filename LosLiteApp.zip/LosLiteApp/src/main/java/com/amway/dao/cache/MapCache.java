package com.amway.dao.cache;

import java.util.Map;

import com.amway.model.AffiliateMasterData;
import com.amway.model.BonusAwardMaster;
import com.amway.model.CountryMasterData;

public interface MapCache {
	Map<Integer, BonusAwardMaster> getAllBonusAwardsMap();

	Map<Integer, AffiliateMasterData> getAllAffiliatesDataMap();

	Map<String, CountryMasterData> getAllCountryDataMap();
}
