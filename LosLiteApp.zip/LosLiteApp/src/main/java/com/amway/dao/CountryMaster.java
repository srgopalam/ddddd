package com.amway.dao;

import java.util.Map;

import com.amway.model.CountryMasterData;

public interface CountryMaster {
	public Map<String, CountryMasterData> getAllCountryDataMap();
}