package com.amway.dao;

import java.util.List;
import java.util.Set;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.amway.model.PVBVDetailData;

public interface PVBVDetail {
	List<PVBVDetailData> getPVBVDataByVolumeType(NamedParameterJdbcTemplate namedParameterJdbcTemplate,
			Set<String> volumeTypes, int period);

	List<PVBVDetailData> getYtdPVBVDataByVolumeType(NamedParameterJdbcTemplate namedParameterJdbcTemplate,
			Set<String> volumeTypes, int period);
}
