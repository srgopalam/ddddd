package com.amway.dao;

import java.sql.Date;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public interface BlockPrivilegesDao {

	public boolean getIsDistBlocked(long bnsCustId, java.sql.Date sqlExpDate);

	Map<Long, Boolean> getIsDistBlocked(NamedParameterJdbcTemplate namedParameterJdbcTemplate, Date sqlExpDate);

}
