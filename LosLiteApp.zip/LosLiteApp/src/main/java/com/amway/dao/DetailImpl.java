package com.amway.dao;

import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

import com.amway.api.rest.MethodAsyncController;
import com.amway.domain.CustomerData;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.domain.RequestedCustomerData;
import com.amway.domain.list.Details;
import com.amway.domain.list.VolumeDetailPeriod;
import com.amway.domain.list.VolumeDetailPeriods;
import com.amway.util.DBUtil;
import com.amway.util.LOSType;
import com.amway.util.RESTFulServiceConsumer;
import com.amway.util.VolumeDetailFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class DetailImpl implements IDetail {
	private static final Logger LOGGER = LoggerFactory.getLogger(DetailImpl.class);
	public static final String DEFAULT_CLASS_CODE = "9";
	public static final String PLATINUM_CLASS_CODE = "2";
	public static final String CUSTOMER_STATUS_CODES = "customerStatusCodes";
	public static final String BUSINESS_NATURES = "businessNatures";
	public static final String POUND = "#";
	public static final int PERFORMANCE_BONUS_AWARD_NO = 10;
	public static final int LEADERSHIP_BONUS_AWARD_NO = 200;
	public static final int IN_CLAUSE_LIMIT = 1000;
	protected static final List<String> ACTIVE_ONLY_LIST = Arrays.asList("1", "3");
	protected static final List<String> ACTIVE_AND_INACTIVE_LIST = Arrays.asList("1", "2", "3", "X");
	public static final String PERIOD = "period";
	public static final String BONUS_CUST_ID = "bonusCustId";
	protected static final String IN_MARKET_SPON_TYPE = LOSType.MONTHLY_IN_MARKET_SPONSOR.getMagicCode();
	@Autowired
	private MethodAsyncController methodAsyncController;
	@Autowired
	private TaskExecutor executor;
	@Autowired
	private RESTFulServiceConsumer restConsumer;
	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * Gets the list data for requested.
	 *
	 * @param modelLosDetailsRequest    the model los details request
	 * @param requestedCustomerDataList the requested customer data list
	 * @return the list data for requested
	 * @throws Exception
	 */
	@Override
	public VolumeDetailPeriods getListDataForRequested(ModelLosDetailsRequest modelLosDetailsRequest,
			List<RequestedCustomerData> requestedCustomerDataList) {
		VolumeDetailPeriods volumeDetailPeriods = new VolumeDetailPeriods();
		List<String> customerStatusCodes = new ArrayList<>();
		if (modelLosDetailsRequest.isIncludeInactive()) {
			customerStatusCodes.addAll(ACTIVE_AND_INACTIVE_LIST);
		} else {
			customerStatusCodes.addAll(ACTIVE_ONLY_LIST);
		}

		List<VolumeDetailPeriod> volumeDetailPeriodList = new ArrayList<>();
		for (RequestedCustomerData requestedCustomerData : requestedCustomerDataList) {
			for (CustomerData customerData : requestedCustomerData.getCustomerData()) {
				VolumeDetailPeriod volumeDetailPeriod = new VolumeDetailPeriod();
				volumeDetailPeriod.setAff(customerData.getAff());
				volumeDetailPeriod.setAbo(customerData.getAbo());
				volumeDetailPeriod.setPeriod(requestedCustomerData.getPeriod());
				boolean authorised = true;
				if (modelLosDetailsRequest.getReqAff() > 0 && modelLosDetailsRequest.getReqAbo() > 0) {
					customerData.setReqAff(modelLosDetailsRequest.getReqAff());
					customerData.setReqAbo(modelLosDetailsRequest.getReqAbo());
					authorised = restConsumer.authCheck(modelLosDetailsRequest.getReqAff(),
							modelLosDetailsRequest.getReqAbo(), customerData.getAff(), customerData.getAbo(),
							requestedCustomerData.getPeriod());
				}
				if (!authorised) {
					volumeDetailPeriod.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				} else if (1 <= customerData.getCustomerId()) {
					volumeDetailPeriod.setHttpStatus(HttpStatus.OK.value());
					volumeDetailPeriod.setDetails(getListDataForRequested(customerData, modelLosDetailsRequest,
							volumeDetailPeriod.getPeriod(), customerStatusCodes));
				} else {
					volumeDetailPeriod.setHttpStatus(HttpStatus.BAD_REQUEST.value());
				}
				volumeDetailPeriodList.add(volumeDetailPeriod);
			}
		}
		volumeDetailPeriods.setVolumeDetailPeriods(volumeDetailPeriodList);

		return volumeDetailPeriods;

	}

	@Override
	public VolumeDetailPeriods getMapDataForRequested(ModelLosDetailsRequest request,
			List<RequestedCustomerData> requestedCustomerDataList) {

		List<String> customerStatusCodes = new ArrayList<>();
		if (request.isIncludeInactive()) {
			customerStatusCodes.addAll(ACTIVE_AND_INACTIVE_LIST);
		} else {
			customerStatusCodes.addAll(ACTIVE_ONLY_LIST);
		}

		List<CompletableFuture<VolumeDetailPeriod>> futures = new ArrayList<>();
		for (RequestedCustomerData requestedCustomerData : requestedCustomerDataList) {
			for (CustomerData customerData : requestedCustomerData.getCustomerData()) {
				futures.add(CompletableFuture
						.supplyAsync(() -> isAuthorised(request, requestedCustomerData, customerData), executor)
						.thenApplyAsync(isAuthorised -> getVolumeDetailPeriod(request, customerStatusCodes, requestedCustomerData, customerData, isAuthorised), executor)
						.exceptionally(e -> {
							LOGGER.warn(e.getMessage());
							return buildErrorVolumeDetailPeriod(customerData, requestedCustomerData.getPeriod(),
									HttpStatus.INTERNAL_SERVER_ERROR);
						}));
			}
		}

		List<VolumeDetailPeriod> volumeDetailPeriodList =
				futures.stream().map(CompletableFuture::join).collect(toList());

		VolumeDetailPeriods volumeDetailPeriods = new VolumeDetailPeriods();
		volumeDetailPeriods.setVolumeDetailPeriods(volumeDetailPeriodList);
		return volumeDetailPeriods;
	}

	private VolumeDetailPeriod getVolumeDetailPeriod(ModelLosDetailsRequest request,
			List<String> customerStatusCodes,
			RequestedCustomerData requestedCustomerData, CustomerData customerData, boolean authorised) {
		if (!authorised) {
			return buildErrorVolumeDetailPeriod(customerData, requestedCustomerData.getPeriod(),
					HttpStatus.UNAUTHORIZED);
		}
		if (customerData.getCustomerId() <= 1) {
			return buildErrorVolumeDetailPeriod(customerData, requestedCustomerData.getPeriod(),
					HttpStatus.NOT_FOUND);
		}

		Optional<Details> baseDetails = getRequestedCustomerDetails(customerData,
				request, requestedCustomerData.getPeriod(), customerStatusCodes);

		if (baseDetails.isPresent()) {
			return buildVolumeDetailPeriod(customerData, requestedCustomerData.getPeriod(), baseDetails.get());
		}
		return buildErrorVolumeDetailPeriod(customerData, requestedCustomerData.getPeriod(), HttpStatus.NOT_FOUND);
	}

	private boolean isAuthorised(ModelLosDetailsRequest modelLosDetailsRequest,
			RequestedCustomerData requestedCustomerData, CustomerData customerData) {
		if (modelLosDetailsRequest.getReqAff() <= 0 || modelLosDetailsRequest.getReqAbo() <= 0
				|| customerData.getCustomerId() <= 1) {
		  return true;
    }

		// TODO: Side-effects... should be removed
		customerData.setReqAff(modelLosDetailsRequest.getReqAff());
		customerData.setReqAbo(modelLosDetailsRequest.getReqAbo());

		return restConsumer.authCheck(modelLosDetailsRequest.getReqAff(),
				modelLosDetailsRequest.getReqAbo(), customerData.getAff(), customerData.getAbo(),
				requestedCustomerData.getPeriod());
	}

	private Optional<Details> getRequestedCustomerDetails(CustomerData customerData,
			ModelLosDetailsRequest modelLosDetailsRequest, int period, List<String> customerStatusCodes) {

		List<Details> listDetails = getListDataForRequested(customerData, modelLosDetailsRequest,
				period, customerStatusCodes);

		Map<Long, List<Details>> abosBySponsor =
				listDetails.stream().collect(Collectors.groupingBy(Details::getSponsorCustomerId));

		return listDetails.stream()
        .peek(abo -> abo.setDownlines(abosBySponsor.getOrDefault(abo.getBonusCustomerId(), emptyList())))
				.filter(abo -> abo.getBonusCustomerId() == customerData.getCustomerId())
				.findFirst();
	}

	@Override
	public List<Details> getListDataForRequested(CustomerData customerData,
			ModelLosDetailsRequest modelLosDetailsRequest, int period, List<String> customerStatusCodes) {
		JdbcTemplate scdsJdbcTemplate = null;
		List<Details> listDetails = null;
		try {
			IDetail volumeDetail = VolumeDetailFactory.getImplementation(customerData);
			scdsJdbcTemplate = DBUtil.getSingleConnectionJdbcTemplate(this.jdbcTemplate);
			listDetails = volumeDetail.getListDataForRequested(customerData, modelLosDetailsRequest, period,
					customerStatusCodes);
			if (modelLosDetailsRequest.isIncludeAboAttr() || modelLosDetailsRequest.isIncludeUpline()
					|| modelLosDetailsRequest.isIncludeVolumeDetails() || modelLosDetailsRequest.isIncludeAwardLevels()
					|| modelLosDetailsRequest.isIncludeQualCount() || modelLosDetailsRequest.isIncludeSponStats()
					|| modelLosDetailsRequest.isIncludeHasDownlineFlag()) {
				methodAsyncController.taskExecutorForMethods(customerData, modelLosDetailsRequest, period,
						customerStatusCodes, listDetails, scdsJdbcTemplate);
				DBUtil.commitConnection(scdsJdbcTemplate);
			}
		} catch (Exception e) {
			LOGGER.warn(e.getMessage());
		} finally {
			DBUtil.releaseConnection(scdsJdbcTemplate);
		}
		return listDetails != null ? listDetails : emptyList();
	}

	private static VolumeDetailPeriod buildVolumeDetailPeriod(CustomerData customerData, int period,
			Details details) {
		VolumeDetailPeriod volumeDetailPeriod = new VolumeDetailPeriod();
		volumeDetailPeriod.setAff(customerData.getAff());
		volumeDetailPeriod.setAbo(customerData.getAbo());
		volumeDetailPeriod.setPeriod(period);
		volumeDetailPeriod.setHttpStatus(HttpStatus.OK.value());
		volumeDetailPeriod.setDetail(details);
		return volumeDetailPeriod;
	}

	private static VolumeDetailPeriod buildErrorVolumeDetailPeriod(CustomerData customerData,
			int period, HttpStatus httpStatus) {
		VolumeDetailPeriod volumeDetailPeriod = new VolumeDetailPeriod();
		volumeDetailPeriod.setAff(customerData.getAff());
		volumeDetailPeriod.setAbo(customerData.getAbo());
		volumeDetailPeriod.setPeriod(period);
		volumeDetailPeriod.setHttpStatus(httpStatus.value());
		volumeDetailPeriod.setDetail(null);
		return volumeDetailPeriod;
	}

	/**
	 * Null safe.
	 *
	 * @param   <T> the generic type
	 * @param c the c
	 * @return the collection
	 */
	protected static <T> Collection<T> nullSafe(Collection<T> c) {
		return (c == null) ? Collections.<T>emptyList() : c;
	}

}
