package com.amway.dao;

import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public interface SponsoringStatistics {
	Map<Long, Integer> getGroupCounts(int period, NamedParameterJdbcTemplate namedParameterJdbcTemplate,
			Set<String> businessNatures);
}
