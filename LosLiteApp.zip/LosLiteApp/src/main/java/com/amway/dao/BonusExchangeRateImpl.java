package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.amway.dto.BonusExchangeRateDetailParam;
import com.amway.model.BonusExchangeRateDetail;

@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class BonusExchangeRateImpl implements BonusExchangeRate {
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Override
	public BonusExchangeRateDetail getBonusExchangeRateDetail(BonusExchangeRateDetailParam param) {
		// @formatter:off
		String sql = "SELECT AFF_NO, " + "       EXCHG_RT_TYPE_CD, " + "       FROM_ISO_CURCY_CD, "
				+ "       TO_ISO_CURCY_CD, " + "       EFF_DTM, " + "       EXCHG_RT_AMT, "
				+ "       ROUND (EXCHG_RT_AMT * :BV, :precision) AS ROUNDED_EXCHANGED_BV "
				+ "  FROM WWL03130_BNS_EXCHG_RT_DTL A " + " WHERE     AFF_NO = :aff "
				+ "       AND EXCHG_RT_TYPE_CD = :exchangeRateTypeCode "
				+ "       AND FROM_ISO_CURCY_CD = :fromIsoCurrency " + "       AND TO_ISO_CURCY_CD = :toIsoCurrency "
				+ "       AND EFF_DTM = " + "              (SELECT MAX (EFF_DTM) "
				+ "                 FROM WWL03130_BNS_EXCHG_RT_DTL B "
				+ "                WHERE     A.AFF_NO = B.AFF_NO "
				+ "                      AND A.EXCHG_RT_TYPE_CD = B.EXCHG_RT_TYPE_CD "
				+ "                      AND A.FROM_ISO_CURCY_CD = B.FROM_ISO_CURCY_CD "
				+ "                      AND A.TO_ISO_CURCY_CD = B.TO_ISO_CURCY_CD "
				+ "                      AND B.EFF_DTM <= " + "                             (SELECT LAST_DAY ( "
				+ "                                        TO_CHAR ( "
				+ "                                           TO_DATE (:period, 'yyyymm'), "
				+ "                                           'dd MON yyyy')) "
				+ "                                        AS LAST_DATE_OF_MONTH "
				+ "                                FROM DUAL)) ";
		// @formatter:on

		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("aff", param.getAff());
		((MapSqlParameterSource) namedParameters).addValue("period", param.getPeriod());
		((MapSqlParameterSource) namedParameters).addValue("precision", param.getPrecision());
		((MapSqlParameterSource) namedParameters).addValue("exchangeRateTypeCode", param.getExchangeRateTypeCode());
		((MapSqlParameterSource) namedParameters).addValue("fromIsoCurrency", param.getFromIsoCurrencyCode());
		((MapSqlParameterSource) namedParameters).addValue("toIsoCurrency", param.getToIsoCurrencyCode());
		((MapSqlParameterSource) namedParameters).addValue("BV", param.getBv());
		return (BonusExchangeRateDetail) namedParameterJdbcTemplate.queryForObject(sql, namedParameters,
				new BonusExchangeRateDetailRowMapper());
	}

	public class BonusExchangeRateDetailRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			BonusExchangeRateDetail bonusExchangeRateDetail = new BonusExchangeRateDetail();
			bonusExchangeRateDetail.setAff(rs.getInt("AFF_NO"));
			bonusExchangeRateDetail.setEffectiveDate(rs.getDate("EFF_DTM"));
			bonusExchangeRateDetail.setExchangeRateAmount(rs.getBigDecimal("EXCHG_RT_AMT"));
			bonusExchangeRateDetail.setRoundedExchangedBv(rs.getBigDecimal("ROUNDED_EXCHANGED_BV"));
			bonusExchangeRateDetail.setExchangeRateTypeCode(rs.getString("EXCHG_RT_TYPE_CD"));
			bonusExchangeRateDetail.setFromIsoCurrencyCode(rs.getString("FROM_ISO_CURCY_CD"));
			bonusExchangeRateDetail.setToIsoCurrencyCode(rs.getString("TO_ISO_CURCY_CD"));
			return bonusExchangeRateDetail;
		}
	}
}
