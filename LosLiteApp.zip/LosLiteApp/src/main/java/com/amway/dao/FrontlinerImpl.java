package com.amway.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.amway.domain.ModelLosDetailsRequest;
import com.amway.model.BasicServiceOutputData;
import com.amway.util.DBUtil;
import com.amway.util.mappers.BasicServiceOutputMapper;

public class FrontlinerImpl implements Frontliner {

	@SuppressWarnings("unchecked")
	@Override
	public List<BasicServiceOutputData> getAFrontlinersMagic(final int period, final String sponType,
			final List<Long> customerList, final List<String> customerStatusCodes,
			final ModelLosDetailsRequest modelLosDetailsRequest, final int level, final JdbcTemplate scdsJdbcTemplate,
			final NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		String sql = "    SELECT tbl1.BNS_CUST_ID, spon2.AFF_NO,  spon2.IBO_NO, per.CUST_STAT_CD, per.CUST_NM, spon.bns_cust_id AS SPON_CUST_ID, spon.IBO_NO AS SPON_IBO_NO, "
				+ "spon.AFF_NO AS SPON_AFF_ID, per.BUS_ENTTY_NO, per.CUST_CLASS_CD, per.BUS_NATR_CD, per.AMWAY_CNTRY_CD, "
				+ level + " AS LOS_LVL_NO, 'A' AS LOS_TYPE_CD, '' AS SEG_CD "
				+ "      FROM WWL03290_CUST_SPON_DTL TBL1, WWL03250_CUST_PER_DTL per, WWL01010_bns_cust_mst spon, WWL01010_bns_cust_mst spon2, TTL02000_LOS_DTL_SVC temp "
				+ "     WHERE     per.BNS_CUST_ID = tbl1.bns_cust_id "
				+ "           AND per.BNS_PER_NO = TBL1.bns_per_no "
				+ "           AND spon.bns_cust_id = TBL1.CUST_SPON_ID "
				+ "           AND spon2.BNS_CUST_ID = tbl1.BNS_CUST_ID "
				+ "           AND TRIM (PER.CUST_STAT_CD) IN (:customerStatusCodes) "
				+ "           AND TRIM (PER.BUS_NATR_CD) IN (:businessNatures) "
				+ "           AND TBL1.CUST_SPON_ID = temp.BNS_CUST_ID  AND TBL1.BNS_PER_NO = :period "
				+ "           AND TBL1.SPON_TYPE_CD = :sponType ";
		DBUtil.insertIntoTempTable(scdsJdbcTemplate, customerList);
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		((MapSqlParameterSource) namedParameters).addValue("sponType", sponType);
		((MapSqlParameterSource) namedParameters).addValue("businessNatures",
				modelLosDetailsRequest.getBusinessNatures());
		((MapSqlParameterSource) namedParameters).addValue("customerStatusCodes", customerStatusCodes);
		List<BasicServiceOutputData> resultList = namedParameterJdbcTemplate.query(sql, namedParameters,
				new BasicServiceOutputMapper());
		DBUtil.commitConnection(scdsJdbcTemplate);
		return resultList;
	}

}
