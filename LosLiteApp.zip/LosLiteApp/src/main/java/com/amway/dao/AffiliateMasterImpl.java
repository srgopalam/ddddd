package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.amway.model.AffiliateMasterData;

@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class AffiliateMasterImpl implements AffiliateMaster {
	private static final Logger LOGGER = LoggerFactory.getLogger(AffiliateMasterImpl.class);
	private static final String BASE_SQL = "SELECT AFF_NO,AFF_NM,CURR_BNS_PER_NO,DFLT_ISO_CNTRY_CD,AMWAY_ALIAS_CUST_ID,DFLT_ISO_CURCY_CD,MULT_BUS_ENTTY_FLG,"
			+ "RGN_CD,FUND_CALC_MTHOD_CD,MULT_CURCY_FLG FROM WWL12010_AFF_MST ";

	@Autowired
	protected JdbcTemplate jTemplate;

	@Override
	public AffiliateMasterData getAffiliateData(int aff) throws Exception {
		LOGGER.info("Retrieving WWL12010_AFF_MST's from DB!2");
		AffiliateMasterData affiliateMaster;
		try {
			affiliateMaster = (AffiliateMasterData) jTemplate.queryForObject(BASE_SQL + " WHERE AFF_NO = ? ",
					new Object[] { aff }, new AffiliateMasterRowMapper());
		} catch (EmptyResultDataAccessException exception) {
			throw new Exception("No affiliate found with affNo:" + aff);
		}
		return affiliateMaster;
	}

	@Override
	public List<AffiliateMasterData> getAllAffiliatesData() {
		LOGGER.info("Retrieving WWL12010_AFF_MST's from DB!1");
		return jTemplate.query(BASE_SQL, new AffiliateMasterRowMapper());
	}

	public class AffiliateMasterRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			AffiliateMasterData affiliateMaster = new AffiliateMasterData();
			affiliateMaster.setAff(rs.getInt("AFF_NO"));
			affiliateMaster.setAffName(rs.getString("AFF_NM"));
			affiliateMaster.setCurrentBonusPeriod(rs.getInt("CURR_BNS_PER_NO"));
			affiliateMaster.setDefaultIsoCountryCode(rs.getString("DFLT_ISO_CNTRY_CD"));
			affiliateMaster.setAmwayAliasCustId(rs.getInt("AMWAY_ALIAS_CUST_ID"));
			affiliateMaster.setDefaultIsoCurrencyCode(rs.getString("DFLT_ISO_CURCY_CD"));
			affiliateMaster.setMultiBusinessEntityFlag(rs.getBoolean("MULT_BUS_ENTTY_FLG"));
			affiliateMaster.setRegionCode(rs.getString("RGN_CD"));
			affiliateMaster.setFundClacMethodCode(rs.getString("FUND_CALC_MTHOD_CD"));
			affiliateMaster.setMultiCurrencyFlag(rs.getBoolean("MULT_CURCY_FLG"));
			return affiliateMaster;
		}
	}

	@Override
	public Map<Integer, AffiliateMasterData> getAllAffiliatesDataMap() {
		Map<Integer, AffiliateMasterData> affMasterMap = new HashMap<>();
		List<AffiliateMasterData> affMasterList = this.getAllAffiliatesData();
		for (AffiliateMasterData affData : affMasterList) {
			affMasterMap.put(affData.getAff(), affData);
		}
		return affMasterMap;
	}

}
