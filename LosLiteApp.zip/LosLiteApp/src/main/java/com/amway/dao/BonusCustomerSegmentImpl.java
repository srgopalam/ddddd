package com.amway.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import com.amway.model.BonusCustomerSegmentData;
import com.amway.util.DBUtil;

@Component
@SuppressWarnings({ "rawtypes", "unchecked" })
public class BonusCustomerSegmentImpl implements BonusCustomerSegment {

	public class BonusCustomerSegmentRowMapper implements RowMapper {
		@Override
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			BonusCustomerSegmentData bonusCustomerSegmentData = new BonusCustomerSegmentData();
			bonusCustomerSegmentData.setBonusCustomerId(rs.getLong("BNS_CUST_ID"));
			bonusCustomerSegmentData.setPeriod(rs.getInt("BNS_PER_NO"));
			bonusCustomerSegmentData.setSegmentCode(rs.getString("SEG_CD"));
			return bonusCustomerSegmentData;
		}
	}

	@Override
	public List<BonusCustomerSegmentData> getSegmentData(List<Long> bonusCustomerList, int period,
			final JdbcTemplate scdsJdbcTemplate, final NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		String sql = "SELECT dtl.BNS_CUST_ID, dtl.BNS_PER_NO, TRIM(SEG_CD) AS SEG_CD "
				+ "  FROM WWL03088_CUST_SEG_PER_DTL dtl, TTL02000_LOS_DTL_SVC temp WHERE dtl.BNS_PER_NO = :period "
				+ "       AND dtl.BNS_CUST_ID = temp.BNS_CUST_ID";
		DBUtil.insertIntoTempTable(scdsJdbcTemplate, bonusCustomerList);
		SqlParameterSource namedParameters = new MapSqlParameterSource();
		((MapSqlParameterSource) namedParameters).addValue("period", period);
		List<BonusCustomerSegmentData> segmentDataList = namedParameterJdbcTemplate.query(sql, namedParameters,
				new BonusCustomerSegmentRowMapper());
		DBUtil.commitConnection(scdsJdbcTemplate);
		return segmentDataList;
	}

	@Override
	public String getSegment(long bonusCustomerId, int period,
			final NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		String segment;
		try {
			String sql = "SELECT TRIM(SEG_CD) AS SEG_CD FROM WWL03088_CUST_SEG_PER_DTL dtl "
					+ " WHERE (dtl.BNS_PER_NO = :period OR dtl.BNS_PER_NO = (SELECT MAX (BNS_PER_NO) FROM WWL03088_CUST_SEG_PER_DTL WHERE BNS_PER_NO <= :period)) AND dtl.BNS_CUST_ID = :bonusCustomerId ";
			SqlParameterSource namedParameters = new MapSqlParameterSource();
			((MapSqlParameterSource) namedParameters).addValue("period", period);
			((MapSqlParameterSource) namedParameters).addValue("bonusCustomerId", bonusCustomerId);
			segment = namedParameterJdbcTemplate.queryForObject(sql, namedParameters, String.class);
		} catch (EmptyResultDataAccessException ignore) {
			// set default to 9
			segment = "9";
		}
		return segment;
	}
}
