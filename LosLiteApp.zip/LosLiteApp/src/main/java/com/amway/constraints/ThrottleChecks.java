package com.amway.constraints;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import javax.validation.ConstraintViolation;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.util.CollectionUtils;

import com.amway.domain.ModelLosDetailsRequest;
import com.amway.exception.DataRangeException;
import com.amway.service.CaffeineCacheService;

public class ThrottleChecks {

	private static final int MAX_NO_OF_PERIODS_ALLOWED_FOR_SINGLE_ABO = 24;
	private static final int MAX_NO_OF_PERIODS_ALLOWED_FOR_MULTIPLE_ABOS = 13;
	private static final int MAX_NO_OF_PERIODS_ALLOWED_WHEN_INCLUDE_MAP_TRUE = 1;
	private static final int MAX_NO_OF_AFFABOS_ALLOWED_WHEN_INCLUDE_MAP_TRUE = 1;
	private static final int MAX_NO_OF_AFFABOS_ALLOWED = 500;
	private static final Set<? extends ConstraintViolation<?>> constraintViolations = new HashSet<>();
	private static final Locale locale = LocaleContextHolder.getLocale();

	private ThrottleChecks() {
		super();
	}

	public static void check(ModelLosDetailsRequest req, MessageSource messageSource,
			CaffeineCacheService caffeineCacheService) {

		if (CollectionUtils.isEmpty(req.getPeriods())) {
			throw new DataRangeException(messageSource.getMessage("api.period.missing.message", null, locale),
					constraintViolations);
		}

		if (CollectionUtils.isEmpty(req.getAffAbos())) {
			throw new DataRangeException(messageSource.getMessage("api.affabo.missing.message", null, locale),
					constraintViolations);
		}

		if (MAX_NO_OF_PERIODS_ALLOWED_FOR_SINGLE_ABO < req.getPeriods().size()) {
			throw new DataRangeException(messageSource.getMessage("api.period.limit.message", null, locale),
					constraintViolations);
		}

		if (MAX_NO_OF_PERIODS_ALLOWED_FOR_MULTIPLE_ABOS < req.getPeriods().size() && 1 < req.getAffAbos().size()) {
			throw new DataRangeException(messageSource.getMessage("api.period.limit.multipleabo.message", null, locale),
					constraintViolations);
		}

		if (req.isIncludeMap() && MAX_NO_OF_PERIODS_ALLOWED_WHEN_INCLUDE_MAP_TRUE < req.getPeriods().size()) {
			throw new DataRangeException(
					messageSource.getMessage("api.period.limit.when.includemap.true.message", null, locale),
					constraintViolations);
		}
		if (req.isIncludeMap() && MAX_NO_OF_AFFABOS_ALLOWED_WHEN_INCLUDE_MAP_TRUE < req.getAffAbos().size()) {
			throw new DataRangeException(
					messageSource.getMessage("api.affabo.limit.when.includemap.true.message", null, locale),
					constraintViolations);
		}
		if (req.getAffAbos().size() > MAX_NO_OF_AFFABOS_ALLOWED) {
			throw new DataRangeException(messageSource.getMessage("api.affabo.limit.message", null, locale),
					constraintViolations);
		}
		removeInvalidParamValues(req, messageSource, caffeineCacheService);
	}

	private static void removeInvalidParamValues(ModelLosDetailsRequest req, MessageSource messageSource,
			CaffeineCacheService caffeineCacheService) {
		Set<String> validVolumeTypeCodes = new HashSet<>(caffeineCacheService.getAllVolumeTypeCodes());
		Set<String> validBusinessNatureCodes = new HashSet<>(caffeineCacheService.getAllBusinessNatureCodes());
		int businessNatureCodesMasterCount = validBusinessNatureCodes.size();
		if (!CollectionUtils.isEmpty(req.getVolumeTypes())) {
			validVolumeTypeCodes.retainAll(req.getVolumeTypes());
		} else {
			validVolumeTypeCodes.clear();
			validVolumeTypeCodes.add("001");
		}
		if (!CollectionUtils.isEmpty(req.getBusinessNatures())) {
			validBusinessNatureCodes.retainAll(req.getBusinessNatures());
			if (validBusinessNatureCodes.isEmpty()) {
				throw new DataRangeException(messageSource.getMessage("api.businessNature[].invalid.message",
						new Object[] { req.getBusinessNatures() }, locale), constraintViolations);
			}
		}
		req.setVolumeTypes(validVolumeTypeCodes);
		req.setBusinessNatures(validBusinessNatureCodes);
		req.setShowBusinessNatureProperty(businessNatureCodesMasterCount != validBusinessNatureCodes.size());
	}

}
