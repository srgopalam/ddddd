package com.amway.exception.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.amway.exception.DataRangeException;
import com.amway.exception.ExceptionMessage;

@ControllerAdvice
public class DataValidationExceptionHandler {
	@ExceptionHandler(value = { DataRangeException.class })
	public ResponseEntity<ExceptionMessage> handleBadInput(DataRangeException pre) {
		ExceptionMessage exceptionMessage = new ExceptionMessage(HttpStatus.BAD_REQUEST.value(),
				"DataRangeException / Throttle Checks failed!", pre.getLocalizedMessage());
		return new ResponseEntity<>(exceptionMessage, HttpStatus.BAD_REQUEST);
	}
}