package com.amway.exception.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.amway.exception.EmptyResultException;
import com.amway.exception.ExceptionMessage;

@ControllerAdvice
public class DefaultExceptionHandler extends ResponseEntityExceptionHandler {
	private static final Logger LOG = LoggerFactory.getLogger(DefaultExceptionHandler.class);

	@ExceptionHandler
	public final ResponseEntity<ExceptionMessage> somethingWentWrong(EmptyResultException exception) {
		LOG.error("No records were found that match the specified search criteria!", exception);
		ExceptionMessage exceptionResponse = new ExceptionMessage(HttpStatus.NO_CONTENT.value(),
				"EmptyResultDataAccessException", exception.getLocalizedMessage());
		return new ResponseEntity<>(exceptionResponse, new HttpHeaders(), HttpStatus.NO_CONTENT);
	}

	@ExceptionHandler
	public final ResponseEntity<ExceptionMessage> somethingWentWrong(Exception exception) {
		LOG.error("An exception occurred: {}", exception);
		ExceptionMessage exceptionResponse = new ExceptionMessage(HttpStatus.BAD_REQUEST.value(), "Exception",
				exception.getLocalizedMessage());
		return new ResponseEntity<>(exceptionResponse, new HttpHeaders(), HttpStatus.BAD_REQUEST);
	}
}
