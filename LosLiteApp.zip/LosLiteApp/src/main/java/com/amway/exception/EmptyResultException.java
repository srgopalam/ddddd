package com.amway.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;

public class EmptyResultException extends javax.validation.ConstraintViolationException {

	private static final long serialVersionUID = 1708253278749162804L;

	public EmptyResultException(String message, Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(message, constraintViolations);
	}

	@Override
	public synchronized Throwable fillInStackTrace() {
		return this;
	}
}
