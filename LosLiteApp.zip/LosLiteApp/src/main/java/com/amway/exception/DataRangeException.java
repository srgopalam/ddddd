package com.amway.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;

public class DataRangeException extends javax.validation.ConstraintViolationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1708253978749162804L;

	public DataRangeException(String message, Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(message, constraintViolations);
	}

}
