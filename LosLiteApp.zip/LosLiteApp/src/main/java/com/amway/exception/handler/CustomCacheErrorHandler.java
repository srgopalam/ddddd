package com.amway.exception.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.Cache;
import org.springframework.cache.interceptor.CacheErrorHandler;

import com.amway.api.rest.LosController;

public class CustomCacheErrorHandler implements CacheErrorHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(LosController.class);

	@Override
	public void handleCacheGetError(RuntimeException exception, Cache cache, Object key) {
		LOGGER.warn("handleCacheGetError");
	}

	@Override
	public void handleCachePutError(RuntimeException exception, Cache cache, Object key, Object value) {
		LOGGER.warn("handleCachePutError");
	}

	@Override
	public void handleCacheEvictError(RuntimeException exception, Cache cache, Object key) {
		LOGGER.warn("handleCacheEvictError");
	}

	@Override
	public void handleCacheClearError(RuntimeException exception, Cache cache) {
		LOGGER.warn("handleCacheClearError");
	}
}