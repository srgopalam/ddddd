package com.amway.helper;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.amway.dao.AwardLevelImpl;
import com.amway.domain.AwardLevelData;
import com.amway.domain.include.AwardLevelDetail;
import com.amway.domain.list.Details;
import com.amway.service.CaffeineCacheService;

public class AwardLevelHelper {
	public void mapAwardLevelDetails(int period, List<Details> listDetails, CaffeineCacheService caffeineCacheService,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		List<AwardLevelData> awardLevelDataList = new AwardLevelImpl().getAwardLevelData(period,
				namedParameterJdbcTemplate);
		Map<Long, AwardLevelData> awardLevelMap = new HashMap<>();
		for (AwardLevelData awardLevelData : awardLevelDataList) {
			awardLevelMap.put(awardLevelData.getBonusCustomerId(), awardLevelData);
		}
		for (Details detail : nullSafe(listDetails)) {
			setAwardLevelDetails(awardLevelMap, detail);
		}
	}

	private void setAwardLevelDetails(Map<Long, AwardLevelData> awardLevelMap, Details detail) {
		AwardLevelData awardLevelData = awardLevelMap.get(detail.getBonusCustomerId());
		if (null != awardLevelData) {
			AwardLevelDetail awardLevelDetail = new AwardLevelDetail();
			awardLevelDetail.setCurrentAwardRank(awardLevelData.getCurrentAward());
			awardLevelDetail.setCurrentQualPeriod(awardLevelData.getCurrentQualificationPeriod());
			awardLevelDetail.setHighestAwardRank(awardLevelData.getHighestAward());
			awardLevelDetail.setHighestQualPeriod(awardLevelData.getHighestQualificationPeriod());
			detail.setAwardLevelDetail(awardLevelDetail);
		}
	}

	/**
	 * Null safe.
	 *
	 * @param <T> the generic type
	 * @param c   the c
	 * @return the collection
	 */
	private static <T> Collection<T> nullSafe(Collection<T> c) {
		return (c == null) ? Collections.<T>emptyList() : c;
	}
}
