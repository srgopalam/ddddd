package com.amway.helper;

import com.amway.dao.UplineInfoDao;
import com.amway.domain.include.UplineInfo;
import com.amway.domain.list.Details;
import com.amway.service.CaffeineCacheService;
import com.amway.util.CurrentPeriodHelper;
import com.amway.util.DBUtil;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class UplineHelper {
	private static final Logger LOGGER = LoggerFactory.getLogger(UplineHelper.class);

	public void mapUplineInfo(int period, List<Details> listDetails,
			UplineInfoDao uplineInfoDao, CaffeineCacheService caffeineCacheService) {
		Map<Long, Details> allDetailsMapByCustomer = new HashMap<>();
		for (Details detail : nullSafe(listDetails)) {
			allDetailsMapByCustomer.put(detail.getBonusCustomerId(), detail);
		}

		List<Long> allCustomersList = allDetailsMapByCustomer.keySet().stream().collect(Collectors.toList());

		Map<Long, Long> platSponsorLst = new HashMap<>();
		int bnsPeriodYYYYMM = period;
		Map<Long, UplineInfo> intlSponFrmGloss = new HashMap<>();
		Map<Long, UplineInfo> intlSponFrmMagic = new HashMap<>();

		JdbcTemplate scdsJdbcTemplate = uplineInfoDao.getSingleConnectionJdbcTemplate();
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(scdsJdbcTemplate);
		DBUtil.insertIntoTempTable(scdsJdbcTemplate, allCustomersList);
		platSponsorLst.putAll(uplineInfoDao.getPlatinumSponsor(bnsPeriodYYYYMM, namedParameterJdbcTemplate));
		intlSponFrmMagic.putAll(uplineInfoDao.getUplineInfoFrmMagic(bnsPeriodYYYYMM, namedParameterJdbcTemplate));
		intlSponFrmGloss.putAll(uplineInfoDao.getUplineInfoFrmGloss(namedParameterJdbcTemplate));
		DBUtil.commitConnection(scdsJdbcTemplate);
		DBUtil.releaseConnection(scdsJdbcTemplate);
		if (intlSponFrmMagic == null || intlSponFrmGloss == null || platSponsorLst == null) {
			return;
		}

		UplineInfo uplineInfo;
		long platinumSponsor;
		Map<Integer, Boolean> magicVsGloss = new HashMap<>();
		for (Details detail : nullSafe(listDetails)) {
			if (!magicVsGloss.containsKey(detail.getAff())) {
				magicVsGloss.put(detail.getAff(), CurrentPeriodHelper.shouldWeGetDataFromGloss(detail.getAff(),
						bnsPeriodYYYYMM, caffeineCacheService));
			}
			if (magicVsGloss.get(detail.getAff())) {
				uplineInfo = intlSponFrmGloss.get(detail.getBonusCustomerId());
			} else {
				uplineInfo = intlSponFrmMagic.get(detail.getBonusCustomerId());
			}

			if (uplineInfo == null)
				uplineInfo = new UplineInfo();

			if (platSponsorLst.get(detail.getBonusCustomerId()) != null) {
				platinumSponsor = platSponsorLst.get(detail.getBonusCustomerId());
				uplineInfo.setPlatinumSponsor(platinumSponsor);
			}

			detail.setUplineInfo(uplineInfo);
		}
	}

	public void mapHasDownlineFlags(int aff, int bnsPeriodYYYYMM, List<String> customerStatusCodes,
			Set<String> businessNatures, NamedParameterJdbcTemplate namedParameterJdbcTemplate,
			List<Details> listDetails, UplineInfoDao uplineInfoDao, CaffeineCacheService caffeineCacheService) {
		final boolean fromGloss = CurrentPeriodHelper.shouldWeGetDataFromGloss(aff, bnsPeriodYYYYMM,
				caffeineCacheService);
		long s = System.currentTimeMillis();
		Set<Long> sponsorSet = uplineInfoDao.getSponsoredSet(fromGloss, bnsPeriodYYYYMM, customerStatusCodes,
				businessNatures, namedParameterJdbcTemplate);
		LOGGER.info("getSponsoredSet: {}", (s - System.currentTimeMillis()));
		for (Details detail : nullSafe(listDetails)) {
			if (sponsorSet.contains(detail.getBonusCustomerId())) {
				detail.setHasDownlines(true);
			}
		}
	}

	public void mapHasDownlineFlagsIntl(int bnsPeriodYYYYMM, List<String> customerStatusCodes,
			Set<String> businessNatures, NamedParameterJdbcTemplate namedParameterJdbcTemplate,
			List<Details> listDetails, UplineInfoDao uplineInfoDao) {
		long s = System.currentTimeMillis();
		Set<Long> sponsorSet = uplineInfoDao.getSponsoredSetIntl(bnsPeriodYYYYMM, customerStatusCodes, businessNatures,
				namedParameterJdbcTemplate);
		LOGGER.info("mapHasDownlineFlagsIntl: {}", (s - System.currentTimeMillis()));
		for (Details detail : nullSafe(listDetails)) {
			if (sponsorSet.contains(detail.getBonusCustomerId())) {
				detail.setHasDownlines(true);
			}
		}
	}

	protected static <T> Collection<T> nullSafe(Collection<T> c) {
		return (c == null) ? Collections.<T>emptyList() : c;
	}
}
