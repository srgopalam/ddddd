package com.amway.helper;

import com.amway.dao.BonusCustomerQualification;
import com.amway.dao.BonusCustomerQualificationImpl;
import com.amway.domain.include.QualCounts;
import com.amway.domain.list.Details;
import com.amway.service.CaffeineCacheService;
import com.amway.util.CurrentPeriodHelper;
import com.amway.util.DBUtil;
import com.amway.util.DateUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class QualCountsHelper {
	private Set<String> qualMethodCodes;

	public QualCountsHelper() {
		qualMethodCodes = Stream.of("MQ", "QX", "Q", "MM", "MI").collect(Collectors.toSet());
	}

	public void mapQualCountDetails(int period, List<Details> listDetails,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		Map<Long, Map<String, Integer>> qualCountsMap = new BonusCustomerQualificationImpl()
				.getInMktAndFosterQualCounts(period, namedParameterJdbcTemplate);
		Map<String, Integer> qualCountsData = null;
		QualCounts qualCounts = null;
		for (Details detail : nullSafe(listDetails)) {
			qualCountsData = qualCountsMap.get(detail.getBonusCustomerId());
			qualCounts = new QualCounts();
			if (null != qualCountsData) {
				qualCounts.setFosterQualifiedLegsCount(qualCountsData.getOrDefault("FSL", 0));
				qualCounts.setInMktQualifiedLegsCount(qualCountsData.getOrDefault("NAL", 0));
			}
			detail.setQualCounts(qualCounts);
		}
	}

	public void mapQualifiedAwardLegCounts(int period, List<Details> listDetails,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		int fiscalYear = DateUtil.fiscalYear(period);
		int startOfFiscalYear = DateUtil.startOfFiscalYear(fiscalYear);
		int endOfFiscalYear = DateUtil.endOfFiscalYear(fiscalYear);
		Map<Long, Integer> qualCountsMap = new BonusCustomerQualificationImpl()
				.getQualifiedAwardLegCounts(startOfFiscalYear, endOfFiscalYear, namedParameterJdbcTemplate);
		int qualifiedAwardLegsCount = 0;
		QualCounts qualCounts = null;
		for (Details detail : nullSafe(listDetails)) {
			qualifiedAwardLegsCount = qualCountsMap.getOrDefault(detail.getBonusCustomerId(), 0);
			qualCounts = detail.getQualCounts();
			if (null == qualCounts) {
				qualCounts = new QualCounts();
			}
			qualCounts.setQualifiedAwardLegsCount(qualifiedAwardLegsCount);
			detail.setQualCounts(qualCounts);
		}
	}

	public void mapIntlQualifiedLegCounts(int period, List<Details> listDetails,
			JdbcTemplate jdbcTemplate, CaffeineCacheService caffeineCacheService) {
		List<Integer> glossAffList = CurrentPeriodHelper.getGlossAffiliatesByPeriod(period,
        caffeineCacheService);

		Map<Long, Details> magicDetailsMapByCustomer = new HashMap<>();
		Map<Long, Details> glossDetailsMapByCustomer = new HashMap<>();
		for (Details detail : nullSafe(listDetails)) {
			if (!glossAffList.isEmpty() && glossAffList.contains(detail.getAff())) {
				glossDetailsMapByCustomer.put(detail.getBonusCustomerId(), detail);
			} else {
				magicDetailsMapByCustomer.put(detail.getBonusCustomerId(), detail);
			}
		}
		List<Long> magicCustomersList = new ArrayList<>(magicDetailsMapByCustomer.keySet());
		List<Long> glossCustomersList = new ArrayList<>(glossDetailsMapByCustomer.keySet());
		JdbcTemplate scdsJdbcTemplate = DBUtil.getSingleConnectionJdbcTemplate(jdbcTemplate);
		BonusCustomerQualification bonusCustomerQualification = new BonusCustomerQualificationImpl();
		Map<Long, Integer> magicCountsMap = bonusCustomerQualification.getIntlQualifiedLegCounts(true, period,
				magicCustomersList, qualMethodCodes, scdsJdbcTemplate);
		Map<Long, Integer> glossCountsMap = bonusCustomerQualification.getIntlQualifiedLegCounts(false, period,
				glossCustomersList, qualMethodCodes, scdsJdbcTemplate);
		DBUtil.releaseConnection(scdsJdbcTemplate);
		Map<Long, Integer> qualCountsMap = Stream
				.concat(magicCountsMap.entrySet().stream(), glossCountsMap.entrySet().stream())
				.collect(Collectors.toMap(Entry::getKey, Entry::getValue));
		int intlQualifiedLegsCount = 0;
		QualCounts qualCounts = null;
		for (Details detail : nullSafe(listDetails)) {
			intlQualifiedLegsCount = qualCountsMap.getOrDefault(detail.getBonusCustomerId(), 0);
			qualCounts = detail.getQualCounts();
			if (null == qualCounts) {
				qualCounts = new QualCounts();
			}
			qualCounts.setIntlQualifiedLegsCount(intlQualifiedLegsCount);
			detail.setQualCounts(qualCounts);
		}
	}

	/**
	 * Null safe.
	 *
	 * @param <T> the generic type
	 * @param c   the c
	 * @return the collection
	 */
	private static <T> Collection<T> nullSafe(Collection<T> c) {
		return (c == null) ? Collections.<T>emptyList() : c;
	}
}
