package com.amway.helper;

import com.amway.dao.AboAttributesDao;
import com.amway.dao.BlockPrivilegesDao;
import com.amway.dao.BusinessEntity;
import com.amway.dao.SysRuleAffParamsDao;
import com.amway.domain.CustomerData;
import com.amway.domain.include.AboAttributes;
import com.amway.domain.list.Details;
import com.amway.model.AffiliateMasterData;
import com.amway.model.BusinessEntityData;
import com.amway.model.SysRuleAffPerCtl;
import com.amway.service.CaffeineCacheService;
import com.amway.util.DateUtil;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class AboAttributesHelper {

	public static final int KOREA_AFF_SYS_RULE_ID = 702;
	public static final int KOREA_AFF = 180;
	public static final String SPACE = "";
	public static final String PRIMARY_NAME_TYPE = "0";
	public static final String PRIMARY_LCL_NAME_TYPE = "A";
	public static final String APPLICANT1_LCL_NAME_TYPE = "B";
	public static final String LEGAL_ENTITY = "Y";

	public void mapAboAttributes(CustomerData customerData, int period,
			List<Details> listDetails, AboAttributesDao aboAttrDao, BlockPrivilegesDao blockPrivilegesDao,
			SysRuleAffParamsDao sysRuleAffParamDao, NamedParameterJdbcTemplate namedParameterJdbcTemplate,
			final BusinessEntity businessEntity, final CaffeineCacheService caffeineCacheService) {
		java.util.Date endDate = DateUtil.endDate(period);
		SysRuleAffPerCtl sysRuleKorea = sysRuleAffParamDao.get(KOREA_AFF, KOREA_AFF_SYS_RULE_ID, period);
		Map<String, AboAttributes> aboAttrList = aboAttrDao.getAboAttributes(namedParameterJdbcTemplate);
		Map<Long, Boolean> blockPrivilegesList = blockPrivilegesDao.getIsDistBlocked(namedParameterJdbcTemplate,
				new java.sql.Date(endDate.getTime()));
		AboAttributes aboAttrData;
		AboAttributes aboAttrDataA;
		AboAttributes aboAttrDataB;
		// Populate affiliate master data
		Map<Integer, AffiliateMasterData> affMasterMap = caffeineCacheService.getAllAffiliatesDataMap();
		boolean legalEntity;
		Map<Integer, BusinessEntityData> businessEntityDetailMap = businessEntity
				.getBusinessEntityDetailsMapByPeriod(period);
		for (Details detail : nullSafe(listDetails)) {
			AffiliateMasterData affiliateMasterData = affMasterMap.get(detail.getAff());
			// If is Legal Entity, Use Applicant 1 Name.
			legalEntity = false;
			if (aboAttrList.containsKey(detail.getBonusCustomerId() + PRIMARY_NAME_TYPE + LEGAL_ENTITY)) {
				legalEntity = true;
				aboAttrData = aboAttrList.get(detail.getBonusCustomerId() + PRIMARY_NAME_TYPE + LEGAL_ENTITY);
			} else {
				aboAttrData = aboAttrList.get(detail.getBonusCustomerId() + PRIMARY_NAME_TYPE);
			}
			if (aboAttrList.containsKey(detail.getBonusCustomerId() + PRIMARY_LCL_NAME_TYPE + LEGAL_ENTITY)) {
				aboAttrDataA = aboAttrList.get(detail.getBonusCustomerId() + PRIMARY_LCL_NAME_TYPE + LEGAL_ENTITY);
			} else {
				aboAttrDataA = aboAttrList.get(detail.getBonusCustomerId() + PRIMARY_LCL_NAME_TYPE);
			}
			if (aboAttrList.containsKey(detail.getBonusCustomerId() + APPLICANT1_LCL_NAME_TYPE + LEGAL_ENTITY)) {
				aboAttrDataB = aboAttrList.get(detail.getBonusCustomerId() + APPLICANT1_LCL_NAME_TYPE + LEGAL_ENTITY);
			} else {
				aboAttrDataB = aboAttrList.get(detail.getBonusCustomerId() + APPLICANT1_LCL_NAME_TYPE);
			}
			if (aboAttrData == null) {
				aboAttrData = new AboAttributes();
			}

			BusinessEntityData businessEntityDetails;
			businessEntityDetails = businessEntityDetailMap.get(detail.getBusinessEntity());
			if (null != businessEntityDetails) {
				aboAttrData.setIsoCountry(businessEntityDetails.getIsoCountry());
			} else {
				aboAttrData.setIsoCountry(affiliateMasterData.getDefaultIsoCountryCode());
			}
			mapAboNames(aboAttrData, aboAttrDataA, aboAttrDataB, legalEntity);
			aboAttrData.setSegment(detail.getSegmentCode());
			mapPrivacyFlags(blockPrivilegesList, aboAttrData, detail);
			hideAboNames(customerData, sysRuleKorea, aboAttrData, detail);
			detail.setAboAttributes(aboAttrData);
		}
	}

	private void mapAboNames(AboAttributes aboAttrData, AboAttributes aboAttrDataA, AboAttributes aboAttrDataB,
			boolean legalEntity) {
		aboAttrData.setAboName(aboAttrData.getAboName());
		aboAttrData.setIsoLanguage(aboAttrData.getIsoLanguage());
		if (null != aboAttrDataA) {
			aboAttrData.setAboLocalName(aboAttrDataA.getAboName());
			aboAttrData.setIsoLanguage(aboAttrDataA.getIsoLanguage());
		}
		if (legalEntity && null != aboAttrDataB) {
			aboAttrData.setAboLocalName(aboAttrDataB.getAboName());
			aboAttrData.setIsoLanguage(aboAttrDataB.getIsoLanguage());
		}
	}

	private void mapPrivacyFlags(Map<Long, Boolean> blockPrivilegesList, AboAttributes aboAttrData, Details detail) {
		if (blockPrivilegesList.get(detail.getBonusCustomerId()) != null) {
			aboAttrData.setPrivacyFlag(blockPrivilegesList.get(detail.getBonusCustomerId()));
		}
	}

	private void hideAboNames(CustomerData customerData, SysRuleAffPerCtl sysRuleKorea, AboAttributes aboAttrData,
			Details detail) {
		if (sysRuleKorea != null && sysRuleKorea.getUserDefinedFlag() && aboAttrData.isPrivacyFlag()
				&& KOREA_AFF == detail.getAff() && customerData.getReqAff() != detail.getAff()) {
			aboAttrData.setAboName(SPACE);
			aboAttrData.setAboLocalName(SPACE);
		}
	}

	protected static <T> Collection<T> nullSafe(Collection<T> c) {
		return (c == null) ? Collections.<T>emptyList() : c;
	}
}
