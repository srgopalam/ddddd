package com.amway.helper;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.amway.dao.SponsoringStatisticsImpl;
import com.amway.domain.include.SponsoringStats;
import com.amway.domain.list.Details;

public class SponStatsHelper {

	public void mapGroupCounts(int period, List<Details> listDetails, Set<String> businessNatures,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		Map<Long, Integer> groupCountsMap = new SponsoringStatisticsImpl().getGroupCounts(period,
				namedParameterJdbcTemplate, businessNatures);
		SponsoringStats sponsoringStats = null;
		for (Details detail : nullSafe(listDetails)) {
			sponsoringStats = new SponsoringStats();
			sponsoringStats.setGroupCount(null == groupCountsMap.get(detail.getBonusCustomerId()) ? 0
					: groupCountsMap.get(detail.getBonusCustomerId()));
			detail.setSponsoringStats(sponsoringStats);
		}
	}

	/**
	 * Null safe.
	 *
	 * @param   <T> the generic type
	 * @param c the c
	 * @return the collection
	 */
	private static <T> Collection<T> nullSafe(Collection<T> c) {
		return (c == null) ? Collections.<T>emptyList() : c;
	}
}
