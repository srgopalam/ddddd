package com.amway.helper;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.amway.dao.TransactionInquiryDaoImpl;
import com.amway.domain.list.Details;

public class TransactionInquiryHelper {

	private static final String TRX_REWORK_CODE = "006";
	private static final String TRX_TOPUP_CODE = "013";
	private static final String TRX_RETURNS_CODE = "004";

	public void mapHasReworks(int period, List<Details> listDetails,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		List<Long> filteredList = new TransactionInquiryDaoImpl().getFilteredCustomersWithGivenTrxSourceCd(period,
				namedParameterJdbcTemplate, TRX_REWORK_CODE);
		if (null != filteredList) {
			for (Details detail : nullSafe(listDetails)) {
				detail.setHasRework(filteredList.contains(detail.getBonusCustomerId()));
			}
		}
	}

	public void mapHasTopup(int period, List<Details> listDetails,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		List<Long> filteredList = new TransactionInquiryDaoImpl().getFilteredCustomersWithGivenTrxSourceCd(period,
				namedParameterJdbcTemplate, TRX_TOPUP_CODE);
		if (null != filteredList) {
			for (Details detail : nullSafe(listDetails)) {
				detail.setHasTopup(filteredList.contains(detail.getBonusCustomerId()));
			}
		}
	}

	public void mapHasReturns(int period, List<Details> listDetails,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		List<Long> filteredList = new TransactionInquiryDaoImpl().getFilteredCustomersWithGivenTrxSourceCd(period,
				namedParameterJdbcTemplate, TRX_RETURNS_CODE);
		if (null != filteredList) {
			for (Details detail : nullSafe(listDetails)) {
				detail.setHasReturns(filteredList.contains(detail.getBonusCustomerId()));
			}
		}
	}

	public void mapHasReworkImpact(int period, List<Details> listDetails, int affNo,
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		List<Long> filteredList = new TransactionInquiryDaoImpl().getFilteredCustomersWithGeneratedImpact(period, affNo,
				namedParameterJdbcTemplate);
		if (null != filteredList) {
			for (Details detail : nullSafe(listDetails)) {
				detail.setHasReworkImpact(filteredList.contains(detail.getBonusCustomerId()));
			}
		}
	}

	/**
	 * Null safe.
	 *
	 * @param   <T> the generic type
	 * @param c the c
	 * @return the collection
	 */
	private static <T> Collection<T> nullSafe(Collection<T> c) {
		return (c == null) ? Collections.<T>emptyList() : c;
	}
}
