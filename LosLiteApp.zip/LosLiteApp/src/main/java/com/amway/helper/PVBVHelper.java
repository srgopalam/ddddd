package com.amway.helper;

import com.amway.api.rest.VolumeAsyncController;
import com.amway.dao.BonusExchangeRate;
import com.amway.dao.BonusPercentImpl;
import com.amway.dao.BusinessEntity;
import com.amway.dao.DetailImpl;
import com.amway.dao.PVBVDetailImpl;
import com.amway.domain.CustomerData;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.domain.include.PVBVSummary;
import com.amway.domain.include.VolumeDetails;
import com.amway.domain.include.VolumeTypesPVBVData;
import com.amway.domain.list.Details;
import com.amway.dto.NextPercentageAndVolume;
import com.amway.model.AffiliateMasterData;
import com.amway.model.BusinessEntityData;
import com.amway.model.CustomerPercentage;
import com.amway.model.PVBVDetailData;
import com.amway.service.CaffeineCacheService;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class PVBVHelper {
	public static final String EXCHANGE_RATE_TYPE_MONTHLY_AVERAGE = "03";

	public PVBVHelper() {
		super();
	}

	public void mapPercentAndVolume(int period, Map<Long, Integer> bonusPercentMap,
			Map<Long, Integer> leadeshipPercentMap,
			Map<String, NextPercentageAndVolume> nextPercentAndVolTempHoldingMap, Details detail,
			VolumeAsyncController volumeAsyncController) {
		NextPercentageAndVolume nextPercentageAndVolume;
		String nextPercentKey;
		int currentPercent;
		int leadershipPercent;
		int nextVolume;
		VolumeDetails volumeDetails;
		currentPercent = (null == bonusPercentMap.get(detail.getBonusCustomerId()) ? 0
				: bonusPercentMap.get(detail.getBonusCustomerId()));
		leadershipPercent = (null == leadeshipPercentMap.get(detail.getBonusCustomerId()) ? 0
				: leadeshipPercentMap.get(detail.getBonusCustomerId()));
		nextPercentKey = detail.getAff() + DetailImpl.POUND + detail.getBusinessEntity() + DetailImpl.POUND + period
				+ DetailImpl.POUND + currentPercent;
		if (!nextPercentAndVolTempHoldingMap.containsKey(nextPercentKey)) {
			nextPercentageAndVolume = volumeAsyncController.getNextPercentageData(detail.getAff(),
					detail.getBusinessEntity(), period, currentPercent, DetailImpl.PERFORMANCE_BONUS_AWARD_NO);
			nextVolume = volumeAsyncController.getNextVolume(detail.getAff(), detail.getBusinessEntity(), period,
					nextPercentageAndVolume.getScheduleLevelNumber(), DetailImpl.PERFORMANCE_BONUS_AWARD_NO);
			nextPercentageAndVolume.setNextVolume(nextVolume);
			nextPercentAndVolTempHoldingMap.put(nextPercentKey, nextPercentageAndVolume);
		}
		nextPercentageAndVolume = nextPercentAndVolTempHoldingMap.get(nextPercentKey);
		volumeDetails = new VolumeDetails();
		volumeDetails.setBonusPercent(currentPercent);
		volumeDetails.setLeadershipPercent(leadershipPercent);
		volumeDetails.setNextPercentage(nextPercentageAndVolume.getNextPercentage());
		volumeDetails.setNextVolume(nextPercentageAndVolume.getNextVolume());
		detail.setVolumeDetails(volumeDetails);
	}

	public void mapPvBv(CustomerData customerData, ModelLosDetailsRequest modelLosDetailsRequest, int period,
			Map<Integer, AffiliateMasterData> affMasterMap, Map<Integer, BusinessEntityData> businessEntityDetailMap,
			Map<String, List<PVBVDetailData>> pvBvMapByVolType, Details detail, CaffeineCacheService caffeineCacheService,
			BonusExchangeRate bonusExchangeRate) {
		VolumeDetails volumeDetails;
		volumeDetails = detail.getVolumeDetails();
		BusinessEntityData requestedBusinessEntityDetails = businessEntityDetailMap
				.get(customerData.getBusinessEntity());
		VolumeTypesPVBVData volumeTypesPVBVData;
		List<VolumeTypesPVBVData> volumeTypesPVBVList = new ArrayList<>();
		StringBuilder baseKey = new StringBuilder();
		baseKey.append(detail.getBonusCustomerId()).append(DetailImpl.POUND).append(period).append(DetailImpl.POUND);
		for (String volumeType : nullSafe(modelLosDetailsRequest.getVolumeTypes())) {
			String key = baseKey + volumeType;
			for (PVBVDetailData data : nullSafe(pvBvMapByVolType.get(key))) {
				volumeTypesPVBVData = new VolumeTypesPVBVData();
				volumeTypesPVBVData.setVolumeTypeCode(volumeType);
				volumeTypesPVBVData.setPv(data.getPvQuantity());
				volumeTypesPVBVData.setYtdPvTotal(data.getYtdPvQuantity());
				volumeTypesPVBVData.setBv(data.getBvQuantity());
				volumeTypesPVBVList.add(volumeTypesPVBVData);
			}
		}
		mapAboPvBv(detail, volumeDetails, requestedBusinessEntityDetails, volumeTypesPVBVList);
	}

	private void mapAboPvBv(Details detail, VolumeDetails volumeDetails,
			BusinessEntityData requestedBusinessEntityDetails, List<VolumeTypesPVBVData> volumeTypesPVBVList) {
		PVBVSummary aboPvBv = new PVBVSummary();
		List<VolumeTypesPVBVData> aboVolumeTypesPVBVList = new ArrayList<>();
		for (VolumeTypesPVBVData data : nullSafe(volumeTypesPVBVList)) {
			aboVolumeTypesPVBVList.add(data);
		}
		aboPvBv.setVolumeTypesPVBVDataList(aboVolumeTypesPVBVList);
		if (null != volumeDetails && null != detail) {
			volumeDetails.setAboPvBv(aboPvBv);
			detail.setVolumeDetails(volumeDetails);
		}
	}

	public void mapVolumeDetails(CustomerData customerData, ModelLosDetailsRequest modelLosDetailsRequest,
			int period, List<Details> listDetails, CaffeineCacheService caffeineCacheService,
			VolumeAsyncController volumeAsyncController, BusinessEntity businessEntity,
			BonusExchangeRate bonusExchangeRate, NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		Map<Long, Details> allDetailsMapByCustomer = new HashMap<>();

		for (Details detail : listDetails) {
			allDetailsMapByCustomer.put(detail.getBonusCustomerId(), detail);
		}

		Set<String> volumeTypes = modelLosDetailsRequest.getVolumeTypes();
		List<CustomerPercentage> cPercentList = new BonusPercentImpl().getBonusPercent(period,
				namedParameterJdbcTemplate, DetailImpl.PERFORMANCE_BONUS_AWARD_NO);
		Map<Long, Integer> bonusPercentMap = new HashMap<>();

		List<CustomerPercentage> leadershipPercentList = new BonusPercentImpl().getBonusPercent(period,
				namedParameterJdbcTemplate, DetailImpl.LEADERSHIP_BONUS_AWARD_NO);
		Map<Long, Integer> leadeshipPercentMap = new HashMap<>();
		for (CustomerPercentage cPercent : cPercentList) {
			bonusPercentMap.put(cPercent.getBonusCustomerId(), cPercent.getBonusPercent());
		}

		for (CustomerPercentage cPercent : leadershipPercentList) {
			leadeshipPercentMap.put(cPercent.getBonusCustomerId(), cPercent.getBonusPercent());
		}

		Map<String, NextPercentageAndVolume> nextPercentAndVolTempHoldingMap = new HashMap<>();
		for (Details detail : listDetails) {
			mapPercentAndVolume(period, bonusPercentMap, leadeshipPercentMap, nextPercentAndVolTempHoldingMap, detail,
					volumeAsyncController);
		}

		// Populate affiliate master data
		Map<Integer, AffiliateMasterData> affMasterMap = caffeineCacheService.getAllAffiliatesDataMap();

		// Populate business entity details data
		Map<Integer, BusinessEntityData> businessEntityDetailMap = businessEntity
				.getBusinessEntityDetailsMapByPeriod(period);
		// Populate PV BV data by volume
		Map<String, List<PVBVDetailData>> pvBvMapByVolType = new HashMap<>();

		List<PVBVDetailData> pvBvDetailDataList = new PVBVDetailImpl()
				.getPVBVDataByVolumeType(namedParameterJdbcTemplate, volumeTypes, period);
		String pvBvKey;
		for (PVBVDetailData data : pvBvDetailDataList) {
			pvBvKey = data.getBonusCustomerId() + DetailImpl.POUND + data.getBonusPeriod() + DetailImpl.POUND
					+ data.getVolumeTypeCode();
			pvBvMapByVolType.computeIfAbsent(pvBvKey, k -> new ArrayList<>()).add(data);
		}
		if (modelLosDetailsRequest.isIncludeYTDpv()) {
			setYtdPvQty(namedParameterJdbcTemplate, period, volumeTypes, pvBvMapByVolType);
		}
		for (Details detail : listDetails) {
			mapPvBv(customerData, modelLosDetailsRequest, period, affMasterMap, businessEntityDetailMap,
					pvBvMapByVolType, detail, caffeineCacheService, bonusExchangeRate);
		}
	}

	private void setYtdPvQty(NamedParameterJdbcTemplate namedParameterJdbcTemplate, int period, Set<String> volumeTypes,
			Map<String, List<PVBVDetailData>> pvBvMapByVolType) {
		List<PVBVDetailData> pvBvDetailDataList;
		String pvBvKey;
		pvBvDetailDataList = new PVBVDetailImpl().getYtdPVBVDataByVolumeType(namedParameterJdbcTemplate, volumeTypes,
				period);
		Map<String, BigDecimal> pvbvDetailMap = new HashMap<>();
		for (PVBVDetailData data : pvBvDetailDataList) {
			pvBvKey = data.getBonusCustomerId() + DetailImpl.POUND + data.getBonusPeriod() + DetailImpl.POUND
					+ data.getVolumeTypeCode() + DetailImpl.POUND + data.getBusinessEntity();
			pvbvDetailMap.put(pvBvKey, data.getYtdPvQuantity());
		}
		for (Map.Entry<String, List<PVBVDetailData>> entry : pvBvMapByVolType.entrySet()) {
			for (PVBVDetailData data : entry.getValue()) {
				data.setYtdPvQuantity(pvbvDetailMap
						.get(data.getBonusCustomerId() + DetailImpl.POUND + data.getBonusPeriod() + DetailImpl.POUND
								+ data.getVolumeTypeCode() + DetailImpl.POUND + data.getBusinessEntity()));
			}
		}
	}

	/**
	 * Null safe.
	 *
	 * @param <T> the generic type
	 * @param c   the c
	 * @return the collection
	 */
	private static <T> Collection<T> nullSafe(Collection<T> c) {
		return (c == null) ? Collections.<T>emptyList() : c;
	}
}
