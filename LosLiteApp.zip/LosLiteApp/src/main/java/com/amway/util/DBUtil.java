package com.amway.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;

public class DBUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(DBUtil.class);
	private static final String SQL_EXCEPTION_MSG = "SQLException occured!";

	private DBUtil() {
		super();
	}

	public static void commitConnection(final JdbcTemplate jdbcTemplate) {
		SingleConnectionDataSource scds = null;
		Connection scdsConnection = null;
		try {
			scdsConnection = jdbcTemplate.getDataSource().getConnection();
			scds = new SingleConnectionDataSource(scdsConnection, false);
			scdsConnection.commit();
		} catch (SQLException e) {
			LOGGER.error(SQL_EXCEPTION_MSG, e);
		} finally {
			if (null != scds && scds.shouldClose(scdsConnection)) {
				try {
					scdsConnection.close();
				} catch (SQLException e) {
					LOGGER.error(SQL_EXCEPTION_MSG, e);
				}
			}
		}
	}

	public static void releaseConnection(final JdbcTemplate jdbcTemplate) {
		try (final Connection connection = jdbcTemplate.getDataSource().getConnection()) {
			connection.commit();
		} catch (SQLException e) {
			LOGGER.error(SQL_EXCEPTION_MSG, e);
		}
	}

	public static JdbcTemplate getSingleConnectionJdbcTemplate(final JdbcTemplate jdbcTemplate) {
		SingleConnectionDataSource scds = null;
		JdbcTemplate scdsJdbcTemplate = null;
		Connection scdsConnection = null;
		try {
			scdsConnection = jdbcTemplate.getDataSource().getConnection();
			scds = new SingleConnectionDataSource(scdsConnection, false);
			scdsJdbcTemplate = new JdbcTemplate(scds);
			scdsConnection.setAutoCommit(false);
			return scdsJdbcTemplate;
		} catch (SQLException e) {
			LOGGER.error(SQL_EXCEPTION_MSG, e);
			return scdsJdbcTemplate;
		} finally {
			if (null != scds && scds.shouldClose(scdsConnection)) {
				try {
					scdsConnection.close();
				} catch (SQLException e) {
					LOGGER.error(SQL_EXCEPTION_MSG, e);
				}
			}
		}
	}

	public static void insertIntoTempTable(final JdbcTemplate scdsJdbcTemplate, final List<Long> bonusCustomerList) {
		// AMWAY CORPORATION, Sponsors himself
		Long amwayAff = new Long("1563");
		bonusCustomerList.remove(amwayAff);
		scdsJdbcTemplate.batchUpdate("INSERT INTO TTL02000_LOS_DTL_SVC(BNS_CUST_ID) VALUES(?)",
				new BatchPreparedStatementSetter() {
					public int getBatchSize() {
						return bonusCustomerList.size();
					}

					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setLong(1, bonusCustomerList.get(i));
					}
				});
	}
}
