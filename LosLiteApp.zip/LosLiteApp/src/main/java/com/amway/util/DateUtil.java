package com.amway.util;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintViolation;

import com.amway.exception.DataRangeException;

public class DateUtil {
	private DateUtil() {
		super();
	}

	public static final String REGEX_MMYYYY_FORMAT = "^((0[1-9])|(1[0-2]))([0-9]{4})$";
	public static final String REGEX_YYYYMM_FORMAT = "^([0-9]{4})((0[1-9])|(1[0-2]))$";

	protected static final Set<? extends ConstraintViolation<?>> CONSTRAINT_VIOLATION_SET = new HashSet<>();

	public static boolean isValidPeriod(String period, Enum<?> expectedFormat) {
		String regex;
		if (PeriodFormat.YYYYMM.equals(expectedFormat)) {
			regex = REGEX_YYYYMM_FORMAT;
		} else {
			regex = REGEX_MMYYYY_FORMAT;
		}
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(period);
		return m.matches();
	}

	private static void validateYear(int year) {
		if (!isValidYear(year)) {
			throw new DataRangeException(year + " is not a valid year", CONSTRAINT_VIOLATION_SET);
		}
	}

	private static boolean isValidYear(int year) {
		return year > 0 && year <= 9999;
	}

	private static void validatePeriod(int period) {
		if (!isValidPeriod(String.valueOf(period), PeriodFormat.YYYYMM)) {
			throw new DataRangeException(period + " is not a valid period", CONSTRAINT_VIOLATION_SET);
		}
	}

	public static int endOfFiscalYear(int fiscalYear) {
		validateYear(fiscalYear);
		return fiscalYear * 100 + 8;
	}

	public static int startOfFiscalYear(int fiscalYear) {
		validateYear(fiscalYear);
		return (fiscalYear - 1) * 100 + 9;
	}

	public static int fiscalYear(int period) {
		validatePeriod(period);
		int month = period % 100;
		int year = period / 100;
		if (month >= 9) {
			year++;
		}
		return year;
	}

	public static Date endDate(int period) {

		String periodString = Integer.toString(period);
		String yearString = periodString.substring(0, 4);
		String monthString = periodString.substring(4, 6);

		int year = Integer.parseInt(yearString);
		int month = Integer.parseInt(monthString);
		month--; // Calendar stores month starting at zero (JAN = 0, FEB = 1,
		// ...)

		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.set(Calendar.YEAR, year);
		calendar.set(Calendar.MONTH, month);
		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		calendar.set(Calendar.HOUR_OF_DAY, calendar.getActualMaximum(Calendar.HOUR_OF_DAY));
		calendar.set(Calendar.MINUTE, calendar.getActualMaximum(Calendar.MINUTE));
		calendar.set(Calendar.SECOND, calendar.getActualMaximum(Calendar.SECOND));
		calendar.set(Calendar.MILLISECOND, calendar.getActualMaximum(Calendar.MILLISECOND));

		return calendar.getTime();
	}

}