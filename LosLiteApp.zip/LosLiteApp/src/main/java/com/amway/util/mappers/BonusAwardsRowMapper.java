package com.amway.util.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.amway.model.BonusAwardMaster;

@SuppressWarnings("rawtypes")
public class BonusAwardsRowMapper implements RowMapper {
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		BonusAwardMaster bonusAwardsData = new BonusAwardMaster();
		bonusAwardsData.setBonusAwardNo(rs.getInt("BNS_AWD_NO"));
		bonusAwardsData.setBonusAwardName(rs.getString("BNS_AWD_NM"));
		bonusAwardsData.setBonusAwardDesc(rs.getString("BNS_AWD_DESC"));
		bonusAwardsData.setBonusAwardGroupCode(rs.getString("BNS_AWD_GRP_CD"));
		bonusAwardsData.setWwAliasText(rs.getString("WW_ALIAS_TXT"));
		bonusAwardsData.setTopupCode(rs.getString("TOP_UP_CD"));
		bonusAwardsData.setProcCode(rs.getString("PROC_CD"));
		return bonusAwardsData;
	}
}