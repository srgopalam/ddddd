package com.amway.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class RESTFulServiceConsumer {
	public RESTFulServiceConsumer() {
		super();
	}

	@Value("${los.auth.api}")
	private String losAuthURL;
	@Value("${basic.auth.passcode}")
	private String basicAuthPasscode;

	public boolean authCheck(int reqAff, long reqAbo, int aff, long abo, int period) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Basic TUFHSUM6QVlUZDZ3R0I=");
		HttpEntity<String> request = new HttpEntity<>(headers);
		// Query parameters
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(this.losAuthURL)
				// Add query parameter
				.queryParam("reqAff", reqAff).queryParam("reqAbo", reqAbo).queryParam("aff", aff).queryParam("abo", abo)
				.queryParam("period", period);
		ResponseEntity<String> response = restTemplate.exchange(builder.buildAndExpand().toUri(), HttpMethod.GET,
				request, String.class);
		String consumeJSONString = response.getBody();
		return null != consumeJSONString && consumeJSONString.contains("true");
	}

}