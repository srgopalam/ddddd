package com.amway.util.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.amway.model.CustomerPercentage;

@SuppressWarnings("rawtypes")
public class CustomerPercentageRowMapper implements RowMapper {
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		CustomerPercentage data = new CustomerPercentage();
		data.setBonusCustomerId(rs.getLong("BNS_CUST_ID"));
		data.setBonusPercent(rs.getInt("CALC_PCT"));
		return data;
	}
}