package com.amway.util.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.amway.model.BasicServiceOutputData;

@SuppressWarnings("rawtypes")
public class BasicServiceOutputMapper implements RowMapper {
	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		BasicServiceOutputData basicServiceOutputData = new BasicServiceOutputData();
		basicServiceOutputData.setBonusCustomer(rs.getLong("BNS_CUST_ID"));
		basicServiceOutputData.setAff(rs.getInt("AFF_NO"));
		basicServiceOutputData.setAbo(rs.getLong("IBO_NO"));
		basicServiceOutputData.setBusinessStatusCode(rs.getString("CUST_STAT_CD").trim());
		basicServiceOutputData.setAboName(rs.getString("CUST_NM"));
		basicServiceOutputData.setSponsorAff(rs.getInt("SPON_AFF_ID"));
		basicServiceOutputData.setSponsorAbo(rs.getLong("SPON_IBO_NO"));
		basicServiceOutputData.setBusinessEntity(rs.getInt("BUS_ENTTY_NO"));
		basicServiceOutputData.setAboClass(rs.getString("CUST_CLASS_CD"));
		basicServiceOutputData.setBusinessNature(rs.getString("BUS_NATR_CD").trim());
		basicServiceOutputData.setCountry(rs.getString("AMWAY_CNTRY_CD"));
		basicServiceOutputData.setLosLevelNo(rs.getInt("LOS_LVL_NO"));
		basicServiceOutputData.setLosTypeCode(rs.getString("LOS_TYPE_CD"));
		basicServiceOutputData.setSponsorCustomerId(rs.getLong("SPON_CUST_ID"));
		basicServiceOutputData.setSegmentCode(rs.getString("SEG_CD"));
		return basicServiceOutputData;
	}
}
