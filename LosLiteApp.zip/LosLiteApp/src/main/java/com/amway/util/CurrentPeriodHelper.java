package com.amway.util;

import java.util.ArrayList;
import java.util.List;

import com.amway.service.CacheService;
import com.amway.service.CaffeineCacheService;

public class CurrentPeriodHelper {

	private CurrentPeriodHelper() {
		super();
	}

	public static boolean shouldWeGetDataFromGloss(int aff, int bnsPeriod, CaffeineCacheService cacheService) {
		int affCurrPeriod = cacheService.getCurrentBnsPeriodsByAffiliates().get(aff);
		int losBuildPeriod = cacheService.getLosBuildPeriodsByAffiliates().get(aff);
		if (bnsPeriod > affCurrPeriod) {
			return true;
		} else if (bnsPeriod < affCurrPeriod) {
			return false;
		} else // bnsPeriod == affCurrPeriod
		if (losBuildPeriod <= 0) {
			return true;
		}
		if (losBuildPeriod >= bnsPeriod) {
			return false;
		} else {
			return true;
		}
	}

	public static List<Integer> getGlossAffiliatesByPeriod(int bnsPeriod, CaffeineCacheService cacheService) {
		List<Integer> affList = cacheService.getAllAffiliates();
		List<Integer> glossAffList = new ArrayList<>();
		for (int aff : affList) {
			if (shouldWeGetDataFromGloss(aff, bnsPeriod, cacheService)) {
				glossAffList.add(aff);
			}
		}
		return glossAffList;
	}

	public static boolean shouldWeGetDataFromGloss(int aff, int bnsPeriod, CacheService cacheService) {
		int affCurrPeriod = cacheService.getCurrentBnsPeriodsByAffiliates(cacheService.isCacheEnabled()).get(aff);
		int losBuildPeriod = cacheService.getLosBuildPeriodsByAffiliates(cacheService.isCacheEnabled()).get(aff);
		if (bnsPeriod > affCurrPeriod) {
			return true;
		} else if (bnsPeriod < affCurrPeriod) {
			return false;
		} else // bnsPeriod == affCurrPeriod
		if (losBuildPeriod <= 0) {
			return true;
		}
		if (losBuildPeriod >= bnsPeriod) {
			return false;
		} else {
			return true;
		}
	}

	public static List<Integer> getGlossAffiliatesByPeriod(int bnsPeriod, CacheService cacheService) {
		List<Integer> affList = cacheService.getAllAffiliates(cacheService.isCacheEnabled());
		List<Integer> glossAffList = new ArrayList<>();
		for (int aff : affList) {
			if (shouldWeGetDataFromGloss(aff, bnsPeriod, cacheService)) {
				glossAffList.add(aff);
			}
		}
		return glossAffList;
	}
}