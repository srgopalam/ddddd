package com.amway.util;

public enum LOSType {
	MONTHLY_IN_MARKET_SPONSOR("A", "mm"), //
	MONTHLY_INTERNATIONAL_SPONSOR("B", "mn"), //
	LOS_MULTI_BUSINESS_SPONSOR("C", "mb"), //
	ANNUAL_IN_MARKET_SPONSOR("D", "am"), //
	ANNUAL_INTERNATIONAL_SPONSOR("E", "an"), //
	INTERNATIONAL_SPONSOR_DESIGNATOR("F", "sd"), //
	GLOBAL_MULTI_BUSINESS_SPONSOR("G", "gm"); //

	private LOSType(final String glossCode, final String magicCode) {
		this.glossCode = glossCode;
		this.magicCode = magicCode;
	}

	private final String glossCode;
	private final String magicCode;

	public String getGlossCode() {
		return this.glossCode;
	}

	public String getMagicCode() {
		return this.magicCode;
	}

}
