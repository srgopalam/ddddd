package com.amway.util;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amway.dao.IDetail;
import com.amway.dao.DetailGlossImpl;
import com.amway.dao.DetailMagicImpl;
import com.amway.domain.CustomerData;

@Component
public class VolumeDetailFactory {
	private static final String MAGIC = "MAGIC";
	private static final String GLOSS = "GLOSS";

	private static final Map<String, IDetail> detailCache = new HashMap<>();
	@Autowired
	private DetailGlossImpl glossImpl;

	@Autowired
	private DetailMagicImpl magicImpl;

	@PostConstruct
	public void initMyServiceCache() {
		detailCache.put(GLOSS, glossImpl);
		detailCache.put(MAGIC, magicImpl);
	}

	private VolumeDetailFactory() {
	}

	public static IDetail getImplementation(CustomerData customerData) {
		if (null != customerData && customerData.isGlossPeriod()) {
			return detailCache.get(GLOSS);
		} else {
			return detailCache.get(MAGIC);
		}
	}

}
