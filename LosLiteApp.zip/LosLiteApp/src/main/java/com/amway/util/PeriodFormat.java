package com.amway.util;

public enum PeriodFormat {
	YYYYMM, MMYYYY;
}
