package com.amway.api.rest;

import com.amway.domain.CustomerData;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.domain.list.Details;
import com.amway.model.BasicServiceOutputData;
import com.amway.service.CaffeineCacheService;
import com.amway.service.MethodAsyncService;
import com.amway.util.CurrentPeriodHelper;
import com.amway.util.DBUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SuppressWarnings("unchecked")
public class MethodAsyncController {

	@Autowired
	private MethodAsyncService methodAsyncService;
	@Autowired
	private CaffeineCacheService caffeineCacheService;

	protected static <T> Collection<T> nullSafe(Collection<T> c) {
		return (c == null) ? Collections.<T>emptyList() : c;
	}

	public void taskExecutorForMethods(CustomerData customerData,
			ModelLosDetailsRequest modelLosDetailsRequest, int period, List<String> customerStatusCodes,
			List<Details> listDetails, JdbcTemplate scdsJdbcTemplate) {
		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(scdsJdbcTemplate);
		Map<Long, Details> allDetailsMapByCustomer = new HashMap<>();
		for (Details detail : nullSafe(listDetails)) {
			allDetailsMapByCustomer.put(detail.getBonusCustomerId(), detail);
		}
		List<Long> allCustomersList = new ArrayList<>(allDetailsMapByCustomer.keySet());

		DBUtil.insertIntoTempTable(scdsJdbcTemplate, allCustomersList);
		List<CompletableFuture<Void>> methodList = new ArrayList<>();
		if (modelLosDetailsRequest.isIncludeAboAttr()) {
			methodList.add(methodAsyncService.includeAboAttr(customerData, period,
					listDetails, namedParameterJdbcTemplate));
		}
		if (modelLosDetailsRequest.isIncludeUpline()) {
			methodList.add(methodAsyncService.includeUpline(period,
					listDetails));
		}
		if (modelLosDetailsRequest.isIncludeVolumeDetails()) {
			methodList.add(
					methodAsyncService.includeVolumeDetails(customerData, modelLosDetailsRequest, period,
							listDetails, namedParameterJdbcTemplate));
		}
		if (modelLosDetailsRequest.isIncludeAwardLevels()) {
			methodList
					.add(methodAsyncService.includeAwardLevels(period,
							listDetails, namedParameterJdbcTemplate));
		}
		if (modelLosDetailsRequest.isIncludeQualCount()) {
			methodList.add(methodAsyncService.includeQualCount(period,
					listDetails, namedParameterJdbcTemplate));
		}
		if (modelLosDetailsRequest.isIncludeSponStats()) {
			methodList.add(methodAsyncService.includeSponStats(customerData, modelLosDetailsRequest, period,
					listDetails, namedParameterJdbcTemplate));
		}
		if (modelLosDetailsRequest.isIncludeHasDownlineFlag()) {
			final boolean fromGloss = CurrentPeriodHelper.shouldWeGetDataFromGloss(customerData.getAff(),
					period, caffeineCacheService);
			methodList.add(methodAsyncService.includeHasDownlineFlag(customerData, modelLosDetailsRequest,
					period, customerStatusCodes, listDetails, namedParameterJdbcTemplate));
			if (fromGloss) {
				methodList.add(methodAsyncService.includeHasDownlineFlagIntl(modelLosDetailsRequest,
						period, customerStatusCodes, listDetails, namedParameterJdbcTemplate));
			}
		}
		concatenateAsync(methodList);
	}

	private void concatenateAsync(List<CompletableFuture<Void>> methodList) {
		// Restructure as varargs because that's what CompletableFuture.allOf requires.
		CompletableFuture<List<BasicServiceOutputData>>[] futuresAsVarArgs =
				methodList.toArray(new CompletableFuture[0]);
		// Create a new future to gather results once all of the previous futures complete.
		CompletableFuture.allOf(futuresAsVarArgs).join();
	}
}