package com.amway.api.rest;

import java.lang.management.ManagementFactory;

import javax.management.JMX;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.apache.commons.httpclient.util.HttpURLConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.amway.constraints.ThrottleChecks;
import com.amway.dao.BonusCustomer;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.domain.list.VolumeDetailPeriods;
import com.amway.service.CacheService;
import com.amway.service.CaffeineCacheService;
import com.amway.service.LosService;
import com.zaxxer.hikari.HikariPoolMXBean;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author Sreenivasa Gopalam
 */
@Validated
@RestController
public class LosController {
	private static final Logger LOGGER = LoggerFactory.getLogger(LosController.class);

	@Autowired
	private MessageSource messageSource;
	@Autowired
	private CacheService cacheService;
	@Autowired
	private CaffeineCacheService caffeineCacheService;
	private final LosService losService;
	@Autowired
	private BonusCustomer bonusCustomer;
	@Autowired
	private Environment env;

	@Autowired
	public LosController(LosService losService) {
		this.losService = losService;
	}

	@ApiOperation(value = "Getting the LOS & Volume details!", nickname = "getLOSDetails", response = VolumeDetailPeriods.class)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "affAbo[]", value = "AFF-ABO List. Ex:010-670, 430-22", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "period[]", value = "Period or list of periods separated by comma", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "businessNature[]", value = "Business natures filter, accepts list separated by comma. Ex:1,4", dataType = "string", paramType = "query"),
			@ApiImplicitParam(name = "volumeType[]", value = "Volume types filter, accepts list separated by comma. Ex:035.  Defaults to 001 Personal Volume when no volume types are selected", //
					dataType = "string", paramType = "query"),
			@ApiImplicitParam(name = "includeInactive", value = "Set this flag to to true to include in-active downlines.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeMap", value = "Set this flag to true to get downlines as a Map.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeInternational", value = "Set this flag to true to include international downlines.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeFrontline", value = "Set this flag to true to include frontlines.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeGlobalMB", value = "Set this flag to true to include globle multi business downlines.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeVolumeDetails", value = "Set this flag to true to include volume details.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeAwardLevels", value = "Set this flag to true to include award details.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeQualCount", value = "Set this flag to true to include qualification counts.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeSponStats", value = "Set this flag to true to include sponsoring statistics.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeAboAttr", value = "Set this flag to true to include ABO attributes.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeUpline", value = "Set this flag to true to include upline information.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeYTDpvTotals", value = "Set this flag to true to include YTD PV Totals.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeReworkImpact", value = "Set this flag to true to include rework impact flag.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "includeHasDownlineFlag", value = "Set this flag to true to include hasDownline flag.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "asList", value = "Set this flag to true to get downlines as a list.", dataType = "boolean", paramType = "query"),
			@ApiImplicitParam(name = "X-Mashery-Oauth-Scope", value = "Reading requestor information from header", dataType = "string", paramType = "header") })
	@ApiResponses(value = {
			@ApiResponse(code = HttpURLConnection.HTTP_OK, message = "Returns ABO's bonus details as asked."),
			@ApiResponse(code = HttpURLConnection.HTTP_UNAUTHORIZED, message = "Unauthorized"),
			@ApiResponse(code = HttpURLConnection.HTTP_NOT_FOUND, message = "Not found"),
			@ApiResponse(code = HttpURLConnection.HTTP_INTERNAL_ERROR, message = "Internal server problems") })
	@GetMapping("/details")
	public @ResponseBody ResponseEntity<Object> processServiceInputs(
			@ApiIgnore ModelLosDetailsRequest modelLosDetailsRequest) throws Exception {
		if (LOGGER.isDebugEnabled()) {
			MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
			ObjectName poolName = null;
			try {
				poolName = new ObjectName("com.zaxxer.hikari:type=Pool (HikariPool)");
			} catch (MalformedObjectNameException e) {
				LOGGER.error("MalformedObjectNameException occured!", e);
			}
			HikariPoolMXBean poolProxy = JMX.newMXBeanProxy(mBeanServer, poolName, HikariPoolMXBean.class);
			LOGGER.debug("############################################");
			LOGGER.debug("idleConnections:{}", poolProxy.getIdleConnections());
			LOGGER.debug("activeConnections:{}", poolProxy.getActiveConnections());
			LOGGER.debug("totalConnections:{}", poolProxy.getTotalConnections());
			LOGGER.debug("getThreadsAwaitingConnection:{}", poolProxy.getThreadsAwaitingConnection());
			LOGGER.debug("############################################");
		}
		if (modelLosDetailsRequest.getReqAff() > 0 && modelLosDetailsRequest.getReqAbo() > 0) {
			try {
				bonusCustomer.getCustomerData(modelLosDetailsRequest.getReqAff(), modelLosDetailsRequest.getReqAbo());
			} catch (Exception ex) {
				LOGGER.error("Exception occured!", ex);
				return new ResponseEntity<>("Requestor validation failed! " + ex.getMessage(), HttpStatus.BAD_REQUEST);
			}
		}
		ThrottleChecks.check(modelLosDetailsRequest, messageSource, caffeineCacheService);
		VolumeDetailPeriods volumeDetailPeriods = losService.processServiceInputs(modelLosDetailsRequest);
		return new ResponseEntity<>(volumeDetailPeriods, HttpStatus.OK);
	}

	@ApiOperation(value = "Clear the lookup cache!", nickname = "clearLookupCache", response = String.class)
	@PutMapping(value = "/clearLookupCache", produces = "plain/text")
	public @ResponseBody ResponseEntity<String> clearLookupCache() {
		cacheService.clear(true);
		caffeineCacheService.clear();
		return new ResponseEntity<>("losAppLookupMap has been cleared on " + env.getProperty("EXTREME_ENVIRONMENT"),
				HttpStatus.OK);
	}

	@ApiOperation(value = "Business Natures List!", nickname = "BNList", response = String.class)
	@GetMapping("/bnList")
	public @ResponseBody ResponseEntity<String> bnList() {
		return new ResponseEntity<>(caffeineCacheService.getAllBusinessNatureCodes().toString(), HttpStatus.OK);
	}

	@ApiOperation(value = "Volume Types List!", nickname = "volumeTypes", response = String.class)
	@GetMapping("/volumeTypes")
	public @ResponseBody ResponseEntity<String> volumeTypes() {
		return new ResponseEntity<>(cacheService.getAllVolumeTypesData(true).toString(), HttpStatus.OK);
	}
}
