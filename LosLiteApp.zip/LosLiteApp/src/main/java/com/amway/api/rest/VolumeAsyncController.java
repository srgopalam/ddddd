package com.amway.api.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.amway.dao.NextPercentage;
import com.amway.dto.NextPercentageAndVolume;
import com.google.common.base.Predicates;
import com.google.common.collect.Iterables;

@RestController
public class VolumeAsyncController {
	@Autowired
	private NextPercentage nextPercentage;

	public NextPercentageAndVolume getNextPercentageData(int aff, int businessEntity, int period, int currentPercentage,
			int awardNumber) {
		NextPercentageAndVolume nextPercentageData;
		try {
			nextPercentageData = nextPercentage.getNextPercentageData(aff, businessEntity, period, currentPercentage,
					awardNumber);
		} catch (Exception e) {
			nextPercentageData = new NextPercentageAndVolume(currentPercentage, 1, 1);
		}
		return nextPercentageData;
	}

	public int getNextVolume(int aff, int businessEntity, int period, int scheduleLevel, int awardNumber) {
		List<Integer> nextVolumeList = nextPercentage.getNextVolume(aff, businessEntity, period, scheduleLevel,
				awardNumber);
		return Iterables.find(nextVolumeList, Predicates.notNull());
	}

}