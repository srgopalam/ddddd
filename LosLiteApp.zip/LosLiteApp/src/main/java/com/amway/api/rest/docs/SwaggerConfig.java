package com.amway.api.rest.docs;

import static springfox.documentation.schema.AlternateTypeRules.newRule;

import java.time.LocalDate;
import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.async.DeferredResult;

import com.amway.api.rest.LosController;
import com.fasterxml.classmate.TypeResolver;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import springfox.documentation.annotations.ApiIgnore;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.WildcardType;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@ComponentScan(basePackageClasses = { LosController.class })
public class SwaggerConfig {

	@Component
	@Primary
	public class CustomObjectMapper extends ObjectMapper {

		private static final long serialVersionUID = -8608568247784774921L;

		public CustomObjectMapper() {
			setSerializationInclusion(JsonInclude.Include.NON_NULL);
			configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
			configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
			configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			enable(SerializationFeature.INDENT_OUTPUT);
		}
	}

	@Bean
	public Docket api() {
		TypeResolver typeResolver = new TypeResolver();
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.amway.api.rest")).paths(PathSelectors.any()).build()
				.apiInfo(apiInfo()).pathMapping("/").directModelSubstitute(LocalDate.class, String.class)
				.genericModelSubstitutes(ResponseEntity.class).ignoredParameterTypes(ApiIgnore.class)
				.alternateTypeRules(newRule(
						typeResolver.resolve(DeferredResult.class,
								typeResolver.resolve(ResponseEntity.class, WildcardType.class)),
						typeResolver.resolve(WildcardType.class)))
				.tags(new Tag("LOS Service", "All apis relating to LOS"));
	}

	private ApiInfo apiInfo() {
		return new ApiInfo("Magic Bonus/Volume details REST API", "Magic Bonus/Volume details REST API", "1.0",
				"Terms of service", ApiInfo.DEFAULT_CONTACT, "", "", Collections.emptyList());
	}
}