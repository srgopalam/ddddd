package com.amway.resolver;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import com.amway.domain.AffAbo;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.validators.InputParamValidator;
import com.google.common.base.Splitter;

/**
 * This component creates new {@link ModelLosDetailsRequest} objects.
 * 
 * @author Sreenivasa Gopalam
 */
public final class LosDetailsMethodArgumentResolver implements HandlerMethodArgumentResolver {

	private static final Logger LOGGER = LoggerFactory.getLogger(LosDetailsMethodArgumentResolver.class);
	private static final String DEFAULT_AFFABO_SEPERATOR = "-";
	private static final String REQUEST_PARAM_AFFABO = "affAbo[]";
	private static final String REQUEST_PARAM_PERIOD = "period[]";
	private static final String REQUEST_PARAM_BUSINESS_NATURE = "businessNature[]";
	private static final String REQUEST_PARAM_INCLUDE_VOL_TYPE = "volumeType[]";
	private static final String REQUEST_PARAM_INCLUDE_INACTIVE = "includeInactive";
	private static final String REQUEST_PARAM_INCLUDE_INTERNATIONAL = "includeInternational";
	private static final String REQUEST_PARAM_INCLUDE_GLOBAL_MB = "includeGlobalMB";
	private static final String REQUEST_PARAM_INCLUDE_MAP = "includeMap";
	private static final String REQUEST_PARAM_AS_LIST = "asList";
	private static final String REQUEST_PARAM_INCLUDE_FRONTLINE = "includeFrontline";
	private static final String REQUEST_PARAM_INCLUDE_ABO_ATTRIBUTES = "includeAboAttr";
	private static final String REQUEST_PARAM_INCLUDE_VOLUME_DETAILS = "includeVolumeDetails";
	private static final String REQUEST_PARAM_INCLUDE_AWARD_LEVELS = "includeAwardLevels";
	private static final String REQUEST_PARAM_INCLUDE_QUAL_COUNT = "includeQualCount";
	private static final String REQUEST_PARAM_INCLUDE_SPON_STATS = "includeSponStats";
	private static final String REQUEST_PARAM_INCLUDE_UPLINE = "includeUpline";
	private static final String REQUEST_PARAM_INCLUDE_YTD_PV = "includeYTDpvTotals";
	private static final String REQUEST_PARM_INCLUDE_HAS_DOWNLINE_FLAG = "includeHasDownlineFlag";
	private static final String X_MASHERY_HEADER_PARAM = "X-Mashery-Oauth-Scope";
	private static final String X_MASHERY_HEADER_AFF_PARAM = "salesPlanAff";
	private static final String X_MASHERY_HEADER_ABO_PARAM = "aboNum";

	private static final Set<AffAbo> DEFAULT_AFFABO = Collections.emptySet();
	private static final Set<Integer> DEFAULT_PERIOD = Collections.emptySet();
	private static final Set<String> DEFAULT_BUSINESS_NATURE = Collections.emptySet();
	private static final Set<String> DEFAULT_VOL_TYPE = Collections.emptySet();

	@Override
	public boolean supportsParameter(MethodParameter methodParameter) {
		return methodParameter.getParameterType().equals(ModelLosDetailsRequest.class);
	}

	@Override
	public Object resolveArgument(MethodParameter methodParameter, ModelAndViewContainer modelAndViewContainer,
			NativeWebRequest nativeWebRequest, WebDataBinderFactory webDataBinderFactory) throws Exception {
		LOGGER.debug("Creating a ServiceInputMapper object from the incoming request.");
		String affAboParam = nativeWebRequest.getParameter(REQUEST_PARAM_AFFABO);
		String periodParam = nativeWebRequest.getParameter(REQUEST_PARAM_PERIOD);
		String businessNatureParam = nativeWebRequest.getParameter(REQUEST_PARAM_BUSINESS_NATURE);
		String volumeTypeParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_VOL_TYPE);
		String includeInactiveParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_INACTIVE);
		String includeInternationalParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_INTERNATIONAL);
		String includeGlobalMBParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_GLOBAL_MB);
		String includeMapParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_MAP);
		String asListParam = nativeWebRequest.getParameter(REQUEST_PARAM_AS_LIST);
		String includeFrontlineParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_FRONTLINE);
		String includeAboAttrParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_ABO_ATTRIBUTES);
		String includeVolumeDetailsParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_VOLUME_DETAILS);
		String includeAwardLevelsParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_AWARD_LEVELS);
		String includeQualCountParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_QUAL_COUNT);
		String includeSponStatsParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_SPON_STATS);
		String includeUplineParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_UPLINE);
		String includeYTDpvParam = nativeWebRequest.getParameter(REQUEST_PARAM_INCLUDE_YTD_PV);
		String includeHasDownlineFlagParam = nativeWebRequest.getParameter(REQUEST_PARM_INCLUDE_HAS_DOWNLINE_FLAG);

		String requestorInfo = nativeWebRequest.getHeader(X_MASHERY_HEADER_PARAM);
		Set<AffAbo> affAbos = null;
		Set<Integer> periods = null;
		Set<String> businessNatures = null;
		Set<String> volumeTypes = null;

		boolean includeInactive = Boolean.parseBoolean(includeInactiveParam);
		boolean includeInternational = Boolean.parseBoolean(includeInternationalParam);
		boolean includeGlobalMB = Boolean.parseBoolean(includeGlobalMBParam);
		boolean includeMap = Boolean.parseBoolean(includeMapParam);
		boolean asList = Boolean.parseBoolean(asListParam);
		boolean includeFrontline = Boolean.parseBoolean(includeFrontlineParam);
		boolean includeAboAttr = Boolean.parseBoolean(includeAboAttrParam);
		boolean includeVolumeDetails = Boolean.parseBoolean(includeVolumeDetailsParam);
		boolean includeAwardLevels = Boolean.parseBoolean(includeAwardLevelsParam);
		boolean includeQualCount = Boolean.parseBoolean(includeQualCountParam);
		boolean includeSponStats = Boolean.parseBoolean(includeSponStatsParam);
		boolean includeUpline = Boolean.parseBoolean(includeUplineParam);
		boolean includeYTDpv = Boolean.parseBoolean(includeYTDpvParam);
		boolean includeHasDownlineFlag = Boolean.parseBoolean(includeHasDownlineFlagParam);
		int reqAff = 0;
		long reqAbo = 0;
		if (null != requestorInfo && requestorInfo.length() > 0) {
			Map<String, String> headerProps = Splitter.on(" ").withKeyValueSeparator("=").split(requestorInfo);
			if (null != headerProps) {
				reqAff = Integer.valueOf(headerProps.get(X_MASHERY_HEADER_AFF_PARAM));
				reqAbo = Long.valueOf(headerProps.get(X_MASHERY_HEADER_ABO_PARAM));
			}
		}
		affAbos = new HashSet<>();
		mapAffAbos(affAboParam, affAbos);
		volumeTypes = new HashSet<>();
		mapVolumeTypes(volumeTypeParam, volumeTypes);
		businessNatures = new HashSet<>();
		mapBusinessNatureCodes(businessNatureParam, businessNatures);
		Set<String> periodStr = StringUtils.commaDelimitedListToSet(periodParam);
		periods = InputParamValidator.removeInvalidPeriods(periodStr);

		if (isAffAboNotSet(affAbos)) {
			affAbos = DEFAULT_AFFABO;
		}

		if (isPeriodNotSet(periods)) {
			periods = DEFAULT_PERIOD;
		}
		if (isBusinessNatureNotSet(businessNatures)) {
			businessNatures = DEFAULT_BUSINESS_NATURE;
		}
		if (isVolumeTypesNotSet(volumeTypes)) {
			volumeTypes = DEFAULT_VOL_TYPE;
		}
		LOGGER.debug("Returning a new ServiceInputMapper object with affAbos: {}", affAbos);

		return new ModelLosDetailsRequest(reqAff, reqAbo, affAbos, periods, businessNatures, volumeTypes,
				includeInactive, includeInternational, includeGlobalMB, includeMap, asList, includeFrontline,
				includeAboAttr, includeVolumeDetails, includeAwardLevels, includeQualCount, includeSponStats,
				includeUpline, includeYTDpv, includeHasDownlineFlag);
	}

	private void mapAffAbos(String affAbos, Set<AffAbo> affAboParams) {
		AffAbo affAbo = null;
		Set<String> affAboSet = StringUtils.commaDelimitedListToSet(affAbos);
		for (String affAboStr : affAboSet) {
			if (InputParamValidator.isValidAffAbo(affAboStr)) {
				String[] uniqueTokens = StringUtils.tokenizeToStringArray(affAboStr, DEFAULT_AFFABO_SEPERATOR);
				if (null != uniqueTokens && 2 == uniqueTokens.length) {
					affAbo = new AffAbo();
					affAbo.setAff(Integer.valueOf(uniqueTokens[0]));
					affAbo.setAbo(Long.valueOf(uniqueTokens[1]));
					affAboParams.add(affAbo);
				}
			}
		}
	}

	private void mapVolumeTypes(String volumeTypeParam, Set<String> volumeTypes) {
		Set<String> volumeTypeCodeSet = StringUtils.commaDelimitedListToSet(volumeTypeParam);
		for (String volumeTypeCode : volumeTypeCodeSet) {
			volumeTypes.add(org.apache.commons.lang3.StringUtils.leftPad(volumeTypeCode, 3, "0"));
		}
	}

	private void mapBusinessNatureCodes(String businessNatureParam, Set<String> businessNatureCodes) {
		Set<String> businessNatureCodeSet = StringUtils.commaDelimitedListToSet(businessNatureParam);
		for (String businessNatureCode : businessNatureCodeSet) {
			businessNatureCodes.add(businessNatureCode.trim());
		}
	}

	private boolean isAffAboNotSet(Set<AffAbo> affAbos) {
		return CollectionUtils.isEmpty(affAbos);
	}

	private boolean isPeriodNotSet(Set<Integer> periods) {
		return CollectionUtils.isEmpty(periods);
	}

	private boolean isBusinessNatureNotSet(Set<String> businessNatures) {
		return CollectionUtils.isEmpty(businessNatures);
	}

	private boolean isVolumeTypesNotSet(Set<String> volumeTypes) {
		return CollectionUtils.isEmpty(volumeTypes);
	}

}
