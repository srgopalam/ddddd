package com.amway.model;

public class CountryMasterData {
	private String isoCountryCode;
	private String defaultIsoLanguageCode;

	public String getIsoCountryCode() {
		return isoCountryCode;
	}

	public void setIsoCountryCode(String isoCountryCode) {
		this.isoCountryCode = isoCountryCode;
	}

	public String getDefaultIsoLanguageCode() {
		return defaultIsoLanguageCode;
	}

	public void setDefaultIsoLanguageCode(String defaultIsoLanguageCode) {
		this.defaultIsoLanguageCode = defaultIsoLanguageCode;
	}

}