package com.amway.model;

import java.util.Objects;

public class BasicServiceOutputData implements Comparable<BasicServiceOutputData> {

	private long bonusCustomer;
	private long sponsorCustomerId;
	private int aff;
	private long abo;
	private String businessStatusCode;
	private String aboName;
	private int sponsorAff;
	private long sponsorAbo;
	private int businessEntity;
	private String aboClass;
	private String businessNature;
	private String country;
	private int losLevelNo;
	private String losTypeCode;
	private String segmentCode;

	public BasicServiceOutputData() {
		super();
	}

	public String getSegmentCode() {
		return segmentCode;
	}

	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	public long getBonusCustomer() {
		return bonusCustomer;
	}

	public void setBonusCustomer(long bonusCustomer) {
		this.bonusCustomer = bonusCustomer;
	}

	public int getAff() {
		return aff;
	}

	public void setAff(int aff) {
		this.aff = aff;
	}

	public long getAbo() {
		return abo;
	}

	public void setAbo(long abo) {
		this.abo = abo;
	}

	public String getBusinessStatusCode() {
		return businessStatusCode;
	}

	public void setBusinessStatusCode(String businessStatusCode) {
		this.businessStatusCode = businessStatusCode;
	}

	public String getAboName() {
		return aboName;
	}

	public void setAboName(String aboName) {
		this.aboName = aboName;
	}

	public int getSponsorAff() {
		return sponsorAff;
	}

	public void setSponsorAff(int sponsorAff) {
		this.sponsorAff = sponsorAff;
	}

	public long getSponsorAbo() {
		return sponsorAbo;
	}

	public void setSponsorAbo(long sponsorAbo) {
		this.sponsorAbo = sponsorAbo;
	}

	public int getBusinessEntity() {
		return businessEntity;
	}

	public void setBusinessEntity(int businessEntity) {
		this.businessEntity = businessEntity;
	}

	public String getAboClass() {
		return aboClass;
	}

	public void setAboClass(String aboClass) {
		this.aboClass = aboClass;
	}

	public String getBusinessNature() {
		return businessNature;
	}

	public void setBusinessNature(String businessNature) {
		this.businessNature = businessNature;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getLosLevelNo() {
		return losLevelNo;
	}

	public void setLosLevelNo(int losLevelNo) {
		this.losLevelNo = losLevelNo;
	}

	public String getLosTypeCode() {
		return losTypeCode;
	}

	public void setLosTypeCode(String losTypeCode) {
		this.losTypeCode = losTypeCode;
	}

	public long getSponsorCustomerId() {
		return sponsorCustomerId;
	}

	public void setSponsorCustomerId(long sponsorCustomerId) {
		this.sponsorCustomerId = sponsorCustomerId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BasicServiceOutputData [bonusCustomer=").append(bonusCustomer).append(", sponsorCustomerId=")
				.append(sponsorCustomerId).append(", aff=").append(aff).append(", abo=").append(abo)
				.append(", businessStatusCode=").append(businessStatusCode).append(", aboName=").append(aboName)
				.append(", sponsorAff=").append(sponsorAff).append(", sponsorAbo=").append(sponsorAbo)
				.append(", businessEntity=").append(businessEntity).append(", aboClass=").append(aboClass)
				.append(", businessNature=").append(businessNature).append(", country=").append(country)
				.append(", losLevelNo=").append(losLevelNo).append(", losTypeCode=").append(losTypeCode).append("]");
		return builder.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return Objects.hash(abo, aboClass, aboName, aff, bonusCustomer, businessEntity, businessNature,
				businessStatusCode, country, losLevelNo, losTypeCode, segmentCode, sponsorAbo, sponsorAff,
				sponsorCustomerId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof BasicServiceOutputData)) {
			return false;
		}
		BasicServiceOutputData other = (BasicServiceOutputData) obj;
		return abo == other.abo && Objects.equals(aboClass, other.aboClass) && Objects.equals(aboName, other.aboName)
				&& aff == other.aff && bonusCustomer == other.bonusCustomer && businessEntity == other.businessEntity
				&& Objects.equals(businessNature, other.businessNature)
				&& Objects.equals(businessStatusCode, other.businessStatusCode)
				&& Objects.equals(country, other.country) && losLevelNo == other.losLevelNo
				&& Objects.equals(losTypeCode, other.losTypeCode) && Objects.equals(segmentCode, other.segmentCode)
				&& sponsorAbo == other.sponsorAbo && sponsorAff == other.sponsorAff
				&& sponsorCustomerId == other.sponsorCustomerId;
	}

	@Override
	public int compareTo(BasicServiceOutputData o) {
		if (this.getAff() < o.getAff()) {
			return -1;
		}
		if (this.getAff() > o.getAff()) {
			return 1;
		}
		return 0;
	}

}
