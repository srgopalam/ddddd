package com.amway.model;

import java.math.BigDecimal;

public class PVBVDetailData {
	private long bonusCustomerId;
	private int bonusPeriod;
	private int businessEntity;
	private String volumeTypeCode;
	private BigDecimal pvQuantity;
	private BigDecimal ytdPvQuantity;
	private BigDecimal bvQuantity;

	public PVBVDetailData() {
		super();
	}

	public long getBonusCustomerId() {
		return bonusCustomerId;
	}

	public void setBonusCustomerId(long bonusCustomerId) {
		this.bonusCustomerId = bonusCustomerId;
	}

	public int getBonusPeriod() {
		return bonusPeriod;
	}

	public void setBonusPeriod(int bonusPeriod) {
		this.bonusPeriod = bonusPeriod;
	}

	public int getBusinessEntity() {
		return businessEntity;
	}

	public void setBusinessEntity(int businessEntity) {
		this.businessEntity = businessEntity;
	}

	public String getVolumeTypeCode() {
		return volumeTypeCode;
	}

	public void setVolumeTypeCode(String volumeTypeCode) {
		this.volumeTypeCode = volumeTypeCode;
	}

	public BigDecimal getPvQuantity() {
		return pvQuantity;
	}

	public void setPvQuantity(BigDecimal pvQuantity) {
		this.pvQuantity = pvQuantity;
	}

	public BigDecimal getBvQuantity() {
		return bvQuantity;
	}

	public void setBvQuantity(BigDecimal bvQuantity) {
		this.bvQuantity = bvQuantity;
	}

	public BigDecimal getYtdPvQuantity() {
		return ytdPvQuantity;
	}

	public void setYtdPvQuantity(BigDecimal ytdPvQuantity) {
		this.ytdPvQuantity = ytdPvQuantity;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PVBVDetailData [bonusCustomerId=").append(bonusCustomerId).append(", bonusPeriod=")
				.append(bonusPeriod).append(", businessEntity=").append(businessEntity).append(", volumeTypeCode=")
				.append(volumeTypeCode).append(", pvQuantity=").append(pvQuantity).append(", ytdPvQuantity=")
				.append(ytdPvQuantity).append(", bvQuantity=").append(bvQuantity).append("]");
		return builder.toString();
	}

}
