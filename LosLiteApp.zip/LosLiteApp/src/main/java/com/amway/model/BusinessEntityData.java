package com.amway.model;

import java.math.BigDecimal;

public class BusinessEntityData {
	private String name;
	private String description;
	private int businessEntity;
	private int effectivePeriod;
	private String isoCurrency;
	private String isoCountry;
	private String company;
	private boolean businessAllowed;
	private BigDecimal pvBvRatio;
	private BigDecimal minimumStatementAmount;
	private BigDecimal redoClassARLimitAmount;
	private boolean topupAllowed;
	private boolean excludePVFromAwardVolume;
	private boolean excludePVFromRubyVolume;
	private BigDecimal escrowPaymentLimit;
	private boolean trackFirstTimePercentAwards;
	private boolean trackMemberSilverAwards;
	private boolean netNegativeIncludedInGroup;
	private int affiliateNumber;
	private char autoClassCode;
	private char paymentClassCode;
	private boolean memberClientVolumeAllowed;
	private String salesPlanCode;
	private boolean detailByVat;
	private int payPrecisionNo;
	private String payRoundMethodCode;
	private int topUpTotalCount;
	private BigDecimal topUpTotalVolume;

	public BusinessEntityData() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getBusinessEntity() {
		return businessEntity;
	}

	public void setBusinessEntity(int businessEntity) {
		this.businessEntity = businessEntity;
	}

	public int getEffectivePeriod() {
		return effectivePeriod;
	}

	public void setEffectivePeriod(int effectivePeriod) {
		this.effectivePeriod = effectivePeriod;
	}

	public String getIsoCurrency() {
		return isoCurrency;
	}

	public void setIsoCurrency(String isoCurrency) {
		this.isoCurrency = isoCurrency;
	}

	public String getIsoCountry() {
		return isoCountry;
	}

	public void setIsoCountry(String isoCountry) {
		this.isoCountry = isoCountry;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public boolean isBusinessAllowed() {
		return businessAllowed;
	}

	public void setBusinessAllowed(boolean businessAllowed) {
		this.businessAllowed = businessAllowed;
	}

	public BigDecimal getPvBvRatio() {
		return pvBvRatio;
	}

	public void setPvBvRatio(BigDecimal pvBvRatio) {
		this.pvBvRatio = pvBvRatio;
	}

	public BigDecimal getMinimumStatementAmount() {
		return minimumStatementAmount;
	}

	public void setMinimumStatementAmount(BigDecimal minimumStatementAmount) {
		this.minimumStatementAmount = minimumStatementAmount;
	}

	public BigDecimal getRedoClassARLimitAmount() {
		return redoClassARLimitAmount;
	}

	public void setRedoClassARLimitAmount(BigDecimal redoClassARLimitAmount) {
		this.redoClassARLimitAmount = redoClassARLimitAmount;
	}

	public boolean isTopupAllowed() {
		return topupAllowed;
	}

	public void setTopupAllowed(boolean topupAllowed) {
		this.topupAllowed = topupAllowed;
	}

	public boolean isExcludePVFromAwardVolume() {
		return excludePVFromAwardVolume;
	}

	public void setExcludePVFromAwardVolume(boolean excludePVFromAwardVolume) {
		this.excludePVFromAwardVolume = excludePVFromAwardVolume;
	}

	public boolean isExcludePVFromRubyVolume() {
		return excludePVFromRubyVolume;
	}

	public void setExcludePVFromRubyVolume(boolean excludePVFromRubyVolume) {
		this.excludePVFromRubyVolume = excludePVFromRubyVolume;
	}

	public BigDecimal getEscrowPaymentLimit() {
		return escrowPaymentLimit;
	}

	public void setEscrowPaymentLimit(BigDecimal escrowPaymentLimit) {
		this.escrowPaymentLimit = escrowPaymentLimit;
	}

	public boolean isTrackFirstTimePercentAwards() {
		return trackFirstTimePercentAwards;
	}

	public void setTrackFirstTimePercentAwards(boolean trackFirstTimePercentAwards) {
		this.trackFirstTimePercentAwards = trackFirstTimePercentAwards;
	}

	public boolean isTrackMemberSilverAwards() {
		return trackMemberSilverAwards;
	}

	public void setTrackMemberSilverAwards(boolean trackMemberSilverAwards) {
		this.trackMemberSilverAwards = trackMemberSilverAwards;
	}

	public boolean isNetNegativeIncludedInGroup() {
		return netNegativeIncludedInGroup;
	}

	public void setNetNegativeIncludedInGroup(boolean netNegativeIncludedInGroup) {
		this.netNegativeIncludedInGroup = netNegativeIncludedInGroup;
	}

	public int getAffiliateNumber() {
		return affiliateNumber;
	}

	public void setAffiliateNumber(int affiliateNumber) {
		this.affiliateNumber = affiliateNumber;
	}

	public char getAutoClassCode() {
		return autoClassCode;
	}

	public void setAutoClassCode(char autoClassCode) {
		this.autoClassCode = autoClassCode;
	}

	public char getPaymentClassCode() {
		return paymentClassCode;
	}

	public void setPaymentClassCode(char paymentClassCode) {
		this.paymentClassCode = paymentClassCode;
	}

	public boolean isMemberClientVolumeAllowed() {
		return memberClientVolumeAllowed;
	}

	public void setMemberClientVolumeAllowed(boolean memberClientVolumeAllowed) {
		this.memberClientVolumeAllowed = memberClientVolumeAllowed;
	}

	public String getSalesPlanCode() {
		return salesPlanCode;
	}

	public void setSalesPlanCode(String salesPlanCode) {
		this.salesPlanCode = salesPlanCode;
	}

	public boolean isDetailByVat() {
		return detailByVat;
	}

	public void setDetailByVat(boolean detailByVat) {
		this.detailByVat = detailByVat;
	}

	public int getPayPrecisionNo() {
		return payPrecisionNo;
	}

	public void setPayPrecisionNo(int payPrecisionNo) {
		this.payPrecisionNo = payPrecisionNo;
	}

	public String getPayRoundMethodCode() {
		return payRoundMethodCode;
	}

	public void setPayRoundMethodCode(String payRoundMethodCode) {
		this.payRoundMethodCode = payRoundMethodCode;
	}

	public int getTopUpTotalCount() {
		return topUpTotalCount;
	}

	public void setTopUpTotalCount(int topUpTotalCount) {
		this.topUpTotalCount = topUpTotalCount;
	}

	public BigDecimal getTopUpTotalVolume() {
		return topUpTotalVolume;
	}

	public void setTopUpTotalVolume(BigDecimal topUpTotalVolume) {
		this.topUpTotalVolume = topUpTotalVolume;
	}

}
