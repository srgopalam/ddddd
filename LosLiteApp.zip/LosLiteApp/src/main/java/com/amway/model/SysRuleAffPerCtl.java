package com.amway.model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Objects;

public class SysRuleAffPerCtl {

	private int ruleId;
	private int effBnsPerNo;
	private int xprBnsPerNo;
	private String userDefinedTxt;
	private Timestamp userDefinedTime;
	private BigDecimal userDefinedQty;
	private int userDefinedPerNo;
	private boolean userDefinedFlag;
	private String createdBy;
	private Timestamp createdTime;
	private String changedBy;
	private Timestamp changedTime;
	private String moduleName;
	private int affNo;
	private String affName;
	private int busEntityNo;
	private String busEntityName;
	private int noteNo;
	private String noteTxt;

	public SysRuleAffPerCtl() {
		super();
	}

	/**
	 * @return Returns the noteNo.
	 */
	public int getNoteNo() {
		return noteNo;
	}

	/**
	 * @param noteNo The noteNo to set.
	 */
	public void setNoteNo(int noteNo) {
		this.noteNo = noteNo;
	}

	/**
	 * @return Returns the noteTxt.
	 */
	public String getNoteTxt() {
		return noteTxt;
	}

	/**
	 * @param noteTxt The noteTxt to set.
	 */
	public void setNoteTxt(String noteTxt) {
		this.noteTxt = noteTxt;
	}

	/**
	 * @return Returns the changedBy.
	 */
	public String getChangedBy() {
		return changedBy;
	}

	/**
	 * @param changedBy The changedBy to set.
	 */
	public void setChangedBy(String changedBy) {
		this.changedBy = changedBy;
	}

	/**
	 * @return Returns the createdBy.
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy The createdBy to set.
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return Returns the effBnsPerNo.
	 */
	public int getEffBnsPerNo() {
		return effBnsPerNo;
	}

	/**
	 * @param effBnsPerNo The effBnsPerNo to set.
	 */
	public void setEffBnsPerNo(int effBnsPerNo) {
		this.effBnsPerNo = effBnsPerNo;
	}

	/**
	 * @return Returns the moduleName.
	 */
	public String getModuleName() {
		return moduleName;
	}

	/**
	 * @param moduleName The moduleName to set.
	 */
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	/**
	 * @return Returns the ruleId.
	 */
	public int getRuleId() {
		return ruleId;
	}

	/**
	 * @param ruleId The ruleId to set.
	 */
	public void setRuleId(int ruleId) {
		this.ruleId = ruleId;
	}

	/**
	 * @return Returns the userDefinedFlag.
	 */
	public boolean getUserDefinedFlag() {
		return userDefinedFlag;
	}

	/**
	 * @return Returns the userDefinedPerNo.
	 */
	public int getUserDefinedPerNo() {
		return userDefinedPerNo;
	}

	/**
	 * @param userDefinedPerNo The userDefinedPerNo to set.
	 */
	public void setUserDefinedPerNo(int userDefinedPerNo) {
		this.userDefinedPerNo = userDefinedPerNo;
	}

	/**
	 * @return Returns the userDefinedQty.
	 */
	public BigDecimal getUserDefinedQty() {
		return userDefinedQty;
	}

	/**
	 * @return Returns the userDefinedTime.
	 */
	public Timestamp getUserDefinedTime() {
		return userDefinedTime;
	}

	/**
	 * @return Returns the userDefinedTxt.
	 */
	public String getUserDefinedTxt() {
		return userDefinedTxt;
	}

	/**
	 * @param userDefinedTxt The userDefinedTxt to set.
	 */
	public void setUserDefinedTxt(String userDefinedTxt) {
		this.userDefinedTxt = userDefinedTxt;
	}

	/**
	 * @return Returns the xprBnsPerNo.
	 */
	public int getXprBnsPerNo() {
		return xprBnsPerNo;
	}

	/**
	 * @param xprBnsPerNo The xprBnsPerNo to set.
	 */
	public void setXprBnsPerNo(int xprBnsPerNo) {
		this.xprBnsPerNo = xprBnsPerNo;
	}

	/**
	 * @return Returns the changedTime.
	 */
	public Timestamp getChangedTime() {
		return changedTime;
	}

	/**
	 * @param changedTime The changedTime to set.
	 */
	public void setChangedTime(Timestamp changedTime) {
		this.changedTime = changedTime;
	}

	/**
	 * @return Returns the createdTime.
	 */
	public Timestamp getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime The createdTime to set.
	 */
	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @param userDefinedFlag The userDefinedFlag to set.
	 */
	public void setUserDefinedFlag(boolean userDefinedFlag) {
		this.userDefinedFlag = userDefinedFlag;
	}

	/**
	 * @param userDefinedQty The userDefinedQty to set.
	 */
	public void setUserDefinedQty(BigDecimal userDefinedQty) {
		this.userDefinedQty = userDefinedQty;
	}

	/**
	 * @param userDefinedTime The userDefinedTime to set.
	 */
	public void setUserDefinedTime(Timestamp userDefinedTime) {
		this.userDefinedTime = userDefinedTime;
	}

	/**
	 * @return Returns the affNo.
	 */
	public int getAffNo() {
		return affNo;
	}

	/**
	 * @param affNo The affNo to set.
	 */
	public void setAffNo(int affNo) {
		this.affNo = affNo;
	}

	/**
	 * @return Returns the affNm.
	 */
	public String getAffName() {
		return affName;
	}

	/**
	 * @param affNm The affNm to set.
	 */
	public void setAffName(String affName) {
		this.affName = affName;
	}

	/**
	 * @return Returns the busEntityName.
	 */
	public String getBusEntityName() {
		return busEntityName;
	}

	/**
	 * @param busEntityName The busEntityName to set.
	 */
	public void setBusEntityName(String busEntityName) {
		this.busEntityName = busEntityName;
	}

	/**
	 * @return Returns the busEntityNo.
	 */
	public int getBusEntityNo() {
		return busEntityNo;
	}

	/**
	 * @param busEntityNo The busEntityNo to set.
	 */
	public void setBusEntityNo(int busEntityNo) {
		this.busEntityNo = busEntityNo;
	}

	@Override
	public String toString() {
		return "SysRuleAffPerCtlData [ruleId=" + ruleId + ", effBnsPerNo=" + effBnsPerNo + ", xprBnsPerNo="
				+ xprBnsPerNo + ", userDefinedTxt=" + userDefinedTxt + ", userDefinedTime=" + userDefinedTime
				+ ", userDefinedQty=" + userDefinedQty + ", userDefinedPerNo=" + userDefinedPerNo + ", userDefinedFlag="
				+ userDefinedFlag + ", createdBy=" + createdBy + ", createdTime=" + createdTime + ", changedBy="
				+ changedBy + ", changedTime=" + changedTime + ", moduleName=" + moduleName + ", affNo=" + affNo
				+ ", affName=" + affName + ", busEntityNo=" + busEntityNo + ", busEntityName=" + busEntityName
				+ ", noteNo=" + noteNo + ", noteTxt=" + noteTxt + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(affName, affNo, busEntityName, busEntityNo, changedBy, changedTime, createdBy, createdTime,
				effBnsPerNo, moduleName, noteNo, noteTxt, ruleId, userDefinedFlag, userDefinedPerNo, userDefinedQty,
				userDefinedTime, userDefinedTxt, xprBnsPerNo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SysRuleAffPerCtl)) {
			return false;
		}
		SysRuleAffPerCtl other = (SysRuleAffPerCtl) obj;
		return Objects.equals(affName, other.affName) && affNo == other.affNo
				&& Objects.equals(busEntityName, other.busEntityName) && busEntityNo == other.busEntityNo
				&& Objects.equals(changedBy, other.changedBy) && Objects.equals(changedTime, other.changedTime)
				&& Objects.equals(createdBy, other.createdBy) && Objects.equals(createdTime, other.createdTime)
				&& effBnsPerNo == other.effBnsPerNo && Objects.equals(moduleName, other.moduleName)
				&& noteNo == other.noteNo && Objects.equals(noteTxt, other.noteTxt) && ruleId == other.ruleId
				&& userDefinedFlag == other.userDefinedFlag && userDefinedPerNo == other.userDefinedPerNo
				&& Objects.equals(userDefinedQty, other.userDefinedQty)
				&& Objects.equals(userDefinedTime, other.userDefinedTime)
				&& Objects.equals(userDefinedTxt, other.userDefinedTxt) && xprBnsPerNo == other.xprBnsPerNo;
	}
}
