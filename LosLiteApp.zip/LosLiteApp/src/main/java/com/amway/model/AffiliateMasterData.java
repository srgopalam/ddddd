package com.amway.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class AffiliateMasterData implements Serializable {
	private static final long serialVersionUID = 8204585021780240943L;
	private int aff;
	private String affDesc;
	private String affName;
	private int amwayAliasCustId;
	private Date affOperBegDate;
	private int currentBonusPeriod;
	private boolean globalAffFlag;
	private boolean multiCurrencyFlag;
	private boolean multiBusinessEntityFlag;
	private String defaultIsoCountryCode;
	private String defaultCountryCode;
	private String defaultIsoCurrencyCode;
	private boolean affMultiPerFlag;
	private boolean nationalFundFlag;
	private boolean seperateFundFlag;
	private boolean pvMarketFlag;
	private String regionCode;
	private int affSequenceFlag;
	private boolean mrgFlag;
	private int batchRepeatAgeDays;
	private int mbrCalcType;
	private String fundClacMethodCode;
	private int backfilAwardFlag;
	private int currentFiscalYear;
	private boolean arNetInvTmFlag;
	private boolean needRcvInvFlag;
	private int openInvAllowQuantity;
	private BigDecimal escrwPayLimitQuantity;
	private BigDecimal escrwPayMinQuantity;
	private String affTzText;
	private String alternatePersVolTypeCode;

	public AffiliateMasterData() {
		super();
	}

	public int getAff() {
		return aff;
	}

	public void setAff(int aff) {
		this.aff = aff;
	}

	public String getAffDesc() {
		return affDesc;
	}

	public void setAffDesc(String affDesc) {
		this.affDesc = affDesc;
	}

	public String getAffName() {
		return affName;
	}

	public void setAffName(String affName) {
		this.affName = affName;
	}

	public int getAmwayAliasCustId() {
		return amwayAliasCustId;
	}

	public void setAmwayAliasCustId(int amwayAliasCustId) {
		this.amwayAliasCustId = amwayAliasCustId;
	}

	public Date getAffOperBegDate() {
		return affOperBegDate;
	}

	public void setAffOperBegDate(Date affOperBegDate) {
		this.affOperBegDate = affOperBegDate;
	}

	public int getCurrentBonusPeriod() {
		return currentBonusPeriod;
	}

	public void setCurrentBonusPeriod(int currentBonusPeriod) {
		this.currentBonusPeriod = currentBonusPeriod;
	}

	public boolean isGlobalAffFlag() {
		return globalAffFlag;
	}

	public void setGlobalAffFlag(boolean globalAffFlag) {
		this.globalAffFlag = globalAffFlag;
	}

	public boolean isMultiCurrencyFlag() {
		return multiCurrencyFlag;
	}

	public void setMultiCurrencyFlag(boolean multiCurrencyFlag) {
		this.multiCurrencyFlag = multiCurrencyFlag;
	}

	public boolean isMultiBusinessEntityFlag() {
		return multiBusinessEntityFlag;
	}

	public void setMultiBusinessEntityFlag(boolean multiBusinessEntityFlag) {
		this.multiBusinessEntityFlag = multiBusinessEntityFlag;
	}

	public String getDefaultIsoCountryCode() {
		return defaultIsoCountryCode;
	}

	public void setDefaultIsoCountryCode(String defaultIsoCountryCode) {
		this.defaultIsoCountryCode = defaultIsoCountryCode;
	}

	public String getDefaultCountryCode() {
		return defaultCountryCode;
	}

	public void setDefaultCountryCode(String defaultCountryCode) {
		this.defaultCountryCode = defaultCountryCode;
	}

	public String getDefaultIsoCurrencyCode() {
		return defaultIsoCurrencyCode;
	}

	public void setDefaultIsoCurrencyCode(String defaultIsoCurrencyCode) {
		this.defaultIsoCurrencyCode = defaultIsoCurrencyCode;
	}

	public boolean isAffMultiPerFlag() {
		return affMultiPerFlag;
	}

	public void setAffMultiPerFlag(boolean affMultiPerFlag) {
		this.affMultiPerFlag = affMultiPerFlag;
	}

	public boolean isNationalFundFlag() {
		return nationalFundFlag;
	}

	public void setNationalFundFlag(boolean nationalFundFlag) {
		this.nationalFundFlag = nationalFundFlag;
	}

	public boolean isSeperateFundFlag() {
		return seperateFundFlag;
	}

	public void setSeperateFundFlag(boolean seperateFundFlag) {
		this.seperateFundFlag = seperateFundFlag;
	}

	public boolean isPvMarketFlag() {
		return pvMarketFlag;
	}

	public void setPvMarketFlag(boolean pvMarketFlag) {
		this.pvMarketFlag = pvMarketFlag;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public int getAffSequenceFlag() {
		return affSequenceFlag;
	}

	public void setAffSequenceFlag(int affSequenceFlag) {
		this.affSequenceFlag = affSequenceFlag;
	}

	public boolean isMrgFlag() {
		return mrgFlag;
	}

	public void setMrgFlag(boolean mrgFlag) {
		this.mrgFlag = mrgFlag;
	}

	public int getBatchRepeatAgeDays() {
		return batchRepeatAgeDays;
	}

	public void setBatchRepeatAgeDays(int batchRepeatAgeDays) {
		this.batchRepeatAgeDays = batchRepeatAgeDays;
	}

	public int getMbrCalcType() {
		return mbrCalcType;
	}

	public void setMbrCalcType(int mbrCalcType) {
		this.mbrCalcType = mbrCalcType;
	}

	public String getFundClacMethodCode() {
		return fundClacMethodCode;
	}

	public void setFundClacMethodCode(String fundClacMethodCode) {
		this.fundClacMethodCode = fundClacMethodCode;
	}

	public int getBackfilAwardFlag() {
		return backfilAwardFlag;
	}

	public void setBackfilAwardFlag(int backfilAwardFlag) {
		this.backfilAwardFlag = backfilAwardFlag;
	}

	public int getCurrentFiscalYear() {
		return currentFiscalYear;
	}

	public void setCurrentFiscalYear(int currentFiscalYear) {
		this.currentFiscalYear = currentFiscalYear;
	}

	public boolean isArNetInvTmFlag() {
		return arNetInvTmFlag;
	}

	public void setArNetInvTmFlag(boolean arNetInvTmFlag) {
		this.arNetInvTmFlag = arNetInvTmFlag;
	}

	public boolean isNeedRcvInvFlag() {
		return needRcvInvFlag;
	}

	public void setNeedRcvInvFlag(boolean needRcvInvFlag) {
		this.needRcvInvFlag = needRcvInvFlag;
	}

	public int getOpenInvAllowQuantity() {
		return openInvAllowQuantity;
	}

	public void setOpenInvAllowQuantity(int openInvAllowQuantity) {
		this.openInvAllowQuantity = openInvAllowQuantity;
	}

	public BigDecimal getEscrwPayLimitQuantity() {
		return escrwPayLimitQuantity;
	}

	public void setEscrwPayLimitQuantity(BigDecimal escrwPayLimitQuantity) {
		this.escrwPayLimitQuantity = escrwPayLimitQuantity;
	}

	public BigDecimal getEscrwPayMinQuantity() {
		return escrwPayMinQuantity;
	}

	public void setEscrwPayMinQuantity(BigDecimal escrwPayMinQuantity) {
		this.escrwPayMinQuantity = escrwPayMinQuantity;
	}

	public String getAffTzText() {
		return affTzText;
	}

	public void setAffTzText(String affTzText) {
		this.affTzText = affTzText;
	}

	public String getAlternatePersVolTypeCode() {
		return alternatePersVolTypeCode;
	}

	public void setAlternatePersVolTypeCode(String alternatePersVolTypeCode) {
		this.alternatePersVolTypeCode = alternatePersVolTypeCode;
	}

	@Override
	public String toString() {
		return "AffiliateMasterData [aff=" + aff + ", affDesc=" + affDesc + ", affName=" + affName
				+ ", amwayAliasCustId=" + amwayAliasCustId + ", affOperBegDate=" + affOperBegDate
				+ ", currentBonusPeriod=" + currentBonusPeriod + ", globalAffFlag=" + globalAffFlag
				+ ", multiCurrencyFlag=" + multiCurrencyFlag + ", multiBusinessEntityFlag=" + multiBusinessEntityFlag
				+ ", defaultIsoCountryCode=" + defaultIsoCountryCode + ", defaultCountryCode=" + defaultCountryCode
				+ ", defaultIsoCurrencyCode=" + defaultIsoCurrencyCode + ", affMultiPerFlag=" + affMultiPerFlag
				+ ", nationalFundFlag=" + nationalFundFlag + ", seperateFundFlag=" + seperateFundFlag
				+ ", pvMarketFlag=" + pvMarketFlag + ", regionCode=" + regionCode + ", affSequenceFlag="
				+ affSequenceFlag + ", mrgFlag=" + mrgFlag + ", batchRepeatAgeDays=" + batchRepeatAgeDays
				+ ", mbrCalcType=" + mbrCalcType + ", fundClacMethodCode=" + fundClacMethodCode + ", backfilAwardFlag="
				+ backfilAwardFlag + ", currentFiscalYear=" + currentFiscalYear + ", arNetInvTmFlag=" + arNetInvTmFlag
				+ ", needRcvInvFlag=" + needRcvInvFlag + ", openInvAllowQuantity=" + openInvAllowQuantity
				+ ", escrwPayLimitQuantity=" + escrwPayLimitQuantity + ", escrwPayMinQuantity=" + escrwPayMinQuantity
				+ ", affTzText=" + affTzText + ", alternatePersVolTypeCode=" + alternatePersVolTypeCode + "]";
	}

}
