package com.amway.model;

public class CustomerPercentage {
	private long bonusCustomerId;
	private int bonusPercent;

	public CustomerPercentage() {
		super();
	}

	public CustomerPercentage(long bonusCustomerId, int bonusPercent) {
		super();
		this.bonusCustomerId = bonusCustomerId;
		this.bonusPercent = bonusPercent;
	}

	public long getBonusCustomerId() {
		return bonusCustomerId;
	}

	public void setBonusCustomerId(long bonusCustomerId) {
		this.bonusCustomerId = bonusCustomerId;
	}

	public int getBonusPercent() {
		return bonusPercent;
	}

	public void setBonusPercent(int bonusPercent) {
		this.bonusPercent = bonusPercent;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerPercentage [bonusCustomerId=").append(bonusCustomerId).append(", bonusPercent=")
				.append(bonusPercent).append("]");
		return builder.toString();
	}

}
