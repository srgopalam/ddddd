package com.amway.model;

import java.io.Serializable;

public class BonusAwardMaster implements Serializable {
	private static final long serialVersionUID = -5722704598268736295L;
	private int bonusAwardNo;
	private String bonusAwardName;
	private String bonusAwardDesc;
	private String bonusAwardGroupCode;
	private String wwAliasText;
	private String procCode;
	private String topupCode;

	public BonusAwardMaster() {
		super();
	}

	public int getBonusAwardNo() {
		return bonusAwardNo;
	}

	public void setBonusAwardNo(int bonusAwardNo) {
		this.bonusAwardNo = bonusAwardNo;
	}

	public String getBonusAwardName() {
		return bonusAwardName;
	}

	public void setBonusAwardName(String bonusAwardName) {
		this.bonusAwardName = bonusAwardName;
	}

	public String getBonusAwardDesc() {
		return bonusAwardDesc;
	}

	public void setBonusAwardDesc(String bonusAwardDesc) {
		this.bonusAwardDesc = bonusAwardDesc;
	}

	public String getBonusAwardGroupCode() {
		return bonusAwardGroupCode;
	}

	public void setBonusAwardGroupCode(String bonusAwardGroupCode) {
		this.bonusAwardGroupCode = bonusAwardGroupCode;
	}

	public String getWwAliasText() {
		return wwAliasText;
	}

	public void setWwAliasText(String wwAliasText) {
		this.wwAliasText = wwAliasText;
	}

	public String getProcCode() {
		return procCode;
	}

	public void setProcCode(String procCode) {
		this.procCode = procCode;
	}

	public String getTopupCode() {
		return topupCode;
	}

	public void setTopupCode(String topupCode) {
		this.topupCode = topupCode;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BonusAwardMaster [bonusAwardNo=").append(bonusAwardNo).append(", bonusAwardName=")
				.append(bonusAwardName).append(", bonusAwardDesc=").append(bonusAwardDesc)
				.append(", bonusAwardGroupCode=").append(bonusAwardGroupCode).append(", wwAliasText=")
				.append(wwAliasText).append(", procCode=").append(procCode).append(", topupCode=").append(topupCode)
				.append("]");
		return builder.toString();
	}

}
