package com.amway.model;

public class BonusCustomerMaster {
	private int aff;
	private long abo;
	private long bonusCustomerId;
	private int businessEntity;
	private String defaultIsoCountryCode;

	public BonusCustomerMaster() {
		super();
	}

	public int getAff() {
		return aff;
	}

	public void setAff(int aff) {
		this.aff = aff;
	}

	public long getAbo() {
		return abo;
	}

	public void setAbo(long abo) {
		this.abo = abo;
	}

	public long getBonusCustomerId() {
		return bonusCustomerId;
	}

	public void setBonusCustomerId(long bonusCustomerId) {
		this.bonusCustomerId = bonusCustomerId;
	}

	public int getBusinessEntity() {
		return businessEntity;
	}

	public void setBusinessEntity(int businessEntity) {
		this.businessEntity = businessEntity;
	}

	public String getDefaultIsoCountryCode() {
		return defaultIsoCountryCode;
	}

	public void setDefaultIsoCountryCode(String defaultIsoCountryCode) {
		this.defaultIsoCountryCode = defaultIsoCountryCode;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BusinessCustomerMaster [aff=").append(aff).append(", abo=").append(abo)
				.append(", bonusCustomerId=").append(bonusCustomerId).append(", businessEntity=").append(businessEntity)
				.append(", defaultIsoCountryCode=").append(defaultIsoCountryCode).append("]");
		return builder.toString();
	}

}
