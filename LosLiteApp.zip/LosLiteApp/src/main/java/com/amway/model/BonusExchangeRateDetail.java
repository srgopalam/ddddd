package com.amway.model;

import java.math.BigDecimal;
import java.util.Date;

public class BonusExchangeRateDetail {
	private int aff;
	private String exchangeRateTypeCode;
	private String fromIsoCurrencyCode;
	private String toIsoCurrencyCode;
	private Date effectiveDate;
	private BigDecimal exchangeRateAmount;
	private BigDecimal roundedExchangedBv;

	public BonusExchangeRateDetail() {
		super();
	}

	public int getAff() {
		return aff;
	}

	public void setAff(int aff) {
		this.aff = aff;
	}

	public String getExchangeRateTypeCode() {
		return exchangeRateTypeCode;
	}

	public void setExchangeRateTypeCode(String exchangeRateTypeCode) {
		this.exchangeRateTypeCode = exchangeRateTypeCode;
	}

	public String getFromIsoCurrencyCode() {
		return fromIsoCurrencyCode;
	}

	public void setFromIsoCurrencyCode(String fromIsoCurrencyCode) {
		this.fromIsoCurrencyCode = fromIsoCurrencyCode;
	}

	public String getToIsoCurrencyCode() {
		return toIsoCurrencyCode;
	}

	public void setToIsoCurrencyCode(String toIsoCurrencyCode) {
		this.toIsoCurrencyCode = toIsoCurrencyCode;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public BigDecimal getExchangeRateAmount() {
		return exchangeRateAmount;
	}

	public void setExchangeRateAmount(BigDecimal exchangeRateAmount) {
		this.exchangeRateAmount = exchangeRateAmount;
	}

	public BigDecimal getRoundedExchangedBv() {
		return roundedExchangedBv;
	}

	public void setRoundedExchangedBv(BigDecimal roundedExchangedBv) {
		this.roundedExchangedBv = roundedExchangedBv;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BonusExchangeRateDetail [aff=").append(aff).append(", exchangeRateTypeCode=")
				.append(exchangeRateTypeCode).append(", fromIsoCurrencyCode=").append(fromIsoCurrencyCode)
				.append(", toIsoCurrencyCode=").append(toIsoCurrencyCode).append(", effectiveDate=")
				.append(effectiveDate).append(", exchangeRateAmount=").append(exchangeRateAmount)
				.append(", roundedExchangedBv=").append(roundedExchangedBv).append("]");
		return builder.toString();
	}
}
