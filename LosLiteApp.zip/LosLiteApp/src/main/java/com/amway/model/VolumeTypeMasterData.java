package com.amway.model;

import java.io.Serializable;

public class VolumeTypeMasterData implements Serializable {
	private static final long serialVersionUID = -4992085508321918426L;
	private String volumeTypeCode;
	private String bvTypeCode;
	private String volumeTypeName;
	private String volumeTypeGroupCode;
	private String volumeTypeDesc;

	public VolumeTypeMasterData() {
		super();
	}

	public String getVolumeTypeCode() {
		return volumeTypeCode;
	}

	public void setVolumeTypeCode(String volumeTypeCode) {
		this.volumeTypeCode = volumeTypeCode;
	}

	public String getBvTypeCode() {
		return bvTypeCode;
	}

	public void setBvTypeCode(String bvTypeCode) {
		this.bvTypeCode = bvTypeCode;
	}

	public String getVolumeTypeName() {
		return volumeTypeName;
	}

	public void setVolumeTypeName(String volumeTypeName) {
		this.volumeTypeName = volumeTypeName;
	}

	public String getVolumeTypeGroupCode() {
		return volumeTypeGroupCode;
	}

	public void setVolumeTypeGroupCode(String volumeTypeGroupCode) {
		this.volumeTypeGroupCode = volumeTypeGroupCode;
	}

	public String getVolumeTypeDesc() {
		return volumeTypeDesc;
	}

	public void setVolumeTypeDesc(String volumeTypeDesc) {
		this.volumeTypeDesc = volumeTypeDesc;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return String.format(
				"VolumeTypeMasterData [volumeTypeCode=%s, bvTypeCode=%s, volumeTypeName=%s, volumeTypeGroupCode=%s, volumeTypeDesc=%s]",
				volumeTypeCode, bvTypeCode, volumeTypeName, volumeTypeGroupCode, volumeTypeDesc)
				+ System.lineSeparator();
	}

}
