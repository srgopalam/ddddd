package com.amway.validators;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.util.StringUtils;

import com.amway.domain.AffAbo;
import com.amway.util.DateUtil;
import com.amway.util.PeriodFormat;

public class InputParamValidator {
	private static final String DEFAULT_AFFABO_SEPERATOR = "-";

	public static final String REGEX_AFF_ABO_FORMAT = "^([0-9]{2,3})\\-([0-9]{1,11})$";

	private InputParamValidator() {
		super();
	}

	/**
	 * Removes the invalid periods.
	 *
	 * @param periods the periods
	 * @return the sets the
	 */
	public static Set<Integer> removeInvalidPeriods(Set<String> periods) {
		Set<Integer> validPeriods = new HashSet<>();
		for (String period : periods) {
			period = StringUtils.trimAllWhitespace(period);
			if (DateUtil.isValidPeriod(period, PeriodFormat.YYYYMM))
				validPeriods.add(Integer.valueOf(period));
		}
		return validPeriods;
	}

	/**
	 * Checks if is valid aff abo.
	 *
	 * @param affAbo the aff abo
	 * @return true, if is valid aff abo
	 */
	public static boolean isValidAffAbo(String affAbo) {
		String affAboPair = affAbo;
		affAboPair = StringUtils.trimAllWhitespace(affAboPair);
		Pattern p = Pattern.compile(REGEX_AFF_ABO_FORMAT);
		Matcher m = p.matcher(affAboPair);
		return m.matches();
	}

	/**
	 * Removes the invalid aff abos.
	 *
	 * @param affAbos      the aff abos
	 * @param affAboParams the aff abo params
	 */
	public static void removeInvalidAffAbos(String affAbos, Set<AffAbo> affAboParams) {
		AffAbo affAbo = null;
		Set<String> affAboSet = StringUtils.commaDelimitedListToSet(affAbos);
		for (String affAboStr : affAboSet) {
			affAboStr = StringUtils.trimAllWhitespace(affAboStr);
			String[] uniqueTokens = StringUtils.tokenizeToStringArray(affAboStr, DEFAULT_AFFABO_SEPERATOR);
			if (null != uniqueTokens && 2 == uniqueTokens.length) {
				affAbo = new AffAbo();
				affAbo.setAff(Integer.valueOf(uniqueTokens[0]));
				affAbo.setAbo(Long.valueOf(uniqueTokens[1]));
				affAboParams.add(affAbo);
			}
		}
	}
}
