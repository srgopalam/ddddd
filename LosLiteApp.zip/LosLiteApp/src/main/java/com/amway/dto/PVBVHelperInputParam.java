package com.amway.dto;

import java.util.List;
import java.util.Map;

import com.amway.api.rest.VolumeAsyncController;
import com.amway.dao.cache.ListCache;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.domain.include.VolumeDetails;
import com.amway.domain.list.Details;
import com.amway.model.AffiliateMasterData;
import com.amway.model.BusinessEntityData;
import com.amway.model.PVBVDetailData;

public class PVBVHelperInputParam {
	private final int period;
	private final Details details;
	private final ModelLosDetailsRequest modelLosDetailsRequest;
	private final Map<Integer, AffiliateMasterData> affMasterMap;
	private final Map<Long, VolumeDetails> volumeDetailsMap;
	private final Map<String, NextPercentageAndVolume> nextPercentageMap;
	private final Map<String, List<PVBVDetailData>> pvBvByVolTypeMap;
	private final Map<Integer, BusinessEntityData> businessEntityDetailMap;
	private final VolumeAsyncController volumeAsyncController;
	private final ListCache listCache;

	public PVBVHelperInputParam(PVBVHelperInputParamBuilder builder) {
		this.period = builder.period;
		this.details = builder.details;
		this.modelLosDetailsRequest = builder.modelLosDetailsRequest;
		this.affMasterMap = builder.affMasterMap;
		this.volumeDetailsMap = builder.volumeDetailsMap;
		this.nextPercentageMap = builder.nextPercentageMap;
		this.pvBvByVolTypeMap = builder.pvBvByVolTypeMap;
		this.businessEntityDetailMap = builder.businessEntityDetailMap;
		this.volumeAsyncController = builder.volumeAsyncController;
		this.listCache = builder.listCache;
	}

	public int getPeriod() {
		return period;
	}

	public Details getDetails() {
		return details;
	}

	public ModelLosDetailsRequest getModelLosDetailsRequest() {
		return modelLosDetailsRequest;
	}

	public Map<Integer, AffiliateMasterData> getAffMasterMap() {
		return affMasterMap;
	}

	public Map<Long, VolumeDetails> getVolumeDetailsMap() {
		return volumeDetailsMap;
	}

	public Map<String, NextPercentageAndVolume> getNextPercentageMap() {
		return nextPercentageMap;
	}

	public Map<String, List<PVBVDetailData>> getPvBvByVolTypeMap() {
		return pvBvByVolTypeMap;
	}

	public Map<Integer, BusinessEntityData> getBusinessEntityDetailMap() {
		return businessEntityDetailMap;
	}

	public VolumeAsyncController getVolumeAsyncController() {
		return volumeAsyncController;
	}

	public ListCache getListCache() {
		return listCache;
	}

	public static class PVBVHelperInputParamBuilder {
		private int period;
		private Details details;
		private ModelLosDetailsRequest modelLosDetailsRequest;
		private Map<Integer, AffiliateMasterData> affMasterMap;
		private Map<Long, VolumeDetails> volumeDetailsMap;
		private Map<String, NextPercentageAndVolume> nextPercentageMap;
		private Map<String, List<PVBVDetailData>> pvBvByVolTypeMap;
		private Map<Integer, BusinessEntityData> businessEntityDetailMap;
		private VolumeAsyncController volumeAsyncController;
		private ListCache listCache;

		public PVBVHelperInputParamBuilder(int period, Details details, ModelLosDetailsRequest modelLosDetailsRequest) {
			this.period = period;
			this.details = details;
			this.modelLosDetailsRequest = modelLosDetailsRequest;
		}

		public PVBVHelperInputParamBuilder affMasterMap(Map<Integer, AffiliateMasterData> affMasterMap) {
			this.affMasterMap = affMasterMap;
			return this;
		}

		public PVBVHelperInputParamBuilder volumeDetailsMap(Map<Long, VolumeDetails> volumeDetailsMap) {
			this.volumeDetailsMap = volumeDetailsMap;
			return this;
		}

		public PVBVHelperInputParamBuilder nextPercentageMap(Map<String, NextPercentageAndVolume> nextPercentageMap) {
			this.nextPercentageMap = nextPercentageMap;
			return this;
		}

		public PVBVHelperInputParamBuilder pvBvByVolTypeMap(Map<String, List<PVBVDetailData>> pvBvByVolTypeMap) {
			this.pvBvByVolTypeMap = pvBvByVolTypeMap;
			return this;
		}

		public PVBVHelperInputParamBuilder businessEntityDetailMap(
				Map<Integer, BusinessEntityData> businessEntityDetailMap) {
			this.businessEntityDetailMap = businessEntityDetailMap;
			return this;
		}

		public PVBVHelperInputParamBuilder volumeAsyncController(VolumeAsyncController volumeAsyncController) {
			this.volumeAsyncController = volumeAsyncController;
			return this;
		}

		public PVBVHelperInputParamBuilder listCache(ListCache listCache) {
			this.listCache = listCache;
			return this;
		}

		public PVBVHelperInputParam build() {
			return new PVBVHelperInputParam(this);
		}
	}

}
