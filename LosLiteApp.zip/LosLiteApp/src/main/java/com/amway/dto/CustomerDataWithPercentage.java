package com.amway.dto;

public class CustomerDataWithPercentage {
	private long bonusCustomerId;
	private int aff;
	private int bonusPeriod;
	private int businessEntity;
	private int bonusPercent;
	private int leadershipPercent;
	private int nextPercent;
	private int nextVolume;

	public CustomerDataWithPercentage() {
	}

	public CustomerDataWithPercentage(long bonusCustomerId, int aff, int bonusPeriod, int businessEntity) {
		super();
		this.bonusCustomerId = bonusCustomerId;
		this.aff = aff;
		this.bonusPeriod = bonusPeriod;
		this.businessEntity = businessEntity;
	}

	public long getBonusCustomerId() {
		return bonusCustomerId;
	}

	public void setBonusCustomerId(long bonusCustomerId) {
		this.bonusCustomerId = bonusCustomerId;
	}

	public int getAff() {
		return aff;
	}

	public void setAff(int aff) {
		this.aff = aff;
	}

	public int getBonusPeriod() {
		return bonusPeriod;
	}

	public void setBonusPeriod(int bonusPeriod) {
		this.bonusPeriod = bonusPeriod;
	}

	public int getBusinessEntity() {
		return businessEntity;
	}

	public void setBusinessEntity(int businessEntity) {
		this.businessEntity = businessEntity;
	}

	public int getBonusPercent() {
		return bonusPercent;
	}

	public void setBonusPercent(int bonusPercent) {
		this.bonusPercent = bonusPercent;
	}

	public int getLeadershipPercent() {
		return leadershipPercent;
	}

	public void setLeadershipPercent(int leadershipPercent) {
		this.leadershipPercent = leadershipPercent;
	}

	public int getNextPercent() {
		return nextPercent;
	}

	public void setNextPercent(int nextPercent) {
		this.nextPercent = nextPercent;
	}

	public int getNextVolume() {
		return nextVolume;
	}

	public void setNextVolume(int nextVolume) {
		this.nextVolume = nextVolume;
	}

}
