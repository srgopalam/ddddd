package com.amway.dto;

import java.math.BigDecimal;

public class BonusExchangeRateDetailParam {
	private final int aff;
	private final int period;
	private final int precision;
	private final String exchangeRateTypeCode;
	private final String fromIsoCurrencyCode;
	private final String toIsoCurrencyCode;
	private final BigDecimal bV;

	public BonusExchangeRateDetailParam(BonusExchangeRateDetailParamBuilder builder) {
		this.aff = builder.aff;
		this.period = builder.period;
		this.precision = builder.precision;
		this.exchangeRateTypeCode = builder.exchangeRateTypeCode;
		this.fromIsoCurrencyCode = builder.fromIsoCurrencyCode;
		this.toIsoCurrencyCode = builder.toIsoCurrencyCode;
		this.bV = builder.bV;
	}

	public int getAff() {
		return aff;
	}

	public int getPeriod() {
		return period;
	}

	public int getPrecision() {
		return precision;
	}

	public String getExchangeRateTypeCode() {
		return exchangeRateTypeCode;
	}

	public String getFromIsoCurrencyCode() {
		return fromIsoCurrencyCode;
	}

	public String getToIsoCurrencyCode() {
		return toIsoCurrencyCode;
	}

	public BigDecimal getBv() {
		return bV;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BonusExchangeRateDetailParam [aff=").append(aff).append(", period=").append(period)
				.append(", precision=").append(precision).append(", exchangeRateTypeCode=").append(exchangeRateTypeCode)
				.append(", fromIsoCurrencyCode=").append(fromIsoCurrencyCode).append(", toIsoCurrencyCode=")
				.append(toIsoCurrencyCode).append(", bV=").append(bV).append("]");
		return builder.toString();
	}

	public static class BonusExchangeRateDetailParamBuilder {
		private int aff;
		private int period;
		private int precision;
		private String exchangeRateTypeCode;
		private String fromIsoCurrencyCode;
		private String toIsoCurrencyCode;
		private BigDecimal bV;

		public BonusExchangeRateDetailParamBuilder(int aff, int period, int precision) {
			this.aff = aff;
			this.period = period;
			this.precision = precision;
		}

		public BonusExchangeRateDetailParamBuilder exchangeRateTypeCode(String exchangeRateTypeCode) {
			this.exchangeRateTypeCode = exchangeRateTypeCode;
			return this;
		}

		public BonusExchangeRateDetailParamBuilder fromIsoCurrencyCode(String fromIsoCurrencyCode) {
			this.fromIsoCurrencyCode = fromIsoCurrencyCode;
			return this;
		}

		public BonusExchangeRateDetailParamBuilder toIsoCurrencyCode(String toIsoCurrencyCode) {
			this.toIsoCurrencyCode = toIsoCurrencyCode;
			return this;
		}

		public BonusExchangeRateDetailParamBuilder bV(BigDecimal bV) {
			this.bV = bV;
			return this;
		}

		public BonusExchangeRateDetailParam build() {
			return new BonusExchangeRateDetailParam(this);
		}
	}
}
