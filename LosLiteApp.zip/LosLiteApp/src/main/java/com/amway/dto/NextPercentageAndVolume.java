package com.amway.dto;

public class NextPercentageAndVolume {
	private int nextPercentage;
	private int nextVolume;
	private int scheduleLevelNumber;
	private int rowNumber;

	public NextPercentageAndVolume() {
	}

	public NextPercentageAndVolume(int nextPercentage, int scheduleLevelNumber, int rowNumber) {
		super();
		this.nextPercentage = nextPercentage;
		this.scheduleLevelNumber = scheduleLevelNumber;
		this.rowNumber = rowNumber;
	}

	public int getNextPercentage() {
		return nextPercentage;
	}

	public void setNextPercentage(int nextPercentage) {
		this.nextPercentage = nextPercentage;
	}

	public int getScheduleLevelNumber() {
		return scheduleLevelNumber;
	}

	public void setScheduleLevelNumber(int scheduleLevelNumber) {
		this.scheduleLevelNumber = scheduleLevelNumber;
	}

	public int getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}

	public int getNextVolume() {
		return nextVolume;
	}

	public void setNextVolume(int nextVolume) {
		this.nextVolume = nextVolume;
	}

}
