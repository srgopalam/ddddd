package com.amway.util.test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.web.WebAppConfiguration;

import com.amway.bootstrap.Application;
import com.amway.util.DateUtil;
import com.amway.util.PeriodFormat;

@WebAppConfiguration
@SpringBootTest(classes = Application.class)
@Profile("beta")
public class DateUtilTest {

	@Before
	public void initTests() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void shouldHavePeriodInYYYYMMFormat() throws Exception {
		assertTrue("Period should be in YYYYMM", DateUtil.isValidPeriod(mockPeriodInYYYYMM(), PeriodFormat.YYYYMM));
	}

	@Test
	public void shouldHavePeriodInMMYYYYFormat() throws Exception {
		assertTrue("Period should be in MMYYY", DateUtil.isValidPeriod(mockPeriodInMMYYYY(), PeriodFormat.MMYYYY));
	}

	private String mockPeriodInYYYYMM() {
		return "201203";
	}

	private String mockPeriodInMMYYYY() {
		return "122015";
	}
}