package com.amway.util.test;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.amway.api.rest.LosController;
import com.amway.bootstrap.Application;
import com.amway.config.CacheConfiguration;
import com.amway.domain.AffAbo;
import com.amway.domain.ModelLosDetailsRequest;
import com.amway.exception.DataRangeException;
import com.amway.service.LosService;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { Application.class, CacheConfiguration.class })
@Profile("theta")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@PropertySource("classpath:client.properties")
public class LosControllerTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private LosService losService;

	@Autowired
	private LosController losController;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();

	}

	@Test
	public void processServiceInputs() throws Exception {
		AffAbo affAbo = new AffAbo();
		affAbo.setAff(10);
		affAbo.setAbo(670l);
		Set<AffAbo> affAbos = new HashSet<>();
		affAbos.add(affAbo);
		Set<Integer> periods = new HashSet<>();
		periods.add(201801);
		ModelLosDetailsRequest request = new ModelLosDetailsRequest();
		request.setAffAbos(affAbos);
		request.setPeriods(periods);
		request.setIncludeAboAttr(true);
		request.setIncludeAwardLevels(true);
		request.setIncludeFrontline(true);
		request.setIncludeGlobalMB(true);
		request.setIncludeHasDownlineFlag(true);
		request.setIncludeInactive(true);
		request.setIncludeInternational(true);
		request.setIncludeMap(true);
		request.setIncludeQualCount(true);
		request.setIncludeSponStats(true);
		request.setIncludeUpline(true);
		request.setIncludeVolumeDetails(true);
		request.setIncludeYTDpv(true);
		Set<String> volumeTypes = new HashSet<>();
		volumeTypes.add("001");
		volumeTypes.add("005");
		request.setVolumeTypes(volumeTypes);
		losController.processServiceInputs(request);
	}

	@Test
	public void processServiceInputs11() throws Exception {
		AffAbo affAbo = new AffAbo();
		affAbo.setAff(10);
		affAbo.setAbo(670l);
		Set<AffAbo> affAbos = new HashSet<>();
		affAbos.add(affAbo);
		Set<Integer> periods = new HashSet<>();
		periods.add(201801);
		ModelLosDetailsRequest request = new ModelLosDetailsRequest();
		request.setAffAbos(affAbos);
		request.setPeriods(periods);
		request.setIncludeAboAttr(true);
		request.setIncludeAwardLevels(true);
		request.setIncludeFrontline(true);
		request.setIncludeGlobalMB(true);
		request.setIncludeHasDownlineFlag(true);
		request.setIncludeInactive(true);
		request.setIncludeInternational(true);
		request.setIncludeMap(true);
		request.setIncludeQualCount(true);
		request.setIncludeSponStats(true);
		request.setIncludeUpline(true);
		request.setIncludeVolumeDetails(true);
		request.setIncludeYTDpv(true);
		request.setAsList(true);
		Set<String> volumeTypes = new HashSet<>();
		volumeTypes.add("001");
		volumeTypes.add("005");
		request.setVolumeTypes(volumeTypes);
		losController.processServiceInputs(request);
	}

	@Test(expected = DataRangeException.class)
	public void processServiceInputs2() throws Exception {
		AffAbo affAbo = new AffAbo();
		affAbo.setAff(10);
		affAbo.setAbo(670l);
		Set<AffAbo> affAbos = new HashSet<>();
		affAbos.add(affAbo);
		Set<Integer> periods = new HashSet<>();
		periods.add(201801);
		periods.add(201802);
		ModelLosDetailsRequest request = new ModelLosDetailsRequest();
		request.setAffAbos(affAbos);
		request.setPeriods(periods);
		request.setIncludeAboAttr(true);
		request.setIncludeAwardLevels(true);
		request.setIncludeFrontline(true);
		request.setIncludeGlobalMB(true);
		request.setIncludeHasDownlineFlag(true);
		request.setIncludeInactive(true);
		request.setIncludeInternational(true);
		request.setIncludeMap(true);
		request.setIncludeQualCount(true);
		request.setIncludeSponStats(true);
		request.setIncludeUpline(true);
		request.setIncludeVolumeDetails(true);
		request.setIncludeYTDpv(true);
		losController.processServiceInputs(request);
	}

	@Test
	public void processServiceInputs3() throws Exception {
		AffAbo affAbo = new AffAbo();
		affAbo.setAff(10);
		affAbo.setAbo(670l);
		Set<AffAbo> affAbos = new HashSet<>();
		affAbos.add(affAbo);
		Set<Integer> periods = new HashSet<>();
		periods.add(202001);
		ModelLosDetailsRequest request = new ModelLosDetailsRequest();
		request.setAffAbos(affAbos);
		request.setPeriods(periods);
		request.setIncludeAboAttr(true);
		request.setIncludeAwardLevels(true);
		request.setIncludeFrontline(true);
		request.setIncludeGlobalMB(true);
		request.setIncludeHasDownlineFlag(true);
		request.setIncludeInactive(true);
		request.setIncludeInternational(true);
		request.setIncludeMap(true);
		request.setIncludeQualCount(true);
		request.setIncludeSponStats(true);
		request.setIncludeUpline(true);
		request.setIncludeVolumeDetails(true);
		request.setIncludeYTDpv(true);
		losController.processServiceInputs(request);
	}

	@Test(expected = DataRangeException.class)
	public void processServiceInputs4() throws Exception {
		AffAbo affAbo = new AffAbo();
		affAbo.setAff(10);
		affAbo.setAbo(670l);
		Set<AffAbo> affAbos = new HashSet<>();
		affAbos.add(affAbo);
		Set<Integer> periods = new HashSet<>();
		periods.add(20181);
		periods.add(20182);
		ModelLosDetailsRequest request = new ModelLosDetailsRequest();
		request.setAffAbos(affAbos);
		request.setPeriods(periods);
		request.setIncludeAboAttr(true);
		request.setIncludeAwardLevels(true);
		request.setIncludeFrontline(true);
		request.setIncludeGlobalMB(true);
		request.setIncludeHasDownlineFlag(true);
		request.setIncludeInactive(true);
		request.setIncludeInternational(true);
		request.setIncludeMap(true);
		request.setIncludeQualCount(true);
		request.setIncludeSponStats(true);
		request.setIncludeUpline(true);
		request.setIncludeVolumeDetails(true);
		request.setIncludeYTDpv(true);
		losController.processServiceInputs(request);
	}

	@Test(expected = DataRangeException.class)
	public void processServiceInputs5() throws Exception {
		AffAbo affAbo = new AffAbo();
		affAbo.setAff(10);
		affAbo.setAbo(111111670l);
		Set<AffAbo> affAbos = new HashSet<>();
		affAbos.add(affAbo);
		Set<Integer> periods = new HashSet<>();
		periods.add(20181);
		periods.add(20182);
		ModelLosDetailsRequest request = new ModelLosDetailsRequest();
		request.setAffAbos(affAbos);
		request.setPeriods(periods);
		request.setIncludeAboAttr(true);
		request.setIncludeAwardLevels(true);
		request.setIncludeFrontline(true);
		request.setIncludeGlobalMB(true);
		request.setIncludeHasDownlineFlag(true);
		request.setIncludeInactive(true);
		request.setIncludeInternational(true);
		request.setIncludeMap(true);
		request.setIncludeQualCount(true);
		request.setIncludeSponStats(true);
		request.setIncludeUpline(true);
		request.setIncludeVolumeDetails(true);
		request.setIncludeYTDpv(true);
		losController.processServiceInputs(request);
	}
}